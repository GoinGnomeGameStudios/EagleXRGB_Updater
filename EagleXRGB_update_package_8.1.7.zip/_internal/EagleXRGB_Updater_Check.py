import hashlib
import os
import shutil
import subprocess
import sys
import json
import logging
import time
import zipfile
from datetime import datetime

import requests
from packaging import version

class AutoUpdater:
    def __init__(self, update_url, current_version, splash_screen):
        self.update_url = update_url
        self.current_version = current_version
        self.splash_screen = splash_screen
        self.base_path = self.get_app_dir()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.exe_name = os.path.basename(sys.executable)
        self.update_info = {}  # Will be populated when checking for updates
        self.setup_logging()

    def setup_logging(self):
        logging.basicConfig(filename='update_check.log', level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def get_app_dir(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            logging.info(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.current_version)
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")

            if latest_version > current_version:
                self.update_info = remote_version_info
                self.update_info['new_version'] = str(latest_version)
                return True, self.update_info
            return False, None
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"

    def download_update(self, version_info):
        if not version_info or 'update_package' not in version_info:
            logging.error("Invalid version info")
            return False

        try:
            update_url = f"{self.update_url}/{version_info['update_package']}"
            logging.info(f"Downloading update package from: {update_url}")
            response = requests.get(update_url, stream=True)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, 'update_package.zip')

            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded = 0

            with open(package_path, 'wb') as f:
                for data in response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        self.splash_screen.update_progress(progress, "Downloading update...")

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def prepare_for_update(self, version_info):
        update_info = {
            'main_exe_path': sys.executable,
            'update_url': self.update_url,
            'current_version': self.current_version,
            'new_version': version_info['latest_version']
        }
        update_info_path = os.path.join(self.temp_dir, 'EagleXRGB_update_info.json')
        with open(update_info_path, 'w') as f:
            json.dump(update_info, f)
        return update_info_path

    def apply_update(self):
        try:
            logging.info("Starting update application process")

            # Download the update
            if not self.download_update(self.update_info):
                raise Exception("Failed to download update package")

            # Extract and apply the update
            self.extract_update()
            self.update_files_and_folders()

            # Verify the update
            self.verify_update()

            # Clean up
            self.cleanup_update_files()

            # Update local version file
            self.update_local_version_file(self.update_info)

            logging.info("Update applied successfully")
            return True
        except Exception as e:
            logging.error(f"Error applying update: {str(e)}", exc_info=True)
            return False

    def extract_update(self):
        package_path = os.path.join(self.temp_dir, 'update_package.zip')
        logging.info(f"Extracting update package: {package_path}")
        with zipfile.ZipFile(package_path, 'r') as zip_ref:
            zip_ref.extractall(self.temp_dir)
        logging.info("Update package extracted successfully")

    def update_files_and_folders(self):
        manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
        if not os.path.exists(manifest_path):
            raise Exception("Update manifest not found")

        with open(manifest_path, 'r') as f:
            manifest = json.load(f)

        total_items = len(manifest.get('files_to_update', [])) + len(manifest.get('folders_to_update', []))
        current_item = 0

        for item in manifest.get('files_to_update', []) + manifest.get('folders_to_update', []):
            if 'path' in item:
                if os.path.isfile(os.path.join(self.temp_dir, item['path'])):
                    self.update_file(item)
                else:
                    self.update_folder(item)
            current_item += 1
            progress = int((current_item / total_items) * 100)
            logging.info(f"Update progress: {progress}%")
            if self.splash_screen:
                self.splash_screen.update_progress(progress, "Updating")

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if file_info['path'] == self.exe_name:
            return  # We'll handle the EXE separately

        if os.path.exists(src):
            if file_info['action'] == 'replace' or not os.path.exists(dst):
                self.safe_file_operation(shutil.copy2, src, dst)
                logging.info(f"Updated file: {file_info['path']}")
        else:
            logging.warning(f"Source file not found: {src}")

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        if os.path.exists(src):
            if folder_info['action'] == 'merge':
                self.merge_folders(src, dst)
            elif folder_info['action'] == 'create_if_not_exists':
                if not os.path.exists(dst):
                    self.safe_file_operation(shutil.copytree, src, dst)
                    logging.info(f"Created folder: {folder_info['path']}")
            elif folder_info['action'] == 'replace':
                if os.path.exists(dst):
                    self.safe_file_operation(shutil.rmtree, dst)
                self.safe_file_operation(shutil.copytree, src, dst)
                logging.info(f"Replaced folder: {folder_info['path']}")
        else:
            logging.warning(f"Source folder not found: {src}")

    def safe_file_operation(self, operation, *args, max_attempts=10, delay=2):
        for attempt in range(max_attempts):
            try:
                operation(*args)
                return
            except PermissionError as e:
                if attempt < max_attempts - 1:
                    logging.warning(f"Permission error, retrying in {delay} seconds: {str(e)}")
                    time.sleep(delay)
                else:
                    raise

    def merge_folders(self, src, dst):
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                self.merge_folders(s, d)
            else:
                self.safe_file_operation(shutil.copy2, s, d)
                logging.info(f"Updated file in merge: {d}")

    def update_local_version_file(self, new_version_info):
        self.splash_screen.update_progress(50, "Updating version information...")
        current_time = datetime.now().isoformat()
        local_version_info = {
            "latest_version": new_version_info['latest_version'],
            "update_date": current_time

        }
        self.splash_screen.update_progress(100, "Version information updated")
        with open(self.version_file, 'w') as f:
            json.dump(local_version_info, f, indent=2)
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def automatic_update(self):
        update_available, version_info = self.check_for_updates()
        if update_available and version_info:
            logging.info(f"Update available: {version_info.get('latest_version', 'Unknown')}")
            if self.download_update(version_info):
                return self.apply_update()
        return False

    def handle_post_update(self):
        logging.info("Handling post-update tasks")
        try:
            # Verify the update
            self.verify_update()

            # Clean up temporary files
            self.cleanup_update_files()

            # Update the local version file
            with open(self.version_file, 'r') as f:
                version_info = json.load(f)
            self.update_local_version_file(version_info)

            logging.info("Post-update tasks completed successfully")
        except Exception as e:
            logging.error(f"Error during post-update tasks: {str(e)}", exc_info=True)

    def verify_update(self):
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                logging.info(f"Verifying update (Attempt {attempt + 1}/{max_attempts})")

                # Step 1: Check the version of the main executable
                self.splash_screen.update_progress(25, "Verifying executable version...")
                self.verify_executable_version()

                # Step 2: Verify critical files and directories
                self.splash_screen.update_progress(50, "Verifying critical files...")
                self.verify_critical_files()

                # Step 3: Check the version file
                self.splash_screen.update_progress(75, "Verifying version file...")
                self.verify_version_file()

                # Step 4: Verify file integrity (if checksums are provided in the manifest)
                self.splash_screen.update_progress(90, "Verifying file integrity...")
                self.verify_file_integrity()

                logging.info("Update verification completed successfully")
                self.splash_screen.update_progress(100, "Update verification complete")
                return True
            except Exception as e:
                logging.error(f"Verification attempt {attempt + 1} failed: {str(e)}")
                if attempt < max_attempts - 1:
                    time.sleep(2)  # Wait before retrying
                else:
                    raise Exception(f"Update verification failed after {max_attempts} attempts")

    def verify_executable_version(self):
        main_exe = os.path.basename(sys.executable)
        result = subprocess.run([sys.executable, '--version'], capture_output=True, text=True, timeout=10)
        version_output = result.stdout.strip()
        expected_version = self.get_expected_version()
        if version_output != expected_version:
            raise Exception(f"Executable version mismatch. Expected {expected_version}, got {version_output}")
        logging.info(f"Executable version verified: {version_output}")

    def verify_critical_files(self):
        critical_files = [
            'EDC_EagleXRGB_Connector.exe',
            'EagleXRGB_Auto_updater.exe',
            'config/EagleXRGB_https_settings.json',
            # Add more critical files as needed
        ]
        for file in critical_files:
            file_path = os.path.join(self.base_path, file)
            if not os.path.exists(file_path):
                raise Exception(f"Critical file missing: {file}")
        logging.info("All critical files verified")

    def verify_version_file(self):
        if not os.path.exists(self.version_file):
            raise Exception("Version file is missing")
        with open(self.version_file, 'r') as f:
            version_info = json.load(f)
        if 'latest_version' not in version_info or 'update_date' not in version_info:
            raise Exception("Version file is incomplete")
        if version_info['latest_version'] != self.get_expected_version():
            raise Exception(f"Version file mismatch. Expected {self.get_expected_version()}, got {version_info['latest_version']}")
        logging.info("Version file verified")

    def verify_file_integrity(self):
        manifest_path = os.path.join(self.base_path, 'EagleXRGB_update_manifest.json')
        if not os.path.exists(manifest_path):
            logging.warning("Update manifest not found, skipping file integrity check")
            return

        with open(manifest_path, 'r') as f:
            manifest = json.load(f)

        for file_info in manifest.get('files_to_update', []):
            if 'checksum' in file_info:
                file_path = os.path.join(self.base_path, file_info['path'])
                if not os.path.exists(file_path):
                    raise Exception(f"File missing: {file_info['path']}")
                calculated_checksum = self.calculate_file_checksum(file_path)
                if calculated_checksum != file_info['checksum']:
                    raise Exception(f"Checksum mismatch for file: {file_info['path']}")

        logging.info("File integrity verified")

    def calculate_file_checksum(self, file_path):
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    def get_expected_version(self):
        # This should return the version that we expect after the update
        # It could be stored in the update info file or in a constant
        return self.update_info['new_version']

    def cleanup_update_files(self):
        self.splash_screen.update_progress(50, "Cleaning up temporary files...")
        # ... (existing cleanup code) ...
        self.splash_screen.update_progress(100, "Cleanup complete")

