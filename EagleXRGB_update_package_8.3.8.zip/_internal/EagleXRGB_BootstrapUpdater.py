import fnmatch
import hashlib
import os
import sqlite3
import sys
import json
import shutil
import logging
import time
import psutil
import subprocess
from logging.handlers import RotatingFileHandler
from pathlib import Path

import win32con
import win32gui
import win32process


def get_base_path():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


# Add the bundled Python's site-packages to sys.path
base_path = get_base_path()
python_embedded_dir = os.path.join(base_path, 'python_embedded')
site_packages = os.path.join(python_embedded_dir, 'Lib', 'site-packages')

# Add the base path and site-packages to sys.path
sys.path.insert(0, base_path)
sys.path.insert(0, site_packages)

from packaging import version
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication, QMessageBox
from EagleXRGB_version_utils import compare_versions, get_base_path, get_file_version
from EagleXRGB_splash_screen import EpicSplashScreen


def setup_logging(base_path):
    log_dir = os.path.join(base_path, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, 'EagleXRGB_BootstrapUpdater.log')

    handler = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=3)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    logger = logging.getLogger('EagleXRGB_BootstrapUpdater')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    return logger


logger = setup_logging(get_base_path())


def write_progress(base_path, task, progress, message, overall_progress, overall_status):
    progress_file = os.path.join(base_path, 'update_progress.json')
    progress_data = {
        'task': task,
        'progress': progress,
        'message': message,
        'overall_progress': overall_progress,
        'overall_status': overall_status
    }
    with open(progress_file, 'w') as f:
        json.dump(progress_data, f)


def wait_for_main_app_to_close(logger, base_path, splash_screen, max_wait_time=30):
    logger.info("Waiting for main application to close...")
    update_splash_screen(splash_screen, 'wait', 0, "Waiting for main application to close...", 0, "Preparing update")
    start_time = time.time()

    while time.time() - start_time < max_wait_time:
        main_app_processes = [proc for proc in psutil.process_iter(['name', 'pid']) if
                              proc.info['name'] == 'EagleXRGB_Connector.exe']

        if not main_app_processes:
            logger.info("Main application has closed")
            update_splash_screen(splash_screen, 'wait', 100, "Main application closed", 5, "Preparing update")
            return True

        # Try to close the application gracefully
        for proc in main_app_processes:
            try:
                # Find the window for this process
                def enum_windows_callback(hwnd, pid):
                    if win32gui.IsWindowVisible(hwnd) and win32gui.IsWindowEnabled(hwnd):
                        _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
                        if found_pid == pid:
                            win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                            return False  # Stop enumerating
                    return True

                win32gui.EnumWindows(lambda hwnd, _: enum_windows_callback(hwnd, proc.info['pid']), None)

                # Give it some time to close
                proc.wait(timeout=5)
            except psutil.TimeoutExpired:
                logger.warning(f"Graceful shutdown timed out for PID {proc.info['pid']}, attempting to terminate.")
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except psutil.TimeoutExpired:
                    logger.warning(f"Termination timed out for PID {proc.info['pid']}, killing the process.")
                    proc.kill()

        time.sleep(1)
        progress = int((time.time() - start_time) / max_wait_time * 100)
        update_splash_screen(splash_screen, 'wait', progress, f"Waiting for main application to close... {progress}%",
                             0, "Preparing update")

    logger.warning(f"Timeout waiting for main application to close after {max_wait_time} seconds")
    return False


def update_splash_screen(splash_screen, task, progress, message, overall_progress, overall_status):
    if splash_screen:
        splash_screen.update_status(overall_status)
        if task == "download":
            splash_screen.update_download_progress(progress)
        elif task == "update":
            splash_screen.update_update_progress(progress)
    write_progress(base_path, task, progress, message, overall_progress, overall_status)


def safe_remove(path, logger):
    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            if os.path.isfile(path):
                os.remove(path)
            elif os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            return True
        except Exception as e:
            logger.warning(f"Attempt {attempt + 1} to remove {path} failed: {str(e)}")
            time.sleep(1)  # Wait for 1 second before retrying
    logger.error(f"Failed to remove {path} after {max_attempts} attempts")
    return False


def safe_copy(src, dest, ignore_patterns, logger):
    if any(fnmatch.fnmatch(os.path.basename(src), pattern) for pattern in ignore_patterns):
        logger.info(f"Skipping {src} due to ignore pattern")
        return True

    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            if os.path.isfile(src):
                shutil.copy2(src, dest)
            elif os.path.isdir(src):
                if os.path.exists(dest):
                    shutil.rmtree(dest, ignore_errors=True)
                shutil.copytree(src, dest, ignore=shutil.ignore_patterns(*ignore_patterns))
            return True
        except Exception as e:
            logger.warning(f"Attempt {attempt + 1} to copy {src} to {dest} failed: {str(e)}")
            time.sleep(1)  # Wait for 1 second before retrying
    logger.error(f"Failed to copy {src} to {dest} after {max_attempts} attempts")
    return False


def copy_with_retry(src: str, dest: str, max_attempts: int = 5, delay: int = 1) -> bool:
    for attempt in range(max_attempts):
        try:
            shutil.copy2(src, dest)
            return True
        except PermissionError:
            if attempt < max_attempts - 1:
                time.sleep(delay)
            else:
                return False
        except Exception:
            return False


def selective_update_folder(base_path, temp_dir, folder_info, logger):
    update_details = folder_info.get('update_details', [])
    if not update_details:
        logger.warning(f"No update details found for folder: {folder_info['path']}")
        return

    for detail in update_details:
        if detail['category'] == 'custom_scripts':
            update_custom_scripts(base_path, temp_dir, detail['files'], folder_info['path'],
                                  folder_info.get('ignore_patterns', []), logger)


def update_internal_folder(base_path, temp_dir, folder_info, logger):
    for detail in folder_info['update_details']:
        if detail['category'] == 'custom_scripts':
            for file_info in detail['files']:
                if file_info['action'] == 'replace_if_flagged':
                    update_file_if_flagged(base_path, temp_dir, file_info, logger)
        elif detail['category'] == 'third_party_modules':
            for module in detail['modules']:
                if module['action'] == 'update_if_changed':
                    update_module_if_changed(base_path, temp_dir, module, logger)


def is_file_flagged(base_path, file_path, update_file_path):
    current_file_path = os.path.join(base_path, file_path)

    if not os.path.exists(current_file_path):
        return True  # File doesn't exist, so it should be updated

    current_version = get_file_version(current_file_path)
    update_version = get_file_version(update_file_path)

    if current_version is None or update_version is None:
        # If we can't get the version, compare modification times
        return os.path.getmtime(update_file_path) > os.path.getmtime(current_file_path)

    return compare_versions(update_version, current_version) > 0


def update_file_if_flagged(base_path, temp_dir, file_info, logger):
    src = os.path.join(temp_dir, '_internal', file_info['path'])
    dest = os.path.join(base_path, '_internal', file_info['path'])
    if is_file_flagged(base_path, dest, src):
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            if safe_copy(src, dest, [], logger):
                logger.info(f"Updated file: {file_info['path']}")
            else:
                raise Exception(f"Failed to copy {src} to {dest}")
        except Exception as e:
            logger.error(f"Failed to update file {file_info['path']}: {str(e)}")
            raise


def update_internal_scripts(base_path, temp_dir, folder_info, logger):
    internal_dir = os.path.join(base_path, '_internal')
    temp_internal_dir = os.path.join(temp_dir, '_internal')

    for detail in folder_info['update_details']:
        if detail['category'] == 'custom_scripts':
            for file_info in detail['files']:
                src = os.path.join(temp_internal_dir, file_info['path'])
                dest = os.path.join(internal_dir, file_info['path'])
                if os.path.exists(src) and is_file_flagged(base_path, dest, src):
                    try:
                        shutil.copy2(src, dest)
                        logger.info(f"Updated file: {file_info['path']}")
                    except Exception as e:
                        logger.error(f"Failed to update file {file_info['path']}: {str(e)}")
                        raise


def calculate_directory_checksum(directory):
    checksum = hashlib.md5()
    for root, _, files in os.walk(directory):
        for file in sorted(files):  # Sort to ensure consistent order
            file_path = os.path.join(root, file)
            if file.endswith('.pyc') or file.endswith('.pyo'):
                continue  # Skip compiled Python files
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(8192)
                    if not chunk:
                        break
                    checksum.update(chunk)
    return checksum.hexdigest()


def is_module_changed(base_path, module_name):
    current_module_path = os.path.join(base_path, '_internal', module_name)
    update_module_path = os.path.join(base_path, 'EagleXRGB_update_temp', '_internal', module_name)

    if not os.path.exists(current_module_path):
        return True  # Module doesn't exist, so it should be updated

    current_checksum = calculate_directory_checksum(current_module_path)
    update_checksum = calculate_directory_checksum(update_module_path)

    return current_checksum != update_checksum


def update_file(base_path, temp_dir, file_info, logger):
    src = os.path.join(temp_dir, file_info['path'])
    dest = os.path.join(base_path, file_info['path'])
    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if safe_copy(src, dest, [], logger):  # Empty list for ignore_patterns
            logger.info(f"Updated file: {file_info['path']}")
        else:
            raise Exception(f"Failed to copy {src} to {dest}")
    except Exception as e:
        logger.error(f"Failed to update file {file_info['path']}: {str(e)}")
        raise


def update_module_if_changed(base_path, temp_dir, module, logger):
    src = os.path.join(temp_dir, '_internal', module['name'])
    dest = os.path.join(base_path, '_internal', module['name'])
    if is_module_changed(base_path, module['name']):
        if os.path.isdir(src):
            if os.path.exists(dest):
                shutil.rmtree(dest)
            shutil.copytree(src, dest)
        else:
            shutil.copy2(src, dest)
        logger.info(f"Updated module: {module['name']}")


def update_custom_scripts(base_path, temp_dir, files, base_folder, ignore_patterns, logger):
    for file_info in files:
        src = os.path.join(temp_dir, base_folder, file_info['path'])
        dest = os.path.join(base_path, base_folder, file_info['path'])
        if any(fnmatch.fnmatch(file_info['path'], pattern) for pattern in ignore_patterns):
            logger.info(f"Skipping {file_info['path']} due to ignore pattern")
            continue
        if os.path.exists(src) and (file_info['action'] == 'replace' or
                                    (file_info['action'] == 'replace_if_flagged' and is_file_flagged(base_path, dest,
                                                                                                     src))):
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            if safe_copy(src, dest, [], logger):
                logger.info(f"Updated file: {dest}")
            else:
                logger.error(f"Failed to update file: {dest}")


def should_update_module(self, module_name, src_path, dest_path):
    try:
        current_version = self.get_installed_version(module_name)
        new_version = self.get_package_version(src_path)

        if current_version is None or new_version is None:
            logging.warning(f"Unable to determine version for {module_name}. Updating as precaution.")
            return True

        if version.parse(new_version) > version.parse(current_version):
            logging.info(f"New version available for {module_name}: {current_version} -> {new_version}")
            return True
        else:
            logging.info(f"Module {module_name} is up to date (version {current_version})")
            return False
    except Exception as e:
        logging.error(f"Error checking version for {module_name}: {str(e)}")
        return True  # Update as a precaution if version check fails


def update_third_party_modules(base_path, temp_dir, modules, base_folder, logger):
    for module in modules:
        if module['action'] == 'update_if_changed':
            src = os.path.join(temp_dir, base_folder, module['name'])
            dest = os.path.join(base_path, base_folder, module['name'])
            if os.path.exists(src) and is_module_changed(base_path, module['name']):
                if os.path.isdir(src):
                    if os.path.exists(dest):
                        shutil.rmtree(dest)
                    shutil.copytree(src, dest)
                else:
                    shutil.copy2(src, dest)
                logger.info(f"Updated module: {module['name']}")


def apply_updates(base_path, temp_dir, manifest, logger):
    logger.info("Applying updates")
    write_progress(base_path, 'apply', 0, "Starting to apply updates...", 10, "Applying updates")

    try:
        # Update main executable files
        for file_info in manifest['files_to_update']:
            update_file(base_path, temp_dir, file_info, logger)

        # Update internal scripts
        for folder_info in manifest['folders_to_update']:
            if folder_info['path'] == '_internal':
                update_internal_scripts(base_path, temp_dir, folder_info, logger)

        update_version_info(base_path, manifest, logger)

        write_progress(base_path, 'apply', 100, "Updates applied successfully", 90, "Applying updates")
        logger.info("Updates applied successfully")
        return True
    except Exception as e:
        logger.exception(f"Error applying update: {str(e)}")
        write_progress(base_path, 'error', 100, f"Error applying update: {str(e)}", 90, "Update failed")
        return False


def perform_post_update_tasks(base_path, logger):
    logger.info("Starting post-update tasks")
    write_progress(base_path, 'post_update', 0, "Starting post-update tasks...", 90, "Performing post-update tasks")
    try:
        update_config_files(base_path, logger)
        migrate_data(base_path, logger)
        refresh_caches(base_path, logger)
        update_database_schema(base_path, logger)
        rebuild_search_indexes(base_path, logger)
        clear_temp_files(base_path, logger)
        update_file_permissions(base_path, logger)
        verify_critical_components(base_path, logger)
        run_version_specific_updates(base_path, logger)
        update_last_update_timestamp(base_path, logger)

        logger.info("Post-update tasks completed successfully")
        write_progress(base_path, 'post_update', 100, "Post-update tasks completed", 100, "Update complete")
    except Exception as e:
        logger.error(f"Error during post-update tasks: {str(e)}")
        write_progress(base_path, 'error', 100, f"Error during post-update tasks: {str(e)}", 100, "Update failed")
        raise


def update_config_files(base_path, logger):
    logger.info("Updating configuration files")
    config_dir = os.path.join(base_path, 'config')
    for config_file in os.listdir(config_dir):
        if config_file.endswith('.json'):
            merge_config_file(base_path, os.path.join(config_dir, config_file), logger)


def merge_config_file(base_path, config_path, logger):
    with open(config_path, 'r') as f:
        current_config = json.load(f)

    temp_dir = os.path.join(base_path, 'EagleXRGB_update_temp')
    new_config_path = os.path.join(temp_dir, 'config', os.path.basename(config_path))
    if os.path.exists(new_config_path):
        with open(new_config_path, 'r') as f:
            new_config = json.load(f)

        merged_config = merge_configs(current_config, new_config, logger)

        with open(config_path, 'w') as f:
            json.dump(merged_config, f, indent=2)
        logger.info(f"Updated configuration file: {config_path}")


def merge_configs(current_config, new_config, logger):
    logger.info("Merging configurations")
    merged = current_config.copy()

    for key, value in new_config.items():
        if key in current_config:
            if isinstance(value, dict) and isinstance(current_config[key], dict):
                merged[key] = merge_configs(current_config[key], value, logger)
            elif isinstance(value, list) and isinstance(current_config[key], list):
                merged[key] = list(set(current_config[key] + value))
            else:
                merged[key] = value
        else:
            merged[key] = value

    return merged


def migrate_data(base_path, logger):
    logger.info("Starting data migration")
    try:
        with open(os.path.join(base_path, 'EagleXRGB_version_client.json'), 'r') as f:
            current_version_info = json.load(f)
        with open(os.path.join(base_path, 'EagleXRGB_update_temp', 'EagleXRGB_version_server.json'), 'r') as f:
            new_version_info = json.load(f)

        current_version = version.parse(current_version_info['version'])
        new_version = version.parse(new_version_info['latest_version'])

        if current_version < version.parse("8.3.0") <= new_version:
            migrate_to_8_3_0(base_path, logger)

        if current_version < version.parse("8.3.4") <= new_version:
            migrate_to_8_3_4(base_path, logger)

        logger.info("Data migration completed successfully")
    except Exception as e:
        logger.error(f"Error during data migration: {str(e)}")
        raise


def refresh_caches(base_path, logger):
    logger.info("Refreshing caches")
    cache_dir = os.path.join(base_path, 'cache')
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)
    os.makedirs(cache_dir)


def update_database_schema(base_path, logger):
    logger.info("Updating database schema")
    try:
        db_path = os.path.join(base_path, 'EagleXRGB_database.sqlite')
        shutil.copy2(db_path, f"{db_path}.bak")

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("PRAGMA user_version")
        current_schema_version = cursor.fetchone()[0]

        schema_updates = [
            (1, "CREATE TABLE IF NOT EXISTS new_table (id INTEGER PRIMARY KEY, name TEXT)"),
            (2, "ALTER TABLE existing_table ADD COLUMN new_column TEXT"),
        ]

        for version, sql in schema_updates:
            if version > current_schema_version:
                logger.info(f"Applying schema update version {version}")
                cursor.execute(sql)
                cursor.execute(f"PRAGMA user_version = {version}")
                conn.commit()

        conn.close()
        logger.info("Database schema update completed successfully")
    except Exception as e:
        logger.error(f"Error updating database schema: {str(e)}")
        shutil.copy2(f"{db_path}.bak", db_path)
        raise


def rebuild_search_indexes(base_path, logger):
    logger.info("Rebuilding search indexes")
    try:
        index_dir = os.path.join(base_path, 'search_indexes')
        if os.path.exists(index_dir):
            shutil.copytree(index_dir, f"{index_dir}_bak")
            shutil.rmtree(index_dir)
        os.makedirs(index_dir)

        create_document_index(base_path, logger)
        create_user_index(base_path, logger)
        create_content_index(base_path, logger)

        logger.info("Search indexes rebuilt successfully")
    except Exception as e:
        logger.error(f"Error rebuilding search indexes: {str(e)}")
        if os.path.exists(f"{index_dir}_bak"):
            shutil.rmtree(index_dir)
            shutil.move(f"{index_dir}_bak", index_dir)
        raise


def migrate_to_8_3_0(self):
    self.logger.info("Starting migration to version 8.3.0")
    try:
        # 1. Update file formats
        self.update_file_formats_8_3_0()

        # 2. Restructure data directories
        self.restructure_directories_8_3_0()

        # 3. Convert deprecated data structures
        self.convert_deprecated_structures_8_3_0()

        self.logger.info("Migration to version 8.3.0 completed successfully")
    except Exception as e:
        self.logger.error(f"Error during migration to 8.3.0: {str(e)}")
        raise


def update_file_formats_8_3_0(self):
    self.logger.info("Updating file formats for 8.3.0")
    try:
        # Example: Convert all .txt files to .json
        data_dir = os.path.join(self.base_path, 'data')
        for root, _, files in os.walk(data_dir):
            for file in files:
                if file.endswith('.txt'):
                    txt_path = os.path.join(root, file)
                    json_path = txt_path[:-4] + '.json'
                    with open(txt_path, 'r') as txt_file:
                        data = txt_file.read().strip().split('\n')
                    with open(json_path, 'w') as json_file:
                        json.dump({"data": data}, json_file, indent=2)
                    os.remove(txt_path)
                    self.logger.info(f"Converted {txt_path} to {json_path}")
    except Exception as e:
        self.logger.error(f"Error updating file formats: {str(e)}")
        raise


def restructure_directories_8_3_0(self):
    self.logger.info("Restructuring directories for 8.3.0")
    try:
        # Example: Move all user data to a new 'users' directory
        old_user_dir = os.path.join(self.base_path, 'user_data')
        new_user_dir = os.path.join(self.base_path, 'users')
        if os.path.exists(old_user_dir):
            shutil.move(old_user_dir, new_user_dir)
            self.logger.info(f"Moved user data from {old_user_dir} to {new_user_dir}")
    except Exception as e:
        self.logger.error(f"Error restructuring directories: {str(e)}")
        raise


def convert_deprecated_structures_8_3_0(self, ET=None):
    self.logger.info("Converting deprecated data structures for 8.3.0")
    try:
        # Example: Convert old XML configuration to JSON
        old_config = os.path.join(self.base_path, 'config', 'old_config.xml')
        new_config = os.path.join(self.base_path, 'config', 'new_config.json')
        if os.path.exists(old_config):
            tree = ET.parse(old_config)
            root = tree.getroot()
            config_dict = {elem.tag: elem.text for elem in root}
            with open(new_config, 'w') as f:
                json.dump(config_dict, f, indent=2)
            os.remove(old_config)
            self.logger.info(f"Converted {old_config} to {new_config}")
    except Exception as e:
        self.logger.error(f"Error converting deprecated structures: {str(e)}")
        raise


def migrate_to_8_3_4(self):
    self.logger.info("Starting migration to version 8.3.4")
    try:
        # 1. Update configuration files
        self.update_config_files_8_3_4()

        # 2. Modify data schemas
        self.modify_data_schemas_8_3_4()

        # 3. Migrate user preferences
        self.migrate_user_preferences_8_3_4()

        self.logger.info("Migration to version 8.3.4 completed successfully")
    except Exception as e:
        self.logger.error(f"Error during migration to 8.3.4: {str(e)}")
        raise


def update_config_files_8_3_4(self):
    self.logger.info("Updating configuration files for 8.3.4")
    try:
        config_path = os.path.join(self.base_path, 'config', 'app_config.json')
        with open(config_path, 'r') as f:
            config = json.load(f)

        # Example: Add new configuration option
        if 'new_feature_enabled' not in config:
            config['new_feature_enabled'] = True

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        self.logger.info(f"Updated configuration file: {config_path}")
    except Exception as e:
        self.logger.error(f"Error updating configuration files: {str(e)}")
        raise


def modify_data_schemas_8_3_4(self):
    self.logger.info("Modifying data schemas for 8.3.4")
    try:
        db_path = os.path.join(self.base_path, 'EagleXRGB_database.sqlite')
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Example: Add a new column to an existing table
        cursor.execute("ALTER TABLE users ADD COLUMN last_login DATETIME")

        conn.commit()
        conn.close()
        self.logger.info("Modified database schema successfully")
    except Exception as e:
        self.logger.error(f"Error modifying data schemas: {str(e)}")
        raise


def migrate_user_preferences_8_3_4(self):
    self.logger.info("Migrating user preferences for 8.3.4")
    try:
        prefs_dir = os.path.join(self.base_path, 'users')
        for user_dir in os.listdir(prefs_dir):
            user_prefs_path = os.path.join(prefs_dir, user_dir, 'preferences.json')
            if os.path.exists(user_prefs_path):
                with open(user_prefs_path, 'r') as f:
                    prefs = json.load(f)

                # Example: Update preference structure
                if 'theme' in prefs:
                    prefs['appearance'] = {'theme': prefs.pop('theme')}

                with open(user_prefs_path, 'w') as f:
                    json.dump(prefs, f, indent=2)
                self.logger.info(f"Updated preferences for user: {user_dir}")
    except Exception as e:
        self.logger.error(f"Error migrating user preferences: {str(e)}")
        raise


def create_document_index(self):
    self.logger.info("Creating document index")
    try:
        index_dir = os.path.join(self.base_path, 'search_indexes')
        doc_index_path = os.path.join(index_dir, 'document_index.json')
        documents_dir = os.path.join(self.base_path, 'documents')

        index = {}
        for root, _, files in os.walk(documents_dir):
            for file in files:
                if file.endswith('.txt') or file.endswith('.md'):
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r') as f:
                        content = f.read()

                    # Simple indexing: use words as keys and file paths as values
                    for word in set(content.lower().split()):
                        if word not in index:
                            index[word] = []
                        index[word].append(file_path)

        with open(doc_index_path, 'w') as f:
            json.dump(index, f, indent=2)

        self.logger.info(f"Document index created at {doc_index_path}")
    except Exception as e:
        self.logger.error(f"Error creating document index: {str(e)}")
        raise


def create_user_index(self):
    self.logger.info("Creating user index")
    try:
        index_dir = os.path.join(self.base_path, 'search_indexes')
        user_index_path = os.path.join(index_dir, 'user_index.json')
        users_dir = os.path.join(self.base_path, 'users')

        index = {}
        for user_dir in os.listdir(users_dir):
            user_path = os.path.join(users_dir, user_dir)
            if os.path.isdir(user_path):
                user_info_path = os.path.join(user_path, 'info.json')
                if os.path.exists(user_info_path):
                    with open(user_info_path, 'r') as f:
                        user_info = json.load(f)

                    # Index user by username and email
                    index[user_info['username']] = user_path
                    index[user_info['email']] = user_path

        with open(user_index_path, 'w') as f:
            json.dump(index, f, indent=2)

        self.logger.info(f"User index created at {user_index_path}")
    except Exception as e:
        self.logger.error(f"Error creating user index: {str(e)}")
        raise


def create_content_index(self):
    self.logger.info("Creating content index")
    try:
        index_dir = os.path.join(self.base_path, 'search_indexes')
        content_index_path = os.path.join(index_dir, 'content_index.json')
        content_dir = os.path.join(self.base_path, 'content')

        index = {}
        for root, _, files in os.walk(content_dir):
            for file in files:
                if file.endswith('.json'):
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r') as f:
                        content = json.load(f)

                    # Index content by title and tags
                    index[content['title']] = file_path
                    for tag in content.get('tags', []):
                        if tag not in index:
                            index[tag] = []
                        index[tag].append(file_path)

        with open(content_index_path, 'w') as f:
            json.dump(index, f, indent=2)

        self.logger.info(f"Content index created at {content_index_path}")
    except Exception as e:
        self.logger.error(f"Error creating content index: {str(e)}")
        raise


def clear_temp_files(base_path, logger):
    logger.info("Clearing temporary files")
    temp_dir = os.path.join(base_path, 'temp')
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)


def update_file_permissions(base_path, logger):
    logger.info("Updating file permissions")
    for root, dirs, files in os.walk(base_path):
        for dir in dirs:
            os.chmod(os.path.join(root, dir), 0o755)
        for file in files:
            os.chmod(os.path.join(root, file), 0o644)


def verify_critical_components(base_path, logger):
    logger.info("Verifying integrity of critical components")
    critical_files = [
        'EagleXRGB_Connector.exe',
        'EagleXRGB_Updater.py',
        'EagleXRGB_Server_Config.py',
    ]
    for file in critical_files:
        file_path = os.path.join(base_path, file)
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Critical file not found: {file}")


def run_version_specific_updates(base_path, logger):
    logger.info("Running version-specific updates")
    updates_dir = os.path.join(base_path, 'version_updates')
    if os.path.exists(updates_dir):
        for update_script in sorted(os.listdir(updates_dir)):
            if update_script.endswith('.py'):
                script_path = os.path.join(updates_dir, update_script)
                logger.info(f"Running update script: {script_path}")
                try:
                    subprocess.run([sys.executable, script_path], check=True)
                except subprocess.CalledProcessError as e:
                    logger.error(f"Error running update script {script_path}: {str(e)}")
                    raise


def update_last_update_timestamp(base_path, logger):
    logger.info("Updating last update timestamp")
    timestamp_file = os.path.join(base_path, 'last_update.txt')
    with open(timestamp_file, 'w') as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S"))


def update_folder(base_path, temp_dir, folder_info, logger):
    src = os.path.join(temp_dir, folder_info['path'])
    dest = os.path.join(base_path, folder_info['path'])
    try:
        if folder_info['action'] == 'merge':
            merge_folders(src, dest, folder_info.get('ignore_patterns', []), logger)
        elif folder_info['action'] == 'replace':
            if os.path.exists(dest):
                safe_remove(dest, logger)
            safe_copy(src, dest, folder_info.get('ignore_patterns', []), logger)
        elif folder_info['action'] == 'selective_update':
            selective_update_folder(base_path, temp_dir, folder_info, logger)
        logger.info(f"Updated folder: {folder_info['path']}")
    except Exception as e:
        logger.error(f"Failed to update folder {folder_info['path']}: {str(e)}")
        raise


def merge_folders(src, dest, ignore_patterns, logger):
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dest, item)
        if any(fnmatch.fnmatch(item, pattern) for pattern in ignore_patterns):
            logger.info(f"Skipping {item} due to ignore pattern")
            continue
        if os.path.isdir(s):
            if not os.path.exists(d):
                os.makedirs(d)
            merge_folders(s, d, ignore_patterns, logger)
        else:
            safe_copy(s, d, [], logger)


def remove_obsolete(base_path, manifest, logger):
    write_progress(base_path, 'remove', 0, "Removing obsolete files and folders...", 75, "Applying updates")
    total_items = len(manifest.get('files_to_remove', [])) + len(manifest.get('folders_to_remove', []))
    current_item = 0

    for file_path in manifest.get('files_to_remove', []):
        full_path = os.path.join(base_path, file_path)
        if os.path.exists(full_path):
            os.remove(full_path)
            logger.info(f"Removed obsolete file: {file_path}")
        current_item += 1
        progress = int((current_item / total_items) * 100)
        write_progress(base_path, 'remove', progress, f"Removing obsolete items: {progress}%", 75 + progress * 0.1,
                       "Applying updates")

    for folder_path in manifest.get('folders_to_remove', []):
        full_path = os.path.join(base_path, folder_path)
        if os.path.exists(full_path):
            shutil.rmtree(full_path)
            logger.info(f"Removed obsolete folder: {folder_path}")
        current_item += 1
        progress = int((current_item / total_items) * 100)
        write_progress(base_path, 'remove', progress, f"Removing obsolete items: {progress}%", 75 + progress * 0.1,
                       "Applying updates")


def update_version_info(base_path, manifest, logger):
    write_progress(base_path, 'version', 0, "Updating version information...", 85, "Applying updates")
    version_file = os.path.join(base_path, 'EagleXRGB_version_client.json')

    try:
        # Get the version of the main application (EagleXRGB_Connector.exe)
        main_app_path = os.path.join(base_path, 'EagleXRGB_Connector.exe')
        main_app_version = get_file_version(main_app_path)

        # Get the version of the updater (EagleXRGB_Updater.exe)
        updater_path = os.path.join(base_path, 'EagleXRGB_Updater.exe')
        updater_version = get_file_version(updater_path)

        # If we couldn't get the versions from the files, use the ones from the manifest
        if main_app_version is None:
            main_app_version = manifest.get('version', 'Unknown')
            logger.warning(f"Couldn't get version from {main_app_path}. Using manifest version: {main_app_version}")

        if updater_version is None:
            updater_version = manifest.get('updater_version', 'Unknown')
            logger.warning(f"Couldn't get version from {updater_path}. Using manifest version: {updater_version}")

        version_info = {
            "version": main_app_version,
            "updater_version": updater_version
        }

        with open(version_file, 'w') as f:
            json.dump(version_info, f, indent=2)

        logger.info(
            f"Updated version information: Main app version: {main_app_version}, Updater version: {updater_version}")
        write_progress(base_path, 'version', 100, "Version information updated", 90, "Applying updates")
    except Exception as e:
        logger.error(f"Error updating version information: {str(e)}")
        write_progress(base_path, 'error', 100, f"Error updating version information: {str(e)}", 90, "Update failed")
        raise


def verify_file_integrity(file_path, expected_hash):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    calculated_hash = sha256_hash.hexdigest()
    return calculated_hash == expected_hash


def verify_update(base_path, manifest, logger):
    logger.info("Verifying update...")
    write_progress(base_path, 'verify', 0, "Starting update verification...", 90, "Verifying update")
    try:
        total_files = len(manifest['files_to_update'])
        for i, file_info in enumerate(manifest['files_to_update']):
            file_path = os.path.join(base_path, file_info['path'])
            if not os.path.exists(file_path):
                logger.error(f"Updated file not found: {file_path}")
                return False
            if 'hash' in file_info:
                if not verify_file_integrity(file_path, file_info['hash']):
                    logger.error(f"File integrity check failed: {file_path}")
                    return False
            progress = int((i + 1) / total_files * 100)
            write_progress(base_path, 'verify', progress, f"Verifying files: {progress}%", 90 + progress * 0.05,
                           "Verifying update")
        logger.info("Update verification completed successfully")
        write_progress(base_path, 'verify', 100, "Update verification completed", 95, "Verifying update")
        return True
    except Exception as e:
        logger.error(f"Error during update verification: {str(e)}")
        write_progress(base_path, 'error', 100, f"Error during update verification: {str(e)}", 95,
                       "Verification failed")
        return False


def cleanup(base_path, temp_dir, logger):
    logger.info("Starting cleanup process")
    write_progress(base_path, 'cleanup', 0, "Starting cleanup...", 95, "Cleaning up")
    try:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
            logger.info(f"Removed temporary directory: {temp_dir}")
        write_progress(base_path, 'cleanup', 50, "Removed temporary directory", 97, "Cleaning up")

        bootstrap_info_file = os.path.join(base_path, 'bootstrap_info.json')
        if os.path.exists(bootstrap_info_file):
            os.remove(bootstrap_info_file)
            logger.info(f"Removed bootstrap info file: {bootstrap_info_file}")
        write_progress(base_path, 'cleanup', 100, "Cleanup completed", 99, "Cleaning up")
        logger.info("Cleanup process completed successfully")
    except Exception as e:
        logger.error(f"Error during cleanup: {str(e)}", exc_info=True)
        write_progress(base_path, 'error', 100, f"Error during cleanup: {str(e)}", 99, "Cleanup failed")


def backup_current_version(self):
    self.report_progress(40, "Backing up current version...")
    try:
        if self.backup_dir.exists():
            shutil.rmtree(self.backup_dir)
        shutil.copytree(self.base_path, self.backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_update_temp', 'EagleXRGB_backup'))
        self.logger.info(f"Backup created successfully at {self.backup_dir}")
    except Exception as e:
        self.logger.error(f"Failed to create backup: {str(e)}")
        raise


def rollback(base_path, backup_dir, logger):
    logger.info("Starting rollback process")
    write_progress(base_path, 'rollback', 0, "Starting rollback...", 0, "Rolling back update")
    try:
        if not os.path.exists(backup_dir):
            logger.error("Backup directory not found. Unable to rollback.")
            return False

        preserve_items = ['EagleXRGB_update_temp', 'EagleXRGB_backup', 'logs']

        total_items = len(os.listdir(base_path)) + len(os.listdir(backup_dir))
        current_item = 0

        for item in os.listdir(base_path):
            if item not in preserve_items:
                item_path = os.path.join(base_path, item)
                if not safe_remove(item_path, logger):
                    logger.warning(f"Failed to remove {item_path} during rollback")
            current_item += 1
            progress = int((current_item / total_items) * 50)
            write_progress(base_path, 'rollback', progress, f"Removing updated files: {progress}%", progress,
                           "Rolling back update")

        for item in os.listdir(backup_dir):
            src = os.path.join(backup_dir, item)
            dest = os.path.join(base_path, item)
            if not safe_copy(src, dest, [], logger):  # Empty list for ignore_patterns
                logger.warning(f"Failed to restore {src} to {dest} during rollback")
            current_item += 1
            progress = 50 + int((current_item / total_items) * 50)
            write_progress(base_path, 'rollback', progress, f"Restoring backup files: {progress}%", progress,
                           "Rolling back update")

        logger.info("Rollback completed successfully")
        write_progress(base_path, 'rollback', 100, "Rollback completed", 100, "Update rolled back")
        return True
    except Exception as e:
        logger.error(f"Error during rollback: {str(e)}", exc_info=True)
        write_progress(base_path, 'error', 100, f"Error during rollback: {str(e)}", 100, "Rollback failed")
        return False


def restart_main_application(base_path, logger):
    try:
        main_app = os.path.join(base_path, 'EagleXRGB_Connector.exe')
        subprocess.Popen([main_app], creationflags=subprocess.DETACHED_PROCESS)
        logger.info("Main application restarted")
        write_progress(base_path, 'restart', 100, "Main application restarted", 100, "Update complete")
        return True
    except Exception as e:
        logger.error(f"Failed to restart main application: {str(e)}")
        write_progress(base_path, 'error', 100, f"Failed to restart main application: {str(e)}", 100, "Restart failed")
        return False


def final_cleanup(base_path, temp_dir, logger):
    logger.info("Starting final cleanup process")
    try:
        # Remove temporary directory
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
            logger.info(f"Removed temporary directory: {temp_dir}")

        # Remove bootstrap info file
        bootstrap_info_file = os.path.join(base_path, 'bootstrap_info.json')
        if os.path.exists(bootstrap_info_file):
            os.remove(bootstrap_info_file)
            logger.info(f"Removed bootstrap info file: {bootstrap_info_file}")

        # Remove update info file
        update_info_file = os.path.join(base_path, 'update_info.json')
        if os.path.exists(update_info_file):
            os.remove(update_info_file)
            logger.info(f"Removed update info file: {update_info_file}")

        # Remove progress file
        progress_file = os.path.join(base_path, 'update_progress.json')
        if os.path.exists(progress_file):
            os.remove(progress_file)
            logger.info(f"Removed progress file: {progress_file}")

        logger.info("Final cleanup process completed successfully")
    except Exception as e:
        logger.error(f"Error during final cleanup: {str(e)}", exc_info=True)


def main():
    if len(sys.argv) != 2:
        print("Usage: EagleXRGB_BootstrapUpdater.py <bootstrap_info_file>")
        return 1

    try:
        bootstrap_info_file = sys.argv[1]
        print(f"Starting bootstrap update process with info file: {bootstrap_info_file}")

        with open(bootstrap_info_file, 'r') as f:
            bootstrap_info = json.load(f)

        base_path = bootstrap_info['base_path']
        temp_dir = bootstrap_info['temp_dir']
        manifest = bootstrap_info['manifest']

        logger = setup_logging(base_path)
        logger.info("Bootstrap updater started")
        logger.info(f"Base path: {base_path}")
        logger.info(f"Temp directory: {temp_dir}")
        logger.info(f"Manifest version: {manifest.get('version', 'Unknown')}")

        app = QApplication(sys.argv)
        splash_screen = EpicSplashScreen()
        splash_screen.show()

        update_splash_screen(splash_screen, 'start', 0, "Bootstrap updater started", 0, "Initializing update")

        if not wait_for_main_app_to_close(logger, base_path, splash_screen):
            logger.error("Failed to close main application")
            update_splash_screen(splash_screen, 'error', 100, "Failed to close main application", 5, "Update failed")
            QMessageBox.critical(None, "Update Error",
                                 "The update process cannot continue because the main application is still running. Please close EagleXRGB_Connector.exe manually and try updating again.")
            QTimer.singleShot(3000, app.quit)
            return app.exec_()

        logger.info("Creating backup...")
        update_splash_screen(splash_screen, 'backup', 0, "Creating backup...", 5, "Preparing update")
        backup_dir = os.path.join(base_path, 'EagleXRGB_backup')
        shutil.copytree(base_path, backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_update_temp', 'EagleXRGB_backup', 'logs'))
        logger.info(f"Backup created at {backup_dir}")
        update_splash_screen(splash_screen, 'backup', 100, "Backup created", 10, "Preparing update")

        logger.info("Applying updates...")
        if apply_updates(base_path, temp_dir, manifest, logger):
            logger.info("Updates applied successfully")
            update_version_info(base_path, manifest, logger)  # Add this line
            update_splash_screen(splash_screen, 'verify', 0, "Verifying update...", 80, "Verifying update")
            if verify_update(base_path, manifest, logger):
                logger.info("Update verification successful")
                update_splash_screen(splash_screen, 'cleanup', 0, "Cleaning up...", 90, "Cleaning up")
                cleanup(base_path, temp_dir, logger)
                final_cleanup(base_path, temp_dir, logger)
                update_splash_screen(splash_screen, 'cleanup', 100, "Cleanup completed", 95, "Cleanup completed")

                if restart_main_application(base_path, logger):
                    logger.info("Update process completed successfully")
                    update_splash_screen(splash_screen, 'complete', 100, "Update completed successfully", 100,
                                         "Update complete")
                    QTimer.singleShot(3000, app.quit)
                    return app.exec_()
                else:
                    logger.error("Failed to restart main application")
                    update_splash_screen(splash_screen, 'error', 100, "Failed to restart main application", 100,
                                         "Update failed")
                    QTimer.singleShot(3000, app.quit)
                    return app.exec_()
            else:
                logger.error("Update verification failed")
                update_splash_screen(splash_screen, 'error', 100, "Update verification failed", 95, "Update failed")
                if rollback(base_path, backup_dir, logger):
                    logger.info("Rollback completed")
                    update_splash_screen(splash_screen, 'rollback', 100, "Rollback completed", 100,
                                         "Update rolled back")
                else:
                    logger.error("Rollback failed")
                    update_splash_screen(splash_screen, 'error', 100, "Rollback failed", 100, "Critical error")
                QTimer.singleShot(3000, app.quit)
                return app.exec_()
        else:
            logger.error("Update process failed")
            update_splash_screen(splash_screen, 'error', 100, "Update process failed", 70, "Update failed")
            if rollback(base_path, backup_dir, logger):
                logger.info("Rollback completed")
                update_splash_screen(splash_screen, 'rollback', 100, "Rollback completed", 100, "Update rolled back")
            else:
                logger.error("Rollback failed")
                update_splash_screen(splash_screen, 'error', 100, "Rollback failed", 100, "Critical error")
            QTimer.singleShot(3000, app.quit)
            return app.exec_()
    except Exception as e:
        logger.exception("Unexpected error in bootstrap updater")
        if 'splash_screen' in locals():
            update_splash_screen(splash_screen, 'error', 100, f"Unexpected error: {str(e)}", 100, "Critical error")
            QTimer.singleShot(3000, app.quit)
            return app.exec_()
        else:
            print(f"An unexpected error occurred: {str(e)}")
            return 3
    finally:
        # Ensure final cleanup is always attempted
        if 'base_path' in locals() and 'temp_dir' in locals() and 'logger' in locals():
            final_cleanup(base_path, temp_dir, logger)


if __name__ == "__main__":
    exit_code = main()
    print(f"Bootstrap updater exiting with code: {exit_code}")
    sys.exit(exit_code)
