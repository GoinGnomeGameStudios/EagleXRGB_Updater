import os
import sys
import json
import shutil
import logging
import time
import zipfile
import subprocess
import psutil
import requests
from PyQt5.QtGui import QIcon, QImageReader
from PyQt5.QtWidgets import QApplication, QMessageBox, QStyle, QWidget
from PyQt5.QtCore import QThread, pyqtSignal, QTimer
from requests import RequestException

from EagleXRGB_splash_screen import SplashScreen
from EagleXRGB_version_utils import get_updater_version


class UpdaterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EagleXRGB Auto Updater")
        self.setWindowIcon(self.get_icon('eaglex-openrgb-connector-icon'))

    def get_icon(self, icon_name):
        icon_paths = [
            os.path.join(os.path.dirname(sys.executable), 'icons', f'{icon_name}.png'),
            os.path.join(os.path.dirname(sys.executable), f'{icon_name}.png'),
            os.path.join(os.path.dirname(__file__), 'icons', f'{icon_name}.png'),
            os.path.join(os.path.dirname(__file__), f'{icon_name}.png')
        ]

        for icon_path in icon_paths:
            if os.path.exists(icon_path):
                logging.info(f"Loading icon from path: {icon_path}")
                icon = QIcon(icon_path)
                if not icon.isNull():
                    logging.info(f"Successfully loaded icon: {icon_name}")
                    return icon

        logging.warning(f"Failed to load icon: {icon_name}, using fallback")
        return self.style().standardIcon(QStyle.SP_FileIcon)

    def verify_icon_files(self):
        logging.info("Verifying icon files:")
        possible_icon_dirs = [
            os.path.join(os.path.dirname(sys.executable), 'icons'),
            os.path.join(os.path.dirname(__file__), 'icons')
        ]

        for icons_dir in possible_icon_dirs:
            if os.path.exists(icons_dir):
                logging.info(f"Icons directory found: {icons_dir}")
                for filename in os.listdir(icons_dir):
                    if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                        file_path = os.path.join(icons_dir, filename)
                        file_size = os.path.getsize(file_path)
                        reader = QImageReader(file_path)
                        if reader.canRead():
                            image_size = reader.size()
                            logging.info(
                                f"Icon file: {filename}, Size: {file_size} bytes, Dimensions: {image_size.width()}x{image_size.height()}")
                        else:
                            logging.warning(f"Cannot read image file: {filename}, Size: {file_size} bytes")
                return

        logging.error("Icons directory not found in any expected location")


class UpdaterThread(QThread):
    update_progress = pyqtSignal(int, str)
    update_completed = pyqtSignal(bool, str)

    def __init__(self, updater):
        super().__init__()
        self.updater = updater

    def run(self):
        try:
            self.updater.apply_update(self.update_progress)
            self.update_completed.emit(True, "Update completed successfully.")
        except Exception as e:
            logging.error(f"Error during update: {str(e)}", exc_info=True)
            self.update_completed.emit(False, f"Update failed: {str(e)}")


 # Define the updater version


class Updater:
    def __init__(self, update_info_path):
        self.setup_logging()
        with open(update_info_path, 'r') as f:
            self.update_info = json.load(f)
        self.base_path = os.path.dirname(self.update_info['main_exe_path'])
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.main_exe = os.path.basename(self.update_info['main_exe_path'])
        self.updater_exe = 'EagleXRGB_Auto_updater.exe'  # Define the updater executable name
        self.update_package = self.update_info['update_package']
        self.updater_version = get_updater_version()

    @staticmethod
    def get_updater_version():
        return get_updater_version()

    def setup_logging(self):
        log_file = os.path.join(os.path.dirname(sys.executable), 'updater.log')
        logging.basicConfig(filename=log_file, level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def wait_for_process_to_end(self, timeout=30):
        start_time = time.time()
        while time.time() - start_time < timeout:
            if not any(proc.name() == self.main_exe for proc in psutil.process_iter(['name'])):
                return True
            time.sleep(1)
        return False

    def force_close_main_app(self):
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == self.main_exe:
                logging.info(f"Attempting to close {self.main_exe} (PID: {proc.pid})")
                try:
                    proc.terminate()
                    proc.wait(timeout=10)
                except psutil.TimeoutExpired:
                    logging.warning(f"Termination timed out, forcing closure of {self.main_exe}")
                    proc.kill()
                except Exception as e:
                    logging.error(f"Error closing {self.main_exe}: {str(e)}")

    def download_update(self, progress_callback):
        try:
            new_version = self.update_info['new_version']
            update_package_name = f"EagleXRGB_update_package_{new_version}.zip"
            update_url = f"{self.update_info['update_url']}/{update_package_name}"

            logging.info(f"Attempting to download update package from: {update_url}")

            response = requests.get(update_url, stream=True, timeout=30)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, update_package_name)

            total_size = int(response.headers.get('content-length', 0))
            logging.info(f"Total download size: {total_size} bytes")

            block_size = 8192
            downloaded = 0

            with open(package_path, 'wb') as f:
                for data in response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        progress_callback.emit(progress, f"Downloading update... {progress}%")
                    logging.debug(f"Downloaded {downloaded} of {total_size} bytes")

            if downloaded == total_size or total_size == 0:
                logging.info(f"Update package '{update_package_name}' downloaded successfully")
                return True
            else:
                logging.error(f"Download incomplete. Expected {total_size}, got {downloaded} bytes")
                return False

        except RequestException as e:
            logging.error(f"Network error while downloading update: {str(e)}")
            return False
        except Exception as e:
            logging.error(f"Unexpected error during download: {str(e)}")
            return False

    def apply_update(self, progress_callback):
        try:
            # Step 1: Ensure main application is closed
            progress_callback.emit(0, f"Closing {self.main_exe}...")
            logging.info(f"Attempting to close {self.main_exe}")
            self.force_close_main_app()

            # Step 2: Extract the update package
            progress_callback.emit(50, "Extracting update package...")
            logging.info("Extracting update package...")
            if not os.path.exists(self.update_package):
                raise FileNotFoundError(f"Update package not found: {self.update_package}")

            with zipfile.ZipFile(self.update_package, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)
            progress_callback.emit(60, "Update package extracted")

            # Log the contents of the temp directory
            logging.info("Contents of temp directory after extraction:")
            for root, dirs, files in os.walk(self.temp_dir):
                for file in files:
                    logging.info(os.path.join(root, file))

            # Step 3: Extract the update package
            progress_callback.emit(50, "Extracting update package...")
            logging.info("Extracting update package...")
            package_path = os.path.join(self.temp_dir, 'update_package.zip')
            if not os.path.exists(package_path):
                raise FileNotFoundError(f"Update package not found: {package_path}")

            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)
            progress_callback.emit(60, "Update package extracted")

            # Log the contents of the temp directory
            logging.info("Contents of temp directory after extraction:")
            for root, dirs, files in os.walk(self.temp_dir):
                for file in files:
                    logging.info(os.path.join(root, file))

            # Step 4: Read the update manifest
            progress_callback.emit(65, "Reading update manifest...")
            logging.info("Reading update manifest...")
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            if not os.path.exists(manifest_path):
                raise FileNotFoundError(f"Update manifest not found: {manifest_path}")

            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
            logging.info(f"Manifest content: {json.dumps(manifest, indent=2)}")

            # Step 5: Update files and folders
            progress_callback.emit(70, "Updating files and folders...")
            logging.info("Updating files and folders...")
            self.update_files_and_folders(manifest, progress_callback)

            # Step 6: Update executables
            progress_callback.emit(90, "Updating executables...")
            logging.info("Updating executables...")
            self.update_executables(manifest)

            # Step 7: Update local version file
            progress_callback.emit(95, "Updating version information...")
            logging.info("Updating version information...")
            self.update_local_version_file()

            # Step 8: Clean up
            progress_callback.emit(98, "Cleaning up...")
            logging.info("Cleaning up...")
            self.clean_up()

            # Final step: Signal completion
            self.signal_completion()
            logging.info("Update applied successfully.")
            progress_callback.emit(100, "Update completed successfully")
        except Exception as e:
            logging.error(f"Error applying update: {str(e)}", exc_info=True)
            raise

    def update_executables(self, manifest):
        for item in manifest.get('files_to_update', []):
            if item['path'] == self.main_exe:
                self.update_main_executable()

    def update_main_executable(self):
        src = os.path.join(self.temp_dir, self.main_exe)
        dst = self.update_info['main_exe_path']
        if os.path.exists(src):
            self.safe_file_operation(shutil.copy2, src, dst)
            logging.info(f"Updated main executable: {dst}")
        else:
            logging.error(f"Main executable not found in update package: {src}")

    def update_updater_executable(self):
        src = os.path.join(self.temp_dir, self.updater_exe)
        dst = os.path.join(self.base_path, self.updater_exe)
        if os.path.exists(src):
            self.safe_file_operation(shutil.copy2, src, dst)
            logging.info(f"Updated updater executable: {dst}")
        else:
            logging.error(f"Updater executable not found in update package: {src}")

    def signal_completion(self):
        completion_flag = os.path.join(self.base_path, 'update_complete.flag')
        self.safe_file_operation(self._write_json, completion_flag, {"status": "complete", "temp_dir": self.temp_dir})

    def update_files_and_folders(self, manifest, progress_callback):
        try:
            total_items = len(manifest.get('files_to_update', [])) + len(manifest.get('folders_to_update', []))
            current_item = 0

            for item in manifest.get('files_to_update', []):
                try:
                    self.update_file(item)
                except Exception as e:
                    logging.error(f"Error updating file {item['path']}: {str(e)}")
                current_item += 1
                progress = 70 + int((current_item / total_items) * 20)
                progress_callback.emit(progress, f"Updating file: {item['path']}")

            for item in manifest.get('folders_to_update', []):
                try:
                    self.update_folder(item)
                except Exception as e:
                    logging.error(f"Error updating folder {item['path']}: {str(e)}")
                current_item += 1
                progress = 70 + int((current_item / total_items) * 20)
                progress_callback.emit(progress, f"Updating folder: {item['path']}")

        except Exception as e:
            logging.error(f"Error in update_files_and_folders: {str(e)}", exc_info=True)
            raise

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        logging.info(f"Updating file: {file_info['path']}")
        logging.info(f"Source: {src}")
        logging.info(f"Destination: {dst}")

        if not os.path.exists(src):
            logging.error(f"Source file not found: {src}")
            return  # Skip this file and continue with others

        if file_info['action'] == 'replace' or not os.path.exists(dst):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            self.safe_file_operation(shutil.copy2, src, dst)
            logging.info(f"File updated: {dst}")
        elif file_info['action'] == 'create_if_not_exists':
            if not os.path.exists(dst):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                self.safe_file_operation(shutil.copy2, src, dst)
                logging.info(f"File created: {dst}")
            else:
                logging.info(f"File already exists, skipping: {dst}")

    def safe_file_operation(self, operation, *args, max_attempts=5, delay=2):
        for attempt in range(max_attempts):
            try:
                return operation(*args)
            except PermissionError as e:
                if attempt < max_attempts - 1:
                    logging.warning(f"Permission error, retrying in {delay} seconds: {str(e)}")
                    time.sleep(delay)
                else:
                    raise

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        logging.info(f"Updating folder: {folder_info['path']}")
        logging.info(f"Source: {src}")
        logging.info(f"Destination: {dst}")

        if folder_info['action'] == 'merge':
            self.merge_folders(src, dst)
        elif folder_info['action'] == 'replace':
            if os.path.exists(dst):
                self.safe_file_operation(shutil.rmtree, dst)
            self.safe_file_operation(shutil.copytree, src, dst)
            logging.info(f"Replaced folder: {dst}")
        elif folder_info['action'] == 'create_if_not_exists':
            if not os.path.exists(dst):
                self.safe_file_operation(shutil.copytree, src, dst)
                logging.info(f"Created folder: {dst}")
            else:
                logging.info(f"Folder already exists, skipping: {dst}")

    def merge_folders(self, src, dst):
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                self.merge_folders(s, d)
            else:
                self.safe_file_operation(shutil.copy2, s, d)
                logging.info(f"Copied file: {d}")

    def update_local_version_file(self):
        new_version_info = {
            "latest_version": self.update_info['new_version'],
            "update_date": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        self.safe_file_operation(self._write_json, self.version_file, new_version_info)
        logging.info(f"Updated local version file to version {self.update_info['new_version']}")

    def _write_json(self, file_path, data):
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)

    def verify_update(self):
        if not os.path.exists(self.update_info['main_exe_path']):
            raise Exception("Main executable not found after update")
        if not os.path.exists(self.version_file):
            raise Exception("Version file not found after update")

        # Check the version of the updated executable
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                result = subprocess.run([self.update_info['main_exe_path'], '--version'],
                                        capture_output=True, text=True, timeout=10)
                updated_version = result.stdout.strip()
                if updated_version != self.update_info['new_version']:
                    raise Exception(
                        f"Version mismatch after update. Expected {self.update_info['new_version']}, got {updated_version}")
                logging.info(f"Verified updated version: {updated_version}")
                return  # Successful verification
            except subprocess.TimeoutExpired:
                logging.warning(
                    f"Timeout while checking updated executable version (attempt {attempt + 1}/{max_attempts})")
            except Exception as e:
                logging.error(
                    f"Error checking updated executable version (attempt {attempt + 1}/{max_attempts}): {str(e)}")

            if attempt < max_attempts - 1:
                time.sleep(2)  # Wait before retrying

        raise Exception("Failed to verify the updated executable version after multiple attempts")

    def remove_specified_folders(self, manifest):
        folders_to_remove = manifest.get('folders_to_remove', [])
        for folder in folders_to_remove:
            folder_path = os.path.join(self.base_path, folder)
            if os.path.exists(folder_path):
                try:
                    shutil.rmtree(folder_path)
                    logging.info(f"Removed folder: {folder_path}")
                except Exception as e:
                    logging.error(f"Failed to remove folder {folder_path}: {str(e)}")

    def clean_up(self):
        try:
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
                logging.info(f"Removed temporary directory: {self.temp_dir}")
        except Exception as e:
            logging.error(f"Failed to remove temporary directory {self.temp_dir}: {str(e)}")


def setup_logging():
    logging.basicConfig(filename='update_check.log', level=logging.DEBUG,
                        format='%(asctime)s - %(levelname)s - %(message)s')


def main():
    if len(sys.argv) > 1 and sys.argv[1] == '--version':
        print(get_updater_version())
        return
    setup_logging()
    logging.info("Updater started")
    logging.info(f"Python version: {sys.version}")
    logging.info(f"Arguments: {sys.argv}")

    app = QApplication(sys.argv)

    if len(sys.argv) < 2:
        logging.error("No update info provided")
        return

    update_info_path = sys.argv[1]
    logging.info(f"Update info path: {update_info_path}")

    # Log the contents of the update info file
    with open(update_info_path, 'r') as f:
        update_info = json.load(f)
    logging.info(f"Update info contents: {json.dumps(update_info, indent=2)}")

    splash = SplashScreen()
    splash.show()

    updater = Updater(update_info_path)
    updater_thread = UpdaterThread(updater)

    def update_progress(value, status):
        splash.update_progress(value, status)
        logging.info(f"Update progress: {value}% - {status}")

    def update_completed(success, message):
        if success:
            splash.show_update_info("Update complete. Restarting application...")
            logging.info("Update completed successfully. Restarting main application.")
            QTimer.singleShot(2000, lambda: restart_main_app(updater.update_info['main_exe_path']))
        else:
            splash.show_update_info("Update failed. Please try again.")
            logging.error(f"Update failed: {message}")
            QMessageBox.critical(None, "Update Failed", message)
            QTimer.singleShot(2000, app.quit)

    def restart_main_app(main_exe_path):
        logging.info(f"Attempting to restart main application: {main_exe_path}")
        try:
            subprocess.Popen([main_exe_path, '--post-update'])
            logging.info("Main application restart initiated with --post-update flag.")
        except Exception as e:
            logging.error(f"Failed to restart main application: {str(e)}", exc_info=True)
        finally:
            QApplication.instance().quit()

    updater_thread.update_progress.connect(update_progress)
    updater_thread.update_completed.connect(update_completed)
    updater_thread.start()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
