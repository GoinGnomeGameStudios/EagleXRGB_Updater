from PyQt5.QtWidgets import QSplashScreen, QProgressBar, QLabel, QVBoxLayout, QWidget
from PyQt5.QtGui import QImage, QPixmap, QFont, QPainter, QColor, QLinearGradient, QPen, QRadialGradient, QBrush
from PyQt5.QtCore import QRectF, Qt, pyqtSignal, QRect, QPoint, QSize, QTimer, QPropertyAnimation, QEasingCurve, \
    pyqtProperty
import math


class EpicSplashScreen(QSplashScreen):
    update_signal = pyqtSignal(str, int, str, int, str)

    def __init__(self, font_size=10, bar_height=20, is_bold=False, show_holographic_lines=True):
        super().__init__(QPixmap(QSize(800, 600)))
        self.setWindowFlag(Qt.WindowStaysOnTopHint)

        self.logo = QPixmap("images/EagleXRGB_openrgb-connector-splash_screen.png")
        self.font_size = font_size
        self.bar_height = bar_height
        self.is_bold = is_bold
        self.show_holographic_lines = show_holographic_lines

        self.angle = 0
        self._glow_opacity = 0

        # Holographic lines configuration
        self.holo_lines_start_y = 300  # Starting Y position of the first line
        self.holo_lines_count = 5     # Number of lines
        self.holo_lines_spacing = 20  # Spacing between lines

        # Create UI elements
        self.create_ui_elements()

        # Animation setup
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animation)
        self.animation_timer.start(50)  # Update every 50ms

        self.glow_animation = QPropertyAnimation(self, b"glow_opacity")
        self.glow_animation.setDuration(2000)
        self.glow_animation.setStartValue(0)
        self.glow_animation.setEndValue(100)
        self.glow_animation.setEasingCurve(QEasingCurve.InOutQuad)
        self.glow_animation.setLoopCount(-1)
        self.glow_animation.start()

        self.update_signal.connect(self.update_all)

    def create_ui_elements(self):
        layout = QVBoxLayout()
        font = QFont()
        font.setPointSize(self.font_size)
        font.setBold(self.is_bold)

        self.status_label = self.create_label("Initializing...", font)
        self.download_progress = self.create_progress_bar()
        self.download_label = self.create_label("Download Progress: 0%", font)
        self.update_progress = self.create_progress_bar()
        self.update_label = self.create_label("Update Progress: 0%", font)

        layout.addWidget(self.status_label)
        layout.addWidget(self.download_progress)
        layout.addWidget(self.download_label)
        layout.addWidget(self.update_progress)
        layout.addWidget(self.update_label)

        widget = QWidget(self)
        widget.setLayout(layout)
        widget.setGeometry(50, 400, 700, 180)

        self.download_progress.hide()
        self.download_label.hide()
        self.update_progress.hide()
        self.update_label.hide()

    def create_label(self, text, font):
        label = QLabel(text)
        label.setAlignment(Qt.AlignCenter)
        label.setFont(font)
        label.setStyleSheet("color: #00ffff; background-color: transparent;")
        return label

    def create_progress_bar(self):
        progress_bar = QProgressBar(self)
        progress_bar.setAlignment(Qt.AlignCenter)
        progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid #00ffff;
                border-radius: 5px;
                background-color: rgba(0, 0, 0, 100);
                text-align: center;
                height: {self.bar_height}px;
            }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #007fff, stop:1 #00ffff);
                border-radius: 3px;
            }}
        """)
        return progress_bar

    def update_status(self, message):
        self.status_label.setText(message)
        self.repaint()

    def update_download_progress(self, value):
        self.download_progress.setValue(value)
        self.download_label.setText(f"Download Progress: {value}%")
        self.download_progress.show()
        self.download_label.show()
        self.update_progress.hide()
        self.update_label.hide()
        self.repaint()

    def update_update_progress(self, value):
        self.update_progress.setValue(value)
        self.update_label.setText(f"Update Progress: {value}%")
        self.update_progress.show()
        self.update_label.show()
        self.download_progress.hide()
        self.download_label.hide()
        self.repaint()

    def update_all(self, task, value, status, overall_progress, overall_status):
        self.status_label.setText(overall_status)
        if task == "download":
            self.update_download_progress(value)
        elif task == "update":
            self.update_update_progress(value)
        self.repaint()

    def update_splash_screen(self, task, progress, message, overall_progress, overall_status):
        self.update_signal.emit(task, progress, message, overall_progress, overall_status)

    def update_animation(self):
        self.angle += 5
        if self.angle >= 360:
            self.angle = 0
        self.repaint()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Create futuristic background
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(10, 10, 30))
        gradient.setColorAt(1, QColor(30, 30, 60))
        painter.fillRect(self.rect(), gradient)

        # Draw animated hexagon pattern
        self.draw_hexagon_pattern(painter)

        # Draw glowing effect
        self.draw_glow_effect(painter)

        # Draw holographic lines if enabled
        if self.show_holographic_lines:
            self.draw_holographic_lines(painter)

        # Draw logo
        self.draw_logo(painter)

        painter.end()

    def draw_holographic_lines(self, painter):
        painter.setPen(QPen(QColor(0, 255, 255, 50), 2))  # Slightly increased opacity
        for i in range(self.holo_lines_count):
            y = self.holo_lines_start_y + i * self.holo_lines_spacing
            painter.drawLine(0, y, self.width(), y)

    def set_holographic_lines_config(self, start_y, count, spacing):
        self.holo_lines_start_y = start_y
        self.holo_lines_count = count
        self.holo_lines_spacing = spacing
        self.repaint()

    def draw_glow_effect(self, painter):
        logo_x = (self.width() - self.logo.width()) // 2
        logo_y = 50

        # Calculate the center of the logo
        center_x = logo_x + self.logo.width() // 2
        center_y = logo_y + self.logo.height() // 2

        # Set glow size to be slightly larger than the logo
        glow_size = max(self.logo.width(), self.logo.height()) * 1.2

        # Create a rectangle for the glow, centered on the logo
        glow_rect = QRectF(
            center_x - glow_size / 2,
            center_y - glow_size / 2,
            glow_size,
            glow_size
        )

        gradient = QRadialGradient(glow_rect.center(), glow_size / 2)
        gradient.setColorAt(0, QColor(0, 255, 255, self._glow_opacity))
        gradient.setColorAt(0.5, QColor(0, 255, 255, self._glow_opacity // 2))
        gradient.setColorAt(1, QColor(0, 255, 255, 0))

        painter.setBrush(QBrush(gradient))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(glow_rect)

    def draw_hexagon_pattern(self, painter):
        hex_color = QColor(0, 255, 255, 20)
        painter.setPen(QPen(hex_color, 1))

        hex_size = 30
        for i in range(-hex_size, self.width() + hex_size, hex_size * 2):
            for j in range(-hex_size, self.height() + hex_size, hex_size * 3):
                offset = hex_size if (j // (hex_size * 3)) % 2 == 0 else 0
                self.draw_hexagon(painter, i + offset, j, hex_size)

    def draw_logo(self, painter):
        logo_x = (self.width() - self.logo.width()) // 2
        logo_y = 50
        painter.drawPixmap(logo_x, logo_y, self.logo)

    def draw_hexagon(self, painter, x, y, size):
        points = []
        for i in range(6):
            angle = (self.angle + i * 60) * math.pi / 180
            point_x = int(x + size * math.cos(angle))
            point_y = int(y + size * math.sin(angle))
            points.append(QPoint(point_x, point_y))
        painter.drawPolygon(*points)

    def draw_glowing_logo(self, painter):
        logo_x = (self.width() - self.logo.width()) // 2
        logo_y = 50

        # Create a separate image for the glow effect
        glow_image = QImage(self.logo.size() + QSize(40, 40), QImage.Format_ARGB32_Premultiplied)
        glow_image.fill(Qt.transparent)

        glow_painter = QPainter(glow_image)
        glow_painter.setRenderHint(QPainter.Antialiasing)

        # Create a radial gradient for the glow
        gradient = QRadialGradient(glow_image.rect().center(), glow_image.width() / 2)
        gradient.setColorAt(0, QColor(0, 255, 255, self._glow_opacity))
        gradient.setColorAt(1, QColor(0, 255, 255, 0))

        # Draw the glow
        glow_painter.setBrush(gradient)
        glow_painter.setPen(Qt.NoPen)
        glow_painter.drawEllipse(glow_image.rect())
        glow_painter.end()

        # Draw the glow image
        painter.drawImage(QRectF(logo_x - 20, logo_y - 20,
                                 self.logo.width() + 40, self.logo.height() + 40),
                          glow_image)

        # Draw the logo on top
        painter.drawPixmap(logo_x, logo_y, self.logo)

    def get_glow_opacity(self):
        return self._glow_opacity

    def set_glow_opacity(self, value):
        self._glow_opacity = value
        self.repaint()

    glow_opacity = pyqtProperty(int, get_glow_opacity, set_glow_opacity)
