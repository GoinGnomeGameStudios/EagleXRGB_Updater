import os
import json
import requests
import zipfile
import shutil
import logging
from packaging import version

class AutoUpdater:
    def __init__(self, app_path, update_url):
        self.app_path = app_path
        self.update_url = update_url
        self.temp_dir = os.path.join(app_path, 'temp_update')
        logging.basicConfig(filename='update_log.txt', level=logging.INFO)

    def check_for_updates(self):
        try:
            response = requests.get(f"{self.update_url}/EagleXRGB_version.json")
            response.raise_for_status()
            version_info = response.json()
            latest_version = version.parse(version_info['latest_version'])
            current_version = version.parse(self.get_current_version())
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")
            return latest_version > current_version, version_info
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        version_file = os.path.join(self.app_path, 'EagleXRGB_version.json')
        if os.path.exists(version_file):
            with open(version_file, 'r') as f:
                return json.load(f)['latest_version']
        return "0.0.0"  # Default version if file doesn't exist

    def download_update(self, version_info):
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)

        try:
            # Download the manifest
            manifest_url = f"{self.update_url}/{version_info['manifest']}"
            logging.info(f"Downloading manifest from: {manifest_url}")
            manifest_response = requests.get(manifest_url)
            manifest_response.raise_for_status()

            with open(os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json'), 'wb') as f:
                f.write(manifest_response.content)

            # Download the update package
            update_url = f"{self.update_url}/{version_info['update_package']}"
            logging.info(f"Downloading update package from: {update_url}")
            update_response = requests.get(update_url)
            update_response.raise_for_status()

            with open(os.path.join(self.temp_dir, 'update_package.zip'), 'wb') as f:
                f.write(update_response.content)

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def apply_update(self):
        try:
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            zip_path = os.path.join(self.temp_dir, 'update_package.zip')

            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)

            # Update files
            for file in manifest['files_to_update']:
                src = os.path.join(self.temp_dir, file)
                dst = os.path.join(self.app_path, file)
                shutil.copy2(src, dst)
                logging.info(f"Updated file: {file}")

            # Update folders
            for folder in manifest['folders_to_update']:
                src = os.path.join(self.temp_dir, folder)
                dst = os.path.join(self.app_path, folder)
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
                logging.info(f"Updated folder: {folder}")

            # Remove files
            for file in manifest['files_to_remove']:
                file_path = os.path.join(self.app_path, file)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    logging.info(f"Removed file: {file}")

            # Remove folders
            for folder in manifest['folders_to_remove']:
                folder_path = os.path.join(self.app_path, folder)
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
                    logging.info(f"Removed folder: {folder}")

            # Clean up
            shutil.rmtree(self.temp_dir)
            logging.info("Update applied successfully")
            return True
        except Exception as e:
            logging.error(f"Error applying update: {e}")
            return False

    def update_process(self):
        update_available, version_info = self.check_for_updates()
        if update_available:
            if self.download_update(version_info):
                if self.apply_update():
                    logging.info("Update process completed successfully")
                    return True
                else:
                    logging.error("Failed to apply update")
            else:
                logging.error("Failed to download update")
        else:
            logging.info("No update available")
        return False