import os
import sys
import win32api
import json
import requests
from packaging import version

FALLBACK_APP_VERSION = "8.3.3"
FALLBACK_UPDATER_VERSION = "1.1.5"
base_update_url = "https://goingnomegamestudios.github.io/EagleXRGB_Updater"


def get_base_path():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.abspath(__file__))


def get_local_version():
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    version_file = os.path.join(base_path, 'logs', 'EagleXRGB_version_client.json')
    try:
        with open(version_file, 'r') as f:
            data = json.load(f)
        return data.get('version', FALLBACK_APP_VERSION), data.get('updater_version', FALLBACK_UPDATER_VERSION)
    except (FileNotFoundError, json.JSONDecodeError):
        return FALLBACK_APP_VERSION, FALLBACK_UPDATER_VERSION


def get_file_version(file_path):
    try:
        info = win32api.GetFileVersionInfo(file_path, "\\")
        ms = info['FileVersionMS']
        ls = info['FileVersionLS']
        return f"{win32api.HIWORD(ms)}.{win32api.LOWORD(ms)}.{win32api.HIWORD(ls)}.{win32api.LOWORD(ls)}"
    except Exception as e:
        print(f"Error getting file version: {e}")
        return None


def get_current_version():
    local_version, _ = get_local_version()
    if getattr(sys, 'frozen', False):
        file_version = get_file_version(sys.executable)
        return file_version if file_version else local_version
    return local_version


def get_updater_version():
    _, updater_version = get_local_version()
    updater_path = os.path.join(get_base_path(), 'EagleXRGB_Updater.exe')
    file_version = get_file_version(updater_path)
    return file_version if file_version else updater_version


def get_latest_version():
    try:
        response = requests.get(f"{base_update_url}/EagleXRGB_version_server.json")
        response.raise_for_status()
        version_info = response.json()
        return version_info.get('latest_version')
    except requests.RequestException as e:
        print(f"Error fetching latest version: {e}")
        return None

def compare_versions(version1, version2):
    v1 = version.parse(version1)
    v2 = version.parse(version2)
    if v1 > v2:
        return 1
    elif v1 < v2:
        return -1
    else:
        return 0


def is_update_available():
    current_version = get_current_version()
    current_updater_version = get_updater_version()
    latest_version, latest_updater_version = get_latest_version()

    if latest_version is None or latest_updater_version is None:
        return False

    return (compare_versions(latest_version, current_version) > 0 or
            compare_versions(latest_updater_version, current_updater_version) > 0)


def get_update_info():
    try:
        response = requests.get(f"{base_update_url}/EagleXRGB_version_server.json")
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Error fetching update information: {e}")
        return None


if __name__ == "__main__":
    print(f"Current version: {get_current_version()}")
    print(f"Current updater version: {get_updater_version()}")
    latest_version, latest_updater_version = get_latest_version()
    print(f"Latest version: {latest_version}")
    print(f"Latest updater version: {latest_updater_version}")
    print(f"Update available: {is_update_available()}")
    print(f"Update info: {get_update_info()}")
