import logging
import os
import smtplib
import traceback
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import json

from EagleXRGB_version_utils import get_base_path


def send_error_report(error_report):
    # Option 1: Send via email
    send_error_email(error_report)

    # Option 2: Send to a central server
    send_error_to_server(error_report)


def send_error_email(error_report):
    sender_email = "your-email@example.com"
    receiver_email = "developer@example.com"
    password = "your-email-password"  # It's better to use environment variables for sensitive information

    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = f"EagleXRGB Updater Error Report - Version {error_report['current_version']}"

    body = f"""
    Error occurred during update process:

    Timestamp: {error_report['timestamp']}
    Current Version: {error_report['current_version']}
    Target Version: {error_report['target_version']}
    Error Message: {error_report['error_message']}

    Traceback:
    {error_report['traceback']}
    """

    message.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())
        logging.info("Error report email sent successfully")
    except Exception as e:
        logging.error(f"Failed to send error report email: {str(e)}")


def send_error_to_server(error_report):
    server_url = "https://your-error-reporting-server.com/api/error-report"

    try:
        response = requests.post(server_url, json=error_report)
        response.raise_for_status()
        logging.info("Error report sent to server successfully")
    except requests.RequestException as e:
        logging.error(f"Failed to send error report to server: {str(e)}")


# Update the report_error method in the Updater class
def report_error(self, error):
    error_report = {
        "timestamp": datetime.now().isoformat(),
        "current_version": self.current_version,
        "target_version": self.latest_version,
        "error_message": str(error),
        "traceback": traceback.format_exc()
    }
    error_file = os.path.join(get_base_path(), 'logs', 'error_report.json')
    with open(error_file, 'w') as f:
        json.dump(error_report, f, indent=2)
    logging.info(f"Error report saved to: {error_file}")

    # Send the error report
    send_error_report(error_report)