import logging
import os
import sys
from logging.handlers import RotatingFileHandler

import win32api
import json
import requests
from packaging import version


def setup_logging():
    base_path = os.path.dirname(sys.executable)
    log_dir = os.path.join(base_path, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, 'EagleXRGB_version_utils.log')

    log_handler = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=5)
    log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    log_handler.setFormatter(log_formatter)

    logger = logging.getLogger('EagleXRGB_version_utils')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(log_handler)

    # Add a stream handler for console output
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)
    logger.addHandler(console_handler)

    return logger


logger = setup_logging()

FALLBACK_APP_VERSION = "8.3.5"
FALLBACK_UPDATER_VERSION = "1.1.7"
base_update_url = "https://goingnomegamestudios.github.io/EagleXRGB_Updater"


def get_base_path():
    if getattr(sys, 'frozen', False):
        # If the application is run as a bundle, the PyInstaller bootloader
        # extends the sys module by a flag frozen=True and sets the app
        # path into variable _MEIPASS'.
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # Ensure we're not in the '_internal' directory
    if os.path.basename(base_path) == '_internal':
        base_path = os.path.dirname(base_path)

    return base_path


def get_local_version():
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    version_file = os.path.join(base_path, 'logs', 'EagleXRGB_version_client.json')
    try:
        with open(version_file, 'r') as f:
            data = json.load(f)
        return data.get('version', FALLBACK_APP_VERSION), data.get('updater_version', FALLBACK_UPDATER_VERSION)
    except (FileNotFoundError, json.JSONDecodeError):
        return FALLBACK_APP_VERSION, FALLBACK_UPDATER_VERSION


def get_file_version(file_path):
    try:
        info = win32api.GetFileVersionInfo(file_path, "\\")
        ms = info['FileVersionMS']
        ls = info['FileVersionLS']
        return f"{win32api.HIWORD(ms)}.{win32api.LOWORD(ms)}.{win32api.HIWORD(ls)}.{win32api.LOWORD(ls)}"
    except Exception as e:
        print(f"Error getting file version: {e}")
        return None


def get_current_version():
    version_file = os.path.join(get_base_path(), 'EagleXRGB_version_client.json')
    try:
        with open(version_file, 'r') as f:
            data = json.load(f)
        return data.get('version', FALLBACK_APP_VERSION)
    except Exception:
        return FALLBACK_APP_VERSION


def get_updater_version():
    version_file = os.path.join(get_base_path(), 'EagleXRGB_version_client.json')
    try:
        with open(version_file, 'r') as f:
            data = json.load(f)
        return data.get('updater_version', FALLBACK_UPDATER_VERSION)
    except Exception:
        return FALLBACK_UPDATER_VERSION


def get_latest_version():
    try:
        response = requests.get(f"{base_update_url}/EagleXRGB_version_server.json", timeout=10)
        response.raise_for_status()
        data = response.json()
        logger.info(f"Server response: {data}")

        latest_version = data.get('latest_version')
        if latest_version is None:
            raise KeyError("'latest_version' not found in server response")

        latest_updater_version = data.get('updater_version', FALLBACK_UPDATER_VERSION)
        if 'updater_version' not in data:
            logger.warning("'updater_version' not found in server response. Using fallback version.")

        logger.info(f"Parsed latest version info: version={latest_version}, updater_version={latest_updater_version}")
        return latest_version, latest_updater_version
    except requests.RequestException as e:
        logger.error(f"Error fetching latest version: {e}")
        return None, None
    except (KeyError, json.JSONDecodeError) as e:
        logger.error(f"Error parsing latest version data: {e}")
        return None, None


def compare_versions(version1, version2):
    v1 = version.parse(version1)
    v2 = version.parse(version2)
    if v1 > v2:
        return 1
    elif v1 < v2:
        return -1
    else:
        return 0


def is_update_available():
    current_version = get_current_version()
    current_updater_version = get_updater_version()
    latest_version, latest_updater_version = get_latest_version()

    if latest_version is None or latest_updater_version is None:
        return False

    return (compare_versions(latest_version, current_version) > 0 or
            compare_versions(latest_updater_version, current_updater_version) > 0)


def get_update_info():
    try:
        # Fetch the server version info
        response = requests.get(f"{base_update_url}/EagleXRGB_version_server.json")
        response.raise_for_status()
        server_info = response.json()

        # Fetch the update metadata
        metadata_response = requests.get(f"{base_update_url}/update_metadata.json")
        metadata_response.raise_for_status()
        metadata = metadata_response.json()

        # Create update_info dictionary
        update_info = {
            'latest_version': server_info['latest_version'],
            'updater_version': server_info['updater_version'],
            'release_notes': server_info['release_notes'],
            'package_url': f"{base_update_url}/{server_info['update_package']}",
            'manifest_url': f"{base_update_url}/{server_info['manifest']}",
            'package_hash': metadata['package_hash'],
            'signature_url': metadata['signature_url'],
            'current_version': get_current_version(),
            'current_updater_version': get_updater_version(),
            'update_url': base_update_url  # Add this line to include the update_url
        }

        # Check for required keys
        required_keys = ['latest_version', 'package_url', 'package_hash', 'signature_url', 'update_url']
        missing_required = [key for key in required_keys if key not in update_info or update_info[key] is None]
        if missing_required:
            logger.error(f"Missing required keys in update_info: {', '.join(missing_required)}")
            return None

        logger.info(f"Successfully retrieved update info: {json.dumps(update_info, indent=2)}")
        return update_info
    except requests.RequestException as e:
        logger.error(f"Network error while fetching update info: {str(e)}")
    except json.JSONDecodeError as e:
        logger.error(f"Error decoding JSON from server response: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error while fetching update info: {str(e)}")

    return None


def get_version_info():
    current_version = get_current_version()
    current_updater_version = get_updater_version()
    latest_version, latest_updater_version = get_latest_version()

    if latest_version is None:
        logger.warning("Unable to fetch latest version. Using current version as latest.")
        latest_version = current_version
        latest_updater_version = current_updater_version

    return {
        'current_version': current_version,
        'latest_version': latest_version,
        'update_url': base_update_url,
        'base_path': get_base_path(),
        'current_updater_version': current_updater_version,
        'latest_updater_version': latest_updater_version
    }


if __name__ == "__main__":
    logger = setup_logging()
    version_info = get_version_info()
    print("Version Information:")
    for key, value in version_info.items():
        print(f"{key}: {value}")
    print(f"Update available: {is_update_available()}")
    print(f"Update info: {get_update_info()}")
