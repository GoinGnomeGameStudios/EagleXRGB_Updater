import base64
import os
import sys
import tempfile
import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry


def get_base_path():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


# Add the bundled Python's site-packages to sys.path
base_path = get_base_path()
python_embedded_dir = os.path.join(base_path, 'python_embedded')
site_packages = os.path.join(python_embedded_dir, 'Lib', 'site-packages')

# Add the base path and site-packages to sys.path
sys.path.insert(0, base_path)
sys.path.insert(0, site_packages)

# Now import the required modules
import ctypes
import hashlib
import importlib
import json
import logging
import shutil
import sqlite3
import subprocess
import time
import traceback
import zipfile
from datetime import datetime
from fnmatch import fnmatch
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict

import psutil
import win32event
import win32api
import winerror
from PyQt5.QtCore import QObject, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import QApplication, QMessageBox, QProgressDialog
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from packaging import version
from importlib import metadata

# Now import your custom modules
from EagleXRGB_version_utils import (FALLBACK_UPDATER_VERSION, base_update_url, compare_versions, get_base_path,
                                     get_current_version,
                                     get_file_version, get_latest_version,
                                     get_local_version, get_update_info, get_updater_version, get_version_info)


def setup_logging(base_path):
    log_dir = Path(base_path) / 'logs'
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / 'EagleXRGB_BootstrapUpdater.log'

    logger = logging.getLogger('EagleXRGB_BootstrapUpdater')
    logger.setLevel(logging.DEBUG)

    file_handler = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=3)
    file_handler.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


logger = setup_logging(get_base_path())


class Updater(QObject):
    update_progress = pyqtSignal(int, str)
    update_error = pyqtSignal(str)
    update_complete = pyqtSignal(bool, str)
    bootstrap_ready = pyqtSignal()

    def __init__(self, update_info):
        super().__init__()
        self.updater_process = None
        self.progress_timer = None
        self.update_info = update_info
        self.base_path = get_base_path()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update_temp')
        self.backup_dir = os.path.join(self.base_path, 'EagleXRGB_backup')
        self.progress_file = os.path.join(tempfile.gettempdir(), 'EagleXRGB_update_progress.json')

        self.logger = self.setup_logging()
        self.logger.info("Updater initialized")

        self.public_key = self.load_public_key()
        self.latest_version = self.update_info.get('latest_version')
        self.current_version = self.update_info.get('current_version')
        self.update_url = self.update_info.get('update_url')

    def setup_logging(self):
        logger = logging.getLogger('EagleXRGB_Updater')
        logger.setLevel(logging.DEBUG)
        log_file = os.path.join(self.base_path, 'logs', 'Updater.log')
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        handler = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=3)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def write_progress(self, task, progress, message, overall_progress, overall_status):
        progress_data = {
            'task': task,
            'progress': progress,
            'message': message,
            'overall_progress': overall_progress,
            'overall_status': overall_status
        }
        try:
            with open(self.progress_file, 'w') as f:
                json.dump(progress_data, f)
            self.logger.info(f"Progress: {overall_progress}% - {overall_status}")
        except Exception as e:
            self.logger.error(f"Error writing progress file: {str(e)}")
            # Attempt to write to a fallback location
            fallback_file = os.path.join(os.path.expanduser('~'), 'EagleXRGB_update_progress.json')
            try:
                with open(fallback_file, 'w') as f:
                    json.dump(progress_data, f)
                self.logger.info(f"Progress written to fallback location: {fallback_file}")
            except Exception as e:
                self.logger.error(f"Error writing to fallback progress file: {str(e)}")

    def run_update(self):
        try:
            self.logger.info(f"Starting update process. Base path: {self.base_path}")
            self.write_progress('update', 0, "Starting update process...", 0, "Starting update")

            # Dump public key contents
            self.dump_public_key()

            self.logger.info("Downloading manifest...")
            self.write_progress('manifest', 0, "Downloading Manifest...", 5, "Downloading Manifest")
            manifest_path = self.download_manifest()
            self.logger.info(f"Manifest downloaded to: {manifest_path}")

            self.logger.info("Downloading update package...")
            self.write_progress('download', 0, "Downloading update package...", 10, "Downloading update")
            package_path = self.download_update_package()
            self.logger.info(f"Update package downloaded to: {package_path}")

            self.logger.info("Downloading update package...")
            self.write_progress('download', 0, "Downloading update package...", 10, "Downloading update")
            package_path = self.download_update_package()
            self.logger.info(f"Update package downloaded to: {package_path}")

            # Compare downloaded file with original file (if available)
            original_package_path = os.path.join(self.base_path, f"EagleXRGB_update_package_{self.latest_version}.zip")
            if os.path.exists(original_package_path):
                self.logger.info("Comparing downloaded package with original package")
                if self.compare_files(package_path, original_package_path):
                    self.logger.info("Downloaded package matches original package")
                else:
                    self.logger.error("Downloaded package does not match original package")
                    raise ValueError("Package integrity check failed")

            self.logger.info("Verifying update package...")
            self.write_progress('verify', 0, "Verifying update package...", 30, "Verifying update")

            python_verification = self.verify_update_package(package_path)
            self.logger.info(f"Python verification result: {'Success' if python_verification else 'Failure'}")

            openssl_verification = self.verify_with_openssl(
                package_path,
                f"{package_path}.sig",
                os.path.join(self.base_path, '_internal', 'public_key.pem')
            )
            self.logger.info(f"OpenSSL verification result: {'Success' if openssl_verification else 'Failure'}")

            if not (python_verification or openssl_verification):
                pure_python_verification = self.verify_with_pure_python(
                    package_path,
                    self.load_signature(package_path),
                    self.load_public_key()
                )
                self.logger.info(
                    f"Pure Python verification result: {'Success' if pure_python_verification else 'Failure'}")

                if not pure_python_verification:
                    raise ValueError("Update package verification failed")

            self.logger.info("Update package verified successfully")

            self.logger.info("Extracting update package...")
            self.write_progress('extract', 0, "Extracting update package...", 50, "Extracting update")
            self.extract_update_package(package_path)
            self.logger.info(f"Update package extracted to {self.temp_dir}")

            self.logger.info("Preparing for bootstrap update...")
            bootstrap_info_path = self.prepare_for_bootstrap()
            self.logger.info(f"Bootstrap info saved to: {bootstrap_info_path}")

            self.update_progress.emit(100, "Update preparation completed. Ready for bootstrap.")
            self.logger.info("Update preparation completed. Ready for bootstrap.")

            # Signal that we're ready for bootstrap
            self.bootstrap_ready.emit()

            # Launch bootstrap updater
            return self.launch_bootstrap_updater(bootstrap_info_path)

        except Exception as e:
            self.logger.error(f"Update failed: {str(e)}", exc_info=True)
            self.update_error.emit(f"Update failed: {str(e)}")
            return False


    def launch_bootstrap_updater(self, bootstrap_info_path):
        python_exe = os.path.join(self.base_path, 'python_embedded', 'python.exe')
        updater_script = os.path.join(self.base_path, '_internal', 'EagleXRGB_BootstrapUpdater.py')

        self.logger.info(f"Python executable path: {python_exe}")
        self.logger.info(f"Updater script path: {updater_script}")
        self.logger.info(f"Bootstrap info path: {bootstrap_info_path}")

        if not all(os.path.exists(path) for path in [python_exe, updater_script, bootstrap_info_path]):
            missing_files = [path for path in [python_exe, updater_script, bootstrap_info_path] if not os.path.exists(path)]
            self.logger.error(f"Required files for bootstrap update are missing: {', '.join(missing_files)}")
            return False

        command = [python_exe, updater_script, bootstrap_info_path]

        self.logger.info(f"Launching bootstrap updater: {' '.join(command)}")

        try:
            process = subprocess.Popen(command,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE,
                                       universal_newlines=True,
                                       creationflags=subprocess.CREATE_NO_WINDOW)

            self.logger.info(f"Bootstrap updater launched with PID: {process.pid}")

            stdout, stderr = process.communicate(timeout=300)  # Wait for up to 5 minutes
            self.logger.info(f"Bootstrap updater stdout:\n{stdout}")
            if stderr:
                self.logger.error(f"Bootstrap updater stderr:\n{stderr}")

            if process.returncode != 0:
                self.logger.error(f"Bootstrap updater exited with non-zero return code: {process.returncode}")
                return False
            else:
                self.logger.info("Bootstrap updater completed successfully")
                self.cleanup_after_update()
                return True

        except subprocess.TimeoutExpired:
            self.logger.error("Bootstrap updater process timed out")
            process.kill()
            stdout, stderr = process.communicate()
            self.logger.info(f"Partial bootstrap updater stdout:\n{stdout}")
            if stderr:
                self.logger.error(f"Partial bootstrap updater stderr:\n{stderr}")
            return False
        except Exception as e:
            self.logger.error(f"Error launching bootstrap updater: {str(e)}", exc_info=True)
            return False

    def cleanup_after_update(self):
        try:
            # Remove backup directory
            if os.path.exists(self.backup_dir):
                shutil.rmtree(self.backup_dir)
                self.logger.info(f"Removed backup directory: {self.backup_dir}")

            # Remove temporary update directory
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
                self.logger.info(f"Removed temporary update directory: {self.temp_dir}")

            # Remove bootstrap info file
            bootstrap_info_path = os.path.join(self.base_path, 'bootstrap_info.json')
            if os.path.exists(bootstrap_info_path):
                os.remove(bootstrap_info_path)
                self.logger.info(f"Removed bootstrap info file: {bootstrap_info_path}")

            # Remove update info file
            update_info_path = os.path.join(self.base_path, 'update_info.json')
            if os.path.exists(update_info_path):
                os.remove(update_info_path)
                self.logger.info(f"Removed update info file: {update_info_path}")

            self.logger.info("Cleanup after update completed successfully")
        except Exception as e:
            self.logger.error(f"Error during cleanup after update: {str(e)}", exc_info=True)

    def prepare_for_bootstrap(self):
        self.logger.info("Preparing for bootstrap update...")

        # Load the manifest
        manifest_path = os.path.join(self.temp_dir, 'update_manifest.json')
        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
        else:
            self.logger.error("Manifest file not found in the update package")
            raise FileNotFoundError("Manifest file not found")

        # Focus only on updating Python scripts in the _internal folder
        allowed_scripts = [
            'EagleXRGB_BootstrapUpdater.py',
            'EagleXRGB_custom_widgets.py',
            'EagleXRGB_Error_Reporting.py',
            'EagleXRGB_GUI_Config.py',
            'EagleXRGB_notifications.py',
            'EagleXRGB_Server_Config.py',
            'EagleXRGB_splash_screen.py',
            'EagleXRGB_Updater.py',
            'EagleXRGB_UpdaterElevator.py',
            'EagleXRGB_version_utils.py',
            'EagleXRGB_UI_Components.py'
        ]

        manifest['folders_to_update'] = [
            {
                'path': '_internal',
                'action': 'selective_update',
                'update_details': [
                    {
                        'category': 'custom_scripts',
                        'files': [
                            {'path': script, 'action': 'replace_if_flagged'}
                            for script in allowed_scripts
                        ]
                    }
                ]
            }
        ]

        # Remove any other folders or files from the update
        manifest['files_to_update'] = [
            file for file in manifest.get('files_to_update', [])
            if file['path'] in ['EagleXRGB_Connector.exe', 'EagleXRGB_Updater.exe', 'EagleXRGB_version_client.json']
        ]

        bootstrap_info = {
            'base_path': self.base_path,
            'temp_dir': self.temp_dir,
            'manifest': manifest
        }

        bootstrap_info_path = os.path.join(self.base_path, 'bootstrap_info.json')
        with open(bootstrap_info_path, 'w') as f:
            json.dump(bootstrap_info, f, indent=2)

        self.logger.info(f"Bootstrap info saved to: {bootstrap_info_path}")
        return bootstrap_info_path

    def report_progress(self, progress, status):
        self.logger.info(f"Progress: {progress}% - {status}")
        self.update_progress.emit(progress, status)

    def fetch_and_verify_update_package(self):
        self.update_progress.emit(10, "Fetching update package...")
        self.server_info = self.fetch_server_info()
        package_path = self.download_update_package()
        self.verify_update_package(package_path)

    def fetch_server_info(self):
        try:
            response = requests.get(f"{self.update_url}/EagleXRGB_version_server.json")
            response.raise_for_status()
            server_info = response.json()
            self.logger.info(f"Fetched server info: {json.dumps(server_info, indent=2)}")
            return server_info
        except Exception as e:
            self.logger.error(f"Error fetching server info: {str(e)}")
            raise

    def download_manifest(self):
        manifest_url = self.update_info['manifest_url']
        manifest_path = os.path.join(self.temp_dir, 'update_manifest.json')
        os.makedirs(self.temp_dir, exist_ok=True)
        response = requests.get(manifest_url)
        response.raise_for_status()
        with open(manifest_path, 'wb') as f:
            f.write(response.content)
        return manifest_path

    def download_update_package(self):
        package_url = self.update_info['package_url']
        package_path = os.path.join(self.temp_dir, f"EagleXRGB_update_package_{self.latest_version}.zip")
        signature_url = f"{package_url}.sig"
        signature_path = f"{package_path}.sig"

        self.logger.info(f"Downloading update package from {package_url} to {package_path}")
        self._download_file(package_url, package_path, "update package")

        self.logger.info(f"Downloading signature from {signature_url} to {signature_path}")
        self._download_file(signature_url, signature_path, "signature")

        return package_path

    def _download_file(self, url, path, file_type):
        response = requests.get(url, stream=True)
        response.raise_for_status()
        total_size = int(response.headers.get('content-length', 0))
        self.logger.info(f"Expected {file_type} size: {total_size} bytes")

        os.makedirs(os.path.dirname(path), exist_ok=True)
        downloaded_size = 0
        with open(path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded_size += len(chunk)
                    progress = int((downloaded_size / total_size) * 100) if total_size > 0 else 0
                    self.write_progress('download', progress, f"Downloading {file_type}: {progress}%",
                                        10 + progress * 0.2,
                                        f"Downloading {file_type}")

        self.logger.info(f"Download completed. Actual file size: {os.path.getsize(path)} bytes")

    def verify_update_package(self, package_path):
        self.logger.info(f"Starting package verification for: {package_path}")

        if not os.path.exists(package_path):
            self.logger.error(f"Package file does not exist: {package_path}")
            return False

        file_size = os.path.getsize(package_path)
        self.logger.info(f"Package file size: {file_size} bytes")

        # Hash verification
        self.write_progress('verify', 0, "Verifying package hash...", 30, "Verifying update")
        calculated_hash = self.calculate_file_hash(package_path)
        expected_hash = self.update_info.get('package_hash')
        self.logger.info(f"Calculated hash: {calculated_hash}")
        self.logger.info(f"Expected hash: {expected_hash}")
        if calculated_hash != expected_hash:
            self.logger.error("Package hash verification failed")
            return False

        # Signature verification
        self.write_progress('verify', 50, "Verifying package signature...", 40, "Verifying update")
        signature = self.load_signature(package_path)
        if signature is None:
            return False

        public_key = self.load_public_key()
        if public_key is None:
            return False

        self.logger.info(f"Signature length: {len(signature)} bytes")
        self.logger.info(f"Signature (base64): {base64.b64encode(signature).decode()}")
        self.logger.info(f"Public key type: {type(public_key).__name__}")

        try:
            with open(package_path, "rb") as f:
                package_data = f.read()
            self.logger.info(f"Package data loaded, size: {len(package_data)} bytes")
            self.logger.info(f"Package data hash: {self.calculate_file_hash(package_path)}")

            self.logger.info("Starting signature verification with PKCS1v15 padding")
            public_key.verify(
                signature,
                package_data,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            self.logger.info("Package signature verified successfully")
            self.write_progress('verify', 100, "Package verified successfully", 50, "Verifying update")
            return True
        except InvalidSignature:
            self.logger.error("Signature verification failed: Invalid signature")
        except Exception as e:
            self.logger.error(f"Signature verification failed: Unexpected error - {str(e)}")
            self.logger.error(f"Error type: {type(e).__name__}")
            self.logger.error(f"Error details: {traceback.format_exc()}")
        return False

    def calculate_file_hash(self, file_path):
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def recreate_signature(self, package_data, public_key):
        self.logger.info("Attempting to recreate signature locally")
        try:
            # Extract the public numbers from the public key
            public_numbers = public_key.public_numbers()

            # Recreate the private key (this is just for testing, never do this in production!)
            private_key = rsa.RSAPrivateNumbers(
                p=1, q=1, d=1, dmp1=1, dmq1=1, iqmp=1,
                public_numbers=public_numbers
            ).private_key()

            # Sign the package data
            signature = private_key.sign(
                package_data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            self.logger.info(f"Recreated signature (base64): {base64.b64encode(signature).decode()}")
        except Exception as e:
            self.logger.error(f"Error recreating signature: {str(e)}")

    def verify_with_openssl(self, package_path, signature_path, public_key_path):
        self.logger.info("Attempting verification with OpenSSL")

        if not shutil.which("openssl"):
            self.logger.error("OpenSSL is not installed or not in the system PATH")
            return False

        try:
            cmd = [
                "openssl", "dgst", "-sha256", "-verify", public_key_path,
                "-signature", signature_path, package_path
            ]
            self.logger.info(f"OpenSSL command: {' '.join(cmd)}")

            result = subprocess.run(cmd, capture_output=True, text=True)
            self.logger.info(f"OpenSSL stdout: {result.stdout}")
            self.logger.info(f"OpenSSL stderr: {result.stderr}")

            if "Verified OK" in result.stdout:
                self.logger.info("OpenSSL verification succeeded")
                return True
            else:
                self.logger.error("OpenSSL verification failed")
                return False
        except Exception as e:
            self.logger.error(f"Error during OpenSSL verification: {str(e)}")
            self.logger.error(f"Error details: {traceback.format_exc()}")
            return False

    def verify_with_pure_python(self, package_path, signature, public_key):
        self.logger.info("Attempting verification with pure Python RSA")
        try:
            with open(package_path, "rb") as f:
                package_data = f.read()

            # Extract public key components
            n = public_key.public_numbers().n
            e = public_key.public_numbers().e

            # Convert signature to integer
            sig_int = int.from_bytes(signature, byteorder='big')

            # Perform RSA verification
            m = pow(sig_int, e, n)
            em = m.to_bytes((m.bit_length() + 7) // 8, byteorder='big')

            # PKCS#1 v1.5 padding removal and verification
            if em[0:2] == b'\x00\x01':
                ps_end = em.index(b'\x00', 2)
                if ps_end > 10:
                    t = em[ps_end + 1:]
                    if t[:15] == b'\x30\x31\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x01\x05\x00\x04\x20':
                        h = t[19:]
                        if h == hashlib.sha256(package_data).digest():
                            self.logger.info("Pure Python RSA verification succeeded")
                            return True

            self.logger.error("Pure Python RSA verification failed")
            return False
        except Exception as e:
            self.logger.error(f"Error during pure Python RSA verification: {str(e)}")
            return False

    def load_public_key(self):
        key_path = os.path.join(self.base_path, '_internal', 'public_key.pem')
        self.logger.info(f"Loading public key from: {key_path}")
        try:
            with open(key_path, "rb") as key_file:
                public_key = serialization.load_pem_public_key(key_file.read())
            self.logger.info(f"Public key loaded successfully, type: {type(public_key).__name__}")
            return public_key
        except FileNotFoundError:
            self.logger.error(f"Public key file not found: {key_path}")
        except ValueError as e:
            self.logger.error(f"Invalid public key data: {str(e)}")
        except Exception as e:
            self.logger.error(f"Failed to load public key: {str(e)}")
        return None

    def dump_public_key(self):
        key_path = os.path.join(self.base_path, '_internal', 'public_key.pem')
        self.logger.info(f"Dumping contents of public key file: {key_path}")
        try:
            with open(key_path, "r") as key_file:
                key_contents = key_file.read()
            self.logger.info(f"Public key contents:\n{key_contents}")
        except Exception as e:
            self.logger.error(f"Error dumping public key contents: {str(e)}")

    def load_signature(self, package_path):
        signature_path = f"{package_path}.sig"
        self.logger.info(f"Loading signature from: {signature_path}")
        if not os.path.exists(signature_path):
            self.logger.error(f"Signature file does not exist: {signature_path}")
            return None
        try:
            with open(signature_path, 'rb') as f:
                signature = f.read()
            self.logger.info(f"Loaded signature, length: {len(signature)} bytes")
            return signature
        except Exception as e:
            self.logger.error(f"Error loading signature file: {str(e)}")
            return None

    def compare_files(self, file1_path, file2_path):
        self.logger.info(f"Comparing files: {file1_path} and {file2_path}")
        if not os.path.exists(file1_path) or not os.path.exists(file2_path):
            self.logger.error("One or both files do not exist")
            return False

        with open(file1_path, 'rb') as f1, open(file2_path, 'rb') as f2:
            while True:
                chunk1 = f1.read(4096)
                chunk2 = f2.read(4096)
                if chunk1 != chunk2:
                    self.logger.error("Files are different")
                    return False
                if not chunk1:
                    break
        self.logger.info("Files are identical")
        return True

    def verify_package_hash(self, package_path):
        sha256_hash = hashlib.sha256()
        with open(package_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        calculated_hash = sha256_hash.hexdigest()
        return calculated_hash == self.server_info['package_hash']

    def verify_package_signature(self, package_path):
        signature_path = os.path.join(self.temp_dir, self.server_info['signature'])
        with open(signature_path, "rb") as sig_file:
            signature = sig_file.read()
        with open(package_path, "rb") as package_file:
            package_data = package_file.read()
        try:
            self.public_key.verify(
                signature,
                package_data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except InvalidSignature:
            return False

    def get_update_info(self):
        try:
            response = requests.get(f"{self.update_url}/update_metadata.json")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            self.logger.error(f"Error fetching update info: {str(e)}")
            raise

    def is_update_needed(self, latest_version, latest_updater_version):
        current_version = get_current_version()
        current_updater_version = get_updater_version()
        logging.info(f"Comparing versions - Current: {current_version}, Latest: {latest_version}")
        logging.info(
            f"Comparing updater versions - Current: {current_updater_version}, Latest: {latest_updater_version}")
        return (latest_version > current_version) or (latest_updater_version > current_updater_version)

    def is_newer_version(self, new_version):
        return version.parse(new_version) > version.parse(self.current_version)

    def download_and_verify_update(self, update_info):
        try:
            self.progress_signal.emit(20, "Downloading update package...")
            package_url = f"{self.update_url}/{update_info['update_package']}"
            package_response = requests.get(package_url)
            package_response.raise_for_status()
            package_data = package_response.content

            # Verify package hash (assuming the hash is provided in the update info)
            if 'package_hash' in update_info:
                calculated_hash = hashlib.sha256(package_data).hexdigest()
                if calculated_hash != update_info['package_hash']:
                    raise ValueError("Package hash verification failed")

            # Verify signature (assuming the signature is provided)
            if 'signature' in update_info:
                signature = update_info['signature']
                public_key = self.load_public_key()
                try:
                    public_key.verify(
                        signature,
                        package_data,
                        padding.PSS(
                            mgf=padding.MGF1(hashes.SHA256()),
                            salt_length=padding.PSS.MAX_LENGTH
                        ),
                        hashes.SHA256()
                    )
                except InvalidSignature:
                    raise ValueError("Signature verification failed")

            # Save the package
            package_path = os.path.join(self.temp_dir, update_info['update_package'])
            os.makedirs(self.temp_dir, exist_ok=True)
            with open(package_path, "wb") as f:
                f.write(package_data)

            return package_path
        except Exception as e:
            self.logger.error(f"Error downloading or verifying update: {str(e)}")
            return None

    def verify_signature(self, package_data, signature):
        try:
            self.public_key.verify(
                signature,
                package_data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except InvalidSignature:
            return False

    def load_manifest(self):
        self.logger.info("Loading update manifest")
        manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest_server.json')
        with open(manifest_path, 'r') as f:
            self.manifest = json.load(f)
        self.logger.info("Update manifest loaded successfully")

    def extract_update_package(self, package_path):
        try:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                total_files = len(zip_ref.infolist())
                for i, file in enumerate(zip_ref.infolist()):
                    zip_ref.extract(file, self.temp_dir)
                    progress = int((i + 1) / total_files * 100)
                    self.write_progress('extract', progress, f"Extracting: {progress}%", 50 + progress * 0.2,
                                        "Extracting update")
            self.logger.info(f"Update package extracted to {self.temp_dir}")
        except Exception as e:
            self.logger.error(f"Error extracting update package: {str(e)}")
            raise


    def calculate_directory_checksum(self, directory):
        checksum = hashlib.md5()
        for root, _, files in os.walk(directory):
            for file in sorted(files):  # Sort to ensure consistent order
                file_path = os.path.join(root, file)
                if file.endswith('.pyc') or file.endswith('.pyo'):
                    continue  # Skip compiled Python files
                with open(file_path, 'rb') as f:
                    while True:
                        chunk = f.read(8192)
                        if not chunk:
                            break
                        checksum.update(chunk)
        return checksum.hexdigest()

    def update_version_info(self, manifest):
        version_file = Path(self.base_path) / 'EagleXRGB_version_client.json'
        with open(version_file, 'w') as f:
            json.dump({
                "version": manifest['version'],
                "updater_version": manifest['updater_version']
            }, f, indent=2)
        self.logger.info("Updated version information")

    def verify_file_integrity(self, file_path, expected_hash):
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        calculated_hash = sha256_hash.hexdigest()
        return calculated_hash == expected_hash

    def verify_update(self):
        self.report_progress(80, "Verifying update...")
        try:
            manifest_path = self.temp_dir / 'update_manifest.json'
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            for file_info in manifest['files_to_update']:
                file_path = Path(self.base_path) / file_info['path']
                if not file_path.exists():
                    self.logger.error(f"Updated file not found: {file_path}")
                    return False
                if 'hash' in file_info:
                    if not self.verify_file_integrity(file_path, file_info['hash']):
                        self.logger.error(f"File integrity check failed: {file_path}")
                        return False
            return True
        except Exception as e:
            self.logger.error(f"Error during update verification: {str(e)}")
            return False

    def get_installed_version(self, module_name):
        try:
            return importlib.metadata.version(module_name)
        except importlib.metadata.PackageNotFoundError:
            logging.warning(f"Module {module_name} not found in installed packages")
            return None

    def get_package_version(self, package_path):
        if os.path.isdir(package_path):
            try:
                # Try to read metadata directly from the package
                metadata = importlib.metadata.PathDistribution(package_path)
                return metadata.version
            except Exception:
                # Fallback to reading setup.py if metadata isn't available
                setup_path = os.path.join(package_path, 'setup.py')
                if os.path.exists(setup_path):
                    with open(setup_path, 'r') as f:
                        for line in f:
                            if 'version' in line:
                                return line.split('=')[-1].strip().strip("'").strip('"')
        else:
            # For single file modules, we might need a different approach
            # This is a simplified version check and might need to be expanded
            with open(package_path, 'r') as f:
                for line in f:
                    if line.startswith('__version__'):
                        return line.split('=')[-1].strip().strip("'").strip('"')

        logging.warning(f"Unable to determine version for package at {package_path}")
        return None

    def terminate_main_app(self):
        self.update_progress.emit(5, "Terminating main application...")
        for proc in psutil.process_iter(['name', 'pid']):
            if proc.info['name'] == 'EagleXRGB_Connector.exe':
                pid = proc.info['pid']
                try:
                    process = psutil.Process(pid)
                    process.terminate()
                    process.wait(timeout=10)
                    if process.is_running():
                        process.kill()
                        process.wait(timeout=5)
                    if not process.is_running():
                        self.logger.info(f"Main application (PID: {pid}) terminated successfully.")
                    else:
                        self.logger.error(f"Failed to terminate main application (PID: {pid})")
                except psutil.NoSuchProcess:
                    self.logger.warning(f"Main application process (PID: {pid}) not found.")
                except psutil.AccessDenied:
                    self.logger.error(f"Access denied when trying to terminate main application (PID: {pid})")
                except Exception as e:
                    self.logger.error(f"Error terminating main application (PID: {pid}): {str(e)}")
                break
        time.sleep(2)  # Wait to ensure the application has fully closed

        # Double-check if the process is still running
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == 'EagleXRGB_Connector.exe':
                self.logger.error("Main application is still running after termination attempt.")
                raise RuntimeError("Failed to terminate main application")

    def report_error(self, error):
        error_report = {
            "timestamp": datetime.now().isoformat(),
            "current_version": self.current_version,
            "target_version": self.latest_version,
            "error_message": str(error),
            "traceback": traceback.format_exc()
        }
        error_file = os.path.join(get_base_path(), 'logs', 'error_report.json')
        with open(error_file, 'w') as f:
            json.dump(error_report, f, indent=2)
        self.logger.info(f"Error report saved to: {error_file}")
        # Here you could add code to send the error report to a server or email it to developers

    def start_embedded_python_updater(self, update_info_file):
        python_exe = os.path.join(self.base_path, 'python_embedded', 'python.exe')
        if not os.path.exists(python_exe):
            raise FileNotFoundError(f"Embedded Python not found at {python_exe}")

        self.logger.info(f"Using embedded Python: {python_exe}")

        updater_script = os.path.join(self.base_path, '_internal', 'EagleXRGB_BootstrapUpdater.py')
        command = [
            python_exe,
            updater_script,
            update_info_file
        ]

        self.logger.info(f"Launching bootstrap updater with command: {' '.join(command)}")

        try:
            self.updater_process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                creationflags=subprocess.CREATE_NO_WINDOW
            )

            self.logger.info(f"Bootstrap updater process launched with PID: {self.updater_process.pid}")

            # Capture and log the output
            stdout, stderr = self.updater_process.communicate(timeout=30)  # Wait for up to 30 seconds
            self.logger.info(f"Bootstrap updater stdout:\n{stdout}")
            if stderr:
                self.logger.error(f"Bootstrap updater stderr:\n{stderr}")

            if self.updater_process.returncode != 0:
                self.logger.error(
                    f"Bootstrap updater exited with non-zero return code: {self.updater_process.returncode}")
            else:
                self.logger.info("Bootstrap updater completed successfully")

        except subprocess.TimeoutExpired:
            self.logger.warning("Bootstrap updater process timed out, it may still be running")
            self.updater_process.kill()
            stdout, stderr = self.updater_process.communicate()
            self.logger.info(f"Partial bootstrap updater stdout:\n{stdout}")
            if stderr:
                self.logger.error(f"Partial bootstrap updater stderr:\n{stderr}")
        except Exception as e:
            self.logger.error(f"Error launching bootstrap updater: {str(e)}")
            raise

        # Start a timer to check the progress file and process status
        self.progress_timer = QTimer()
        self.progress_timer.timeout.connect(self.check_progress_and_process)
        self.progress_timer.start(100)  # Check every 100ms

    def check_progress_and_process(self):
        if self.updater_process is None:
            self.logger.error("Updater process is not initialized")
            return

        if self.updater_process.poll() is not None:
            # Process has ended
            self.progress_timer.stop()
            returncode = self.updater_process.returncode
            stdout, stderr = self.updater_process.communicate()
            self.logger.info(f"Updater process ended with return code: {returncode}")
            self.logger.info(f"Updater stdout: {stdout}")
            self.logger.info(f"Updater stderr: {stderr}")

            if returncode == 0:
                self.update_complete.emit(True, "Update completed successfully")
            else:
                error_message = f"Update failed with return code {returncode}. Error: {stderr}"
                self.update_error.emit(error_message)
            return

        # Check progress file
        try:
            with open(self.progress_file, 'r') as f:
                progress_data = json.load(f)
                task = progress_data.get('task', 'update')
                progress = progress_data.get('progress', 0)
                message = progress_data.get('message', '')
                overall_progress = progress_data.get('overall_progress', 0)
                overall_status = progress_data.get('overall_status', '')
                self.update_progress.emit(overall_progress, overall_status)
                self.logger.info(f"Update progress: {overall_progress}% - {overall_status}")
        except (FileNotFoundError, json.JSONDecodeError) as e:
            self.logger.warning(f"Error reading progress file: {str(e)}")


def main():
    if len(sys.argv) != 2:
        print("Usage: EagleXRGB_Updater.py <update_info_file>")
        return 1

    update_info_file = sys.argv[1]

    try:
        print(f"Starting update process with update info file: {update_info_file}")

        with open(update_info_file, 'r') as f:
            update_info = json.load(f)
        print(f"Loaded update info: {json.dumps(update_info, indent=2)}")

        base_path = get_base_path()
        print(f"Base path: {base_path}")

        updater = Updater(update_info)
        print("Updater instance created")

        updater.logger.info(f"Update info contents: {json.dumps(update_info, indent=2)}")

        success = updater.run_update()
        print(f"Update process completed with success: {success}")

        return 0 if success else 1

    except Exception as e:
        print(f"An error occurred during the update process: {str(e)}")
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())