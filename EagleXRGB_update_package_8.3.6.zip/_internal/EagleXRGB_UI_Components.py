# EagleXRGB_UI_Components.py

from PyQt5.QtWidgets import (QCheckBox, QLabel, QListWidget, QSlider, QSpinBox, QWidget, QPushButton, QLineEdit,
                             QTextEdit,
                             QComboBox,
                             QTabWidget, QTabBar, QStyleOptionTab, QStyle, QProxyStyle)
from PyQt5.QtGui import QColor, QPainter, QLinearGradient, QPainterPath, QPalette, QPen
from PyQt5.QtCore import Qt, QPoint, QRect, QPropertyAnimation, QEasingCurve


class GlassTabStyle(QProxyStyle):
    def drawControl(self, element, option, painter, widget=None):
        if element == QStyle.CE_TabBarTab:
            self.drawCustomTabShape(option, painter)
        elif element == QStyle.CE_TabBarTabLabel:
            if not (option.state & QStyle.State_Selected):
                painter.save()
                painter.setOpacity(0.7)
            super().drawControl(element, option, painter, widget)
            if not (option.state & QStyle.State_Selected):
                painter.restore()
        else:
            super().drawControl(element, option, painter, widget)

    def drawCustomTabShape(self, option, painter):
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)

        rect = option.rect
        selected = option.state & QStyle.State_Selected

        if selected:
            gradient = QLinearGradient(rect.topLeft(), rect.bottomLeft())
            gradient.setColorAt(0, QColor(60, 60, 80, 230))
            gradient.setColorAt(1, QColor(40, 40, 60, 230))
        else:
            gradient = QLinearGradient(rect.topLeft(), rect.bottomLeft())
            gradient.setColorAt(0, QColor(40, 40, 60, 200))
            gradient.setColorAt(1, QColor(30, 30, 50, 200))

        path = QPainterPath()
        path.addRoundedRect(rect, 5, 5)

        painter.fillPath(path, gradient)

        if selected:
            painter.setPen(QPen(QColor(0, 255, 255), 2))
        else:
            painter.setPen(QPen(QColor(100, 100, 100), 1))

        painter.drawPath(path)
        painter.restore()


class GlassLabel(QLabel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setStyleSheet("""
            GlassLabel {
                color: #00ffff;
                font-weight: bold;
                background-color: rgba(20, 20, 30, 100);
                border: 1px solid rgba(0, 255, 255, 50);
                border-radius: 5px;
                padding: 2px;
            }
        """)


class FuturisticCheckBox(QCheckBox):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setStyleSheet("""
            FuturisticCheckBox {
                color: #00ffff;
            }
            FuturisticCheckBox::indicator {
                width: 20px;
                height: 20px;
                background-color: rgba(40, 40, 60, 180);
                border: 1px solid #00ffff;
                border-radius: 3px;
            }
            FuturisticCheckBox::indicator:checked {
                background-color: #00ffff;
            }
        """)


class GlassTabBar(QTabBar):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyle(GlassTabStyle())
        self.setDrawBase(False)


class GlassTabWidget(QTabWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTabBar(GlassTabBar(self))
        self.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid rgba(255, 255, 255, 30);
                border-radius: 5px;
                background-color: rgba(20, 20, 30, 200);
            }
            QTabWidget::tab-bar {
                alignment: center;
            }
        """)


class FuturisticStyle:
    @staticmethod
    def get_glass_style():
        return """
        QWidget {
            background-color: rgba(20, 20, 30, 180);
            border: 1px solid rgba(255, 255, 255, 30);
            border-radius: 10px;
            color: #ffffff;
        }
        QPushButton {
            background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                              stop:0 #5a5a7f, stop:1 #3a3a5f);
            color: #00ffff;
            border: 1px solid #00ffff;
            border-radius: 5px;
            padding: 5px 10px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                              stop:0 #6a6a8f, stop:1 #4a4a6f);
        }
        QPushButton:pressed {
            background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                              stop:0 #4a4a6f, stop:1 #3a3a5f);
        }
        QLineEdit, QTextEdit, QComboBox {
            background-color: rgba(40, 40, 60, 180);
            color: #ffffff;
            border: 1px solid rgba(0, 255, 255, 100);
            border-radius: 5px;
            padding: 5px;
        }
        QTabWidget::pane {
            border: 1px solid rgba(255, 255, 255, 30);
            border-radius: 10px;
            top: -1px;
        }
        QTabBar::tab {
            background-color: rgba(40, 40, 60, 180);
            color: #ffffff;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            padding: 8px 12px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background-color: rgba(60, 60, 80, 200);
            color: #00ffff;
        }
        """


class FuturisticListWidget(QListWidget):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setStyleSheet("""
            FuturisticListWidget {
                background-color: rgba(40, 40, 60, 180);
                border: 1px solid #00ffff;
                border-radius: 5px;
                color: #ffffff;
            }
            FuturisticListWidget::item {
                padding: 5px;
            }
            FuturisticListWidget::item:hover {
                background-color: rgba(60, 60, 80, 180);
            }
            FuturisticListWidget::item:selected {
                background-color: rgba(0, 255, 255, 100);
            }
        """)


class FuturisticSpinBox(QSpinBox):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setStyleSheet("""
            FuturisticSpinBox {
                background-color: rgba(40, 40, 60, 180);
                border: 1px solid #00ffff;
                border-radius: 5px;
                color: #ffffff;
                padding: 2px 5px;
            }
            FuturisticSpinBox::up-button, FuturisticSpinBox::down-button {
                width: 16px;
                border: 1px solid #00ffff;
            }
            FuturisticSpinBox::up-arrow, FuturisticSpinBox::down-arrow {
                width: 8px;
                height: 8px;
            }
            FuturisticSpinBox::up-arrow {
                image: url(icons/up_arrow.png);
            }
            FuturisticSpinBox::down-arrow {
                image: url(icons/down_arrow.png);
            }
        """)


class FuturisticSlider(QSlider):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setStyleSheet("""
            FuturisticSlider::groove:horizontal {
                border: 1px solid #00ffff;
                height: 8px;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #31CCFF, stop:1 #FF33FF);
                margin: 2px 0;
                border-radius: 4px;
            }
            FuturisticSlider::handle:horizontal {
                background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 #FFFFFF, stop:1 #00FFFF);
                border: 1px solid #5c5c5c;
                width: 18px;
                margin: -2px 0;
                border-radius: 9px;
            }
            FuturisticSlider::sub-page:horizontal {
                background: #00ffff;
                border-radius: 4px;
            }
        """)


class GlassWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Create a gradient for the glass effect
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(255, 255, 255, 30))
        gradient.setColorAt(1, QColor(0, 0, 0, 50))

        # Draw the rounded rectangle with the gradient
        painter.setBrush(gradient)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(self.rect(), 10, 10)


class FuturisticButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet("""
            FuturisticButton {
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 #5a5a7f, stop:1 #3a3a5f);
                color: #00ffff;
                border: 1px solid #00ffff;
                border-radius: 5px;
                padding: 5px 10px;
                font-weight: bold;
            }
            FuturisticButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 #6a6a8f, stop:1 #4a4a6f);
            }
            FuturisticButton:pressed {
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 #4a4a6f, stop:1 #3a3a5f);
            }
        """)


class FuturisticLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            FuturisticLineEdit {
                background-color: rgba(40, 40, 60, 180);
                color: #ffffff;
                border: 1px solid rgba(0, 255, 255, 100);
                border-radius: 5px;
                padding: 5px;
            }
        """)


class FuturisticTextEdit(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            FuturisticTextEdit {
                background-color: rgba(40, 40, 60, 180);
                color: #ffffff;
                border: 1px solid rgba(0, 255, 255, 100);
                border-radius: 5px;
                padding: 5px;
            }
        """)


class FuturisticComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            FuturisticComboBox {
                background-color: rgba(40, 40, 60, 180);
                color: #ffffff;
                border: 1px solid rgba(0, 255, 255, 100);
                border-radius: 5px;
                padding: 5px;
            }
            FuturisticComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 15px;
                border-left-width: 1px;
                border-left-color: rgba(0, 255, 255, 100);
                border-left-style: solid;
                border-top-right-radius: 3px;
                border-bottom-right-radius: 3px;
            }
            FuturisticComboBox::down-arrow {
                image: url(icons/dropdown_arrow.png);
            }
        """)


class FuturisticTabStyle(QProxyStyle):
    def drawControl(self, element, option, painter, widget=None):
        if element == QStyle.CE_TabBarTabShape:
            painter.save()
            painter.setRenderHint(QPainter.Antialiasing)

            rect = option.rect
            selected = option.state & QStyle.State_Selected

            if selected:
                painter.setBrush(QColor(60, 60, 80, 200))
                painter.setPen(QColor(0, 255, 255))
            else:
                painter.setBrush(QColor(40, 40, 60, 180))
                painter.setPen(QColor(255, 255, 255, 100))

            painter.drawRoundedRect(rect, 5, 5)
            painter.restore()
        else:
            super().drawControl(element, option, painter, widget)


class FuturisticTabWidget(QTabWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTabBar(FuturisticTabBar(self))
        self.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid rgba(255, 255, 255, 30);
                border-radius: 10px;
                top: -1px;
            }
        """)


class FuturisticTabBar(QTabBar):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyle(FuturisticTabStyle())
        self.setStyleSheet("""
            QTabBar::tab {
                background-color: rgba(40, 40, 60, 180);
                color: #ffffff;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                padding: 8px 12px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: rgba(60, 60, 80, 200);
                color: #00ffff;
            }
        """)


def apply_futuristic_style(widget):
    widget.setStyleSheet(FuturisticStyle.get_glass_style())
    palette = widget.palette()
    palette.setColor(QPalette.Window, QColor(20, 20, 30, 180))
    palette.setColor(QPalette.WindowText, Qt.white)
    palette.setColor(QPalette.Base, QColor(40, 40, 60, 180))
    palette.setColor(QPalette.AlternateBase, QColor(60, 60, 80, 180))
    palette.setColor(QPalette.ToolTipBase, Qt.white)
    palette.setColor(QPalette.ToolTipText, Qt.white)
    palette.setColor(QPalette.Text, Qt.white)
    palette.setColor(QPalette.Button, QColor(60, 60, 80, 180))
    palette.setColor(QPalette.ButtonText, Qt.cyan)
    palette.setColor(QPalette.BrightText, Qt.red)
    palette.setColor(QPalette.Highlight, QColor(0, 255, 255, 128))
    palette.setColor(QPalette.HighlightedText, Qt.black)
    widget.setPalette(palette)
    widget.setStyleSheet(widget.styleSheet() + """
        GlassTabWidget::pane {
            border: 1px solid rgba(255, 255, 255, 30);
            border-radius: 5px;
            background-color: rgba(20, 20, 30, 200);
        }
        GlassTabWidget::tab-bar {
            alignment: center;
        }
        GlassTabBar::tab {
            background-color: rgba(40, 40, 60, 200);
            color: #ffffff;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            padding: 8px 12px;
            margin-right: 2px;
        }
        GlassTabBar::tab:selected {
            background-color: rgba(60, 60, 80, 230);
            color: #00ffff;
        }
    """)


def create_tab_animation(tab_widget):
    def animate_tab_switch(index):
        current_tab = tab_widget.widget(index)
        animation = QPropertyAnimation(current_tab, b"pos")
        animation.setDuration(300)
        animation.setStartValue(QPoint(10, 0))
        animation.setEndValue(QPoint(0, 0))
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.start()

    tab_widget.currentChanged.connect(animate_tab_switch)

# Add more futuristic UI components as needed
