import os

from PyQt5.QtWidgets import QColorDialog, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget, \
    QPushButton, \
    QSlider, QTabWidget, \
    QStackedWidget, \
    QTabBar, \
    QToolTip, QVBoxLayout, QWidget
from PyQt5.QtCore import QPropertyAnimation, QEasingCurve, Qt, QPoint, QEvent, pyqtSignal
from PyQt5.QtGui import QCursor


class CustomTabBar(QTabBar):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            index = self.tabAt(event.pos())
            if index != -1:
                tooltip = self.tabToolTip(index)
                if tooltip:
                    QToolTip.showText(QCursor.pos(), tooltip)
                else:
                    QToolTip.hideText()
                return True
        return super().event(event)


class SmoothTabWidget(QTabWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_index = 0
        self.animation_duration = 500  # Duration of the animation in milliseconds
        self.tooltips = {}  # Dictionary to store tooltips

        # Create and set custom tab bar
        self.setTabBar(CustomTabBar(self))

        # Create a new CustomStackedWidget
        self.custom_stack = CustomStackedWidget(self)

        # Set the custom stack as the stack widget for QTabWidget
        self.setStackedWidget(self.custom_stack)

    def setStackedWidget(self, stack):
        self.custom_stack = stack
        super().setCurrentWidget(self.custom_stack)

    def addTab(self, widget, label):
        index = self.custom_stack.addWidget(widget)
        tab_index = super().addTab(widget, label)
        print(f"Added tab: {label} at index {tab_index}")  # Debug output
        return tab_index

    def setCurrentIndex(self, index):
        if self.current_index == index:
            return

        direction = Qt.RightToLeft if index > self.current_index else Qt.LeftToRight
        self.custom_stack.slideInWidget(index, direction)
        self.current_index = index
        super().setCurrentIndex(index)

    def setTabToolTip(self, index, tooltip):
        self.tooltips[index] = tooltip
        print(f"Setting tooltip for tab {index}: {tooltip}")  # Debug output
        super().setTabToolTip(index, tooltip)


class CustomStackedWidget(QStackedWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.animation = QPropertyAnimation(self, b"pos")
        self.animation.setEasingCurve(QEasingCurve.InOutCubic)
        self.animation.setDuration(500)

    def slideInWidget(self, index, direction):
        if self.count() == 0 or index >= self.count():
            return

        widget = self.widget(index)
        current_widget = self.currentWidget()

        if widget is current_widget:
            return

        if direction == Qt.RightToLeft:
            offset = self.frameRect().width()
            widget.setGeometry(self.frameRect().x() + offset, 0, self.frameRect().width(), self.frameRect().height())
            end_x = self.frameRect().x()
            start_x = self.frameRect().x() - offset
        else:
            offset = -self.frameRect().width()
            widget.setGeometry(self.frameRect().x() + offset, 0, self.frameRect().width(), self.frameRect().height())
            end_x = self.frameRect().x()
            start_x = self.frameRect().x() - offset

        self.animation.setStartValue(QPoint(start_x, 0))
        self.animation.setEndValue(QPoint(end_x, 0))

        self.setCurrentWidget(widget)
        self.animation.start()


class CustomFileDialog(QDialog):
    filesSelected = pyqtSignal(list)
    fileSelected = pyqtSignal(str)

    def __init__(self, parent=None, caption="Select Files", directory="", filter="", mode="multi"):
        super().__init__(parent)
        self.setWindowTitle(caption)
        self.directory = directory
        self.filter = filter
        self.mode = mode  # 'multi' for multiple files, 'single' for single file

        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)

        if self.mode == 'multi':
            # File list for multiple selection
            self.fileList = QListWidget()
            layout.addWidget(self.fileList)

            # Buttons for multiple selection
            buttonLayout = QHBoxLayout()
            self.addButton = QPushButton("Add Files")
            self.addButton.clicked.connect(self.addFiles)
            buttonLayout.addWidget(self.addButton)

            self.removeButton = QPushButton("Remove Selected")
            self.removeButton.clicked.connect(self.removeSelected)
            buttonLayout.addWidget(self.removeButton)

            layout.addLayout(buttonLayout)
        else:
            # Single file selection
            self.filePathInput = QLineEdit()
            layout.addWidget(self.filePathInput)

            self.browseButton = QPushButton("Browse")
            self.browseButton.clicked.connect(self.browseSingleFile)
            layout.addWidget(self.browseButton)

        # Common buttons
        commonButtonLayout = QHBoxLayout()
        self.okButton = QPushButton("OK")
        self.okButton.clicked.connect(self.accept)
        commonButtonLayout.addWidget(self.okButton)

        self.cancelButton = QPushButton("Cancel")
        self.cancelButton.clicked.connect(self.reject)
        commonButtonLayout.addWidget(self.cancelButton)

        layout.addLayout(commonButtonLayout)

        self.resize(600, 400 if self.mode == 'multi' else 200)

    def addFiles(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Files", self.directory, self.filter)
        if files:
            self.fileList.addItems(files)

    def removeSelected(self):
        for item in self.fileList.selectedItems():
            self.fileList.takeItem(self.fileList.row(item))

    def browseSingleFile(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select File", self.directory, self.filter)
        if file:
            self.filePathInput.setText(file)

    def getSelectedFiles(self):
        if self.mode == 'multi':
            return [self.fileList.item(i).text() for i in range(self.fileList.count())]
        else:
            return [self.filePathInput.text()] if self.filePathInput.text() else []

    def accept(self):
        selected_files = self.getSelectedFiles()
        if self.mode == 'multi':
            self.filesSelected.emit(selected_files)
        else:
            self.fileSelected.emit(selected_files[0] if selected_files else '')
        super().accept()


class SettingsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)

        # Animation Speed
        speedLayout = QHBoxLayout()
        speedLayout.addWidget(QLabel("Animation Speed:"))
        self.speedSlider = QSlider(Qt.Horizontal)
        self.speedSlider.setRange(100, 1000)
        self.speedSlider.setValue(500)
        self.speedSlider.setTickPosition(QSlider.TicksBelow)
        self.speedSlider.setTickInterval(100)
        speedLayout.addWidget(self.speedSlider)
        layout.addLayout(speedLayout)

        # Color Theme
        themeLayout = QHBoxLayout()
        themeLayout.addWidget(QLabel("Color Theme:"))
        self.themeCombo = QComboBox()
        self.themeCombo.addItems(["Light", "Dark", "Custom"])
        themeLayout.addWidget(self.themeCombo)
        self.colorButton = QPushButton("Choose Custom Color")
        self.colorButton.clicked.connect(self.chooseColor)
        themeLayout.addWidget(self.colorButton)
        layout.addLayout(themeLayout)

        # Add more settings as needed

        # Apply Button
        self.applyButton = QPushButton("Apply Settings")
        self.applyButton.clicked.connect(self.applySettings)
        layout.addWidget(self.applyButton)

    def chooseColor(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.customColor = color
            self.colorButton.setStyleSheet(f"background-color: {color.name()};")

    def applySettings(self):
        # Here you would apply the settings to your application
        animationSpeed = self.speedSlider.value()
        theme = self.themeCombo.currentText()

        # Apply these settings to your application
        print(f"Applying settings: Animation Speed = {animationSpeed}, Theme = {theme}")


class StyleSheet:
    @staticmethod
    def get_stylesheet():
        return """
        /* Main application style */
        QWidget {
            background-color: #1e1e2e;
            color: #cdd6f4;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        /* Tab widget style */
        QTabWidget::pane {
            border: 1px solid #45475a;
            background-color: #1e1e2e;
        }

        QTabBar::tab {
            background-color: #313244;
            color: #cdd6f4;
            padding: 8px 16px;
            margin-right: 2px;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
        }

        QTabBar::tab:selected {
            background-color: #45475a;
        }

        QTabBar::tab:hover {
            background-color: #585b70;
        }

        /* Button style */
        QPushButton {
            background-color: #89b4fa;
            color: #1e1e2e;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-weight: bold;
        }

        QPushButton:hover {
            background-color: #b4befe;
        }

        QPushButton:pressed {
            background-color: #74c7ec;
        }

        QPushButton:disabled {
            background-color: #6c7086;
            color: #bac2de;
        }

        /* Input fields style */
        QLineEdit, QTextEdit, QSpinBox {
            background-color: #313244;
            color: #cdd6f4;
            border: 1px solid #45475a;
            border-radius: 4px;
            padding: 4px;
        }

        QLineEdit:focus, QTextEdit:focus, QSpinBox:focus {
            border: 1px solid #89b4fa;
        }

        /* Checkbox style */
        QCheckBox {
            color: #cdd6f4;
        }

        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }

        QCheckBox::indicator:unchecked {
            border: 2px solid #45475a;
            background-color: #313244;
        }

        QCheckBox::indicator:checked {
            border: 2px solid #89b4fa;
            background-color: #89b4fa;
        }

        /* Scrollbar style */
        QScrollBar:vertical {
            border: none;
            background-color: #313244;
            width: 12px;
            margin: 0px 0px 0px 0px;
        }

        QScrollBar::handle:vertical {
            background-color: #45475a;
            min-height: 30px;
            border-radius: 6px;
        }

        QScrollBar::handle:vertical:hover {
            background-color: #585b70;
        }

        QScrollBar::sub-line:vertical, QScrollBar::add-line:vertical {
            height: 0px;
        }

        /* List and Combo box styles */
        QListWidget, QComboBox {
            background-color: #313244;
            color: #cdd6f4;
            border: 1px solid #45475a;
            border-radius: 4px;
        }

        QComboBox::drop-down {
            border: none;
        }

        QComboBox::down-arrow {
            image: url(down_arrow.png);
            width: 14px;
            height: 14px;
        }

        QListWidget::item:selected, QComboBox::item:selected {
            background-color: #45475a;
        }
        """
