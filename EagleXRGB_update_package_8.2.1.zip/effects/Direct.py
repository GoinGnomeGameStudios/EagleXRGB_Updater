import openrgb
import colorsys

# Effect Name
name = "Direct"

# Effect Parameters
params = {
    "color": {"type": "color", "default": "#FF0000"},
}


def gradient_color(start_color, end_color, t):
    """
    Calculate a color along a gradient between start_color and end_color.
    t is a value between 0 and 1, where 0 returns start_color and 1 returns end_color.
    """
    start_rgb = tuple(int(start_color[i:i + 2], 16) for i in (1, 3, 5))
    end_rgb = tuple(int(end_color[i:i + 2], 16) for i in (1, 3, 5))

    start_hsv = colorsys.rgb_to_hsv(*[x / 255 for x in start_rgb])
    end_hsv = colorsys.rgb_to_hsv(*[x / 255 for x in end_rgb])

    interp_hsv = tuple(start + t * (end - start) for start, end in zip(start_hsv, end_hsv))
    interp_rgb = colorsys.hsv_to_rgb(*interp_hsv)

    return tuple(int(x * 255) for x in interp_rgb)


def render(device, params):
    """
    Render the effect on the device.
    """
    color = params["color"]
    rgb_color = tuple(int(color[i:i + 2], 16) for i in (1, 3, 5))

    zones = device.zones
    leds = device.leds

    # Set all LEDs to the static color
    for led in leds:
        led.set_color(rgb_color)

    # If the device has zones, set all zones to the static color
    for zone in zones:
        zone.set_color(rgb_color)


def resized(device):
    """
    Called when the device is resized.
    """
    pass  # No action needed for static color effect


def stopped(device):
    """
    Called when the effect is stopped.
    """
    pass  # No cleanup needed for static color effect