import os
import json
import requests
import zipfile
import shutil


class AutoUpdater:
    def __init__(self, app_path, update_url, splash_screen=None):
        self.app_path = app_path
        self.update_url = update_url
        self.temp_dir = os.path.join(app_path, 'temp_update')
        self.splash_screen = splash_screen

    def check_for_updates(self):
        try:
            response = requests.get(f"{self.update_url}/updates/version.json")
            response.raise_for_status()
            latest_version = response.json()['latest_version']
            current_version = self.get_current_version()
            return latest_version > current_version, latest_version
        except requests.RequestException:
            return False, None

    def get_current_version(self):
        with open(os.path.join(self.app_path, 'version.json'), 'r') as f:
            return json.load(f)['version']

    def download_update(self, version):
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)

        try:
            if self.splash_screen:
                self.splash_screen.update_status("Downloading update...")
                self.splash_screen.update_download_progress(0)

            # Download the manifest first
            manifest_url = f"{self.update_url}/updates/{version}/EagleXRGB_update_manifest.json"
            manifest_response = requests.get(manifest_url)
            manifest_response.raise_for_status()

            with open(os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json'), 'wb') as f:
                f.write(manifest_response.content)

            if self.splash_screen:
                self.splash_screen.update_download_progress(10)

            # Now download the update package
            update_url = f"{self.update_url}/updates/{version}/update_package.zip"
            update_response = requests.get(update_url, stream=True)
            update_response.raise_for_status()

            total_size = int(update_response.headers.get('content-length', 0))
            block_size = 1024  # 1 KB
            downloaded = 0

            with open(os.path.join(self.temp_dir, 'update_package.zip'), 'wb') as f:
                for data in update_response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        percent = int(10 + (downloaded / total_size * 90))
                        if self.splash_screen:
                            self.splash_screen.update_download_progress(percent)

            if self.splash_screen:
                self.splash_screen.update_download_progress(100)
                self.splash_screen.update_status("Download complete!")

            return True
        except requests.RequestException:
            if self.splash_screen:
                self.splash_screen.update_status("Download failed!")
            return False

    def apply_update(self):
        if self.splash_screen:
            self.splash_screen.update_status("Applying update...")
            self.splash_screen.update_update_progress(0)

        manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
        zip_path = os.path.join(self.temp_dir, 'update_package.zip')

        with open(manifest_path, 'r') as f:
            manifest = json.load(f)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(self.temp_dir)

        if self.splash_screen:
            self.splash_screen.update_update_progress(20)

        total_items = len(manifest['files_to_update']) + len(manifest['folders_to_update']) + \
                      len(manifest['files_to_remove']) + len(manifest['folders_to_remove'])
        processed_items = 0

        # Update files
        for file in manifest['files_to_update']:
            src = os.path.join(self.temp_dir, file)
            dst = os.path.join(self.app_path, file)
            shutil.copy2(src, dst)
            processed_items += 1
            if self.splash_screen:
                self.splash_screen.update_update_progress(20 + int(processed_items / total_items * 60))

        # Update folders
        for folder in manifest['folders_to_update']:
            src = os.path.join(self.temp_dir, folder)
            dst = os.path.join(self.app_path, folder)
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            processed_items += 1
            if self.splash_screen:
                self.splash_screen.update_update_progress(20 + int(processed_items / total_items * 60))

        # Remove files
        for file in manifest['files_to_remove']:
            file_path = os.path.join(self.app_path, file)
            if os.path.exists(file_path):
                os.remove(file_path)
            processed_items += 1
            if self.splash_screen:
                self.splash_screen.update_update_progress(20 + int(processed_items / total_items * 60))

        # Remove folders
        for folder in manifest['folders_to_remove']:
            folder_path = os.path.join(self.app_path, folder)
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
            processed_items += 1
            if self.splash_screen:
                self.splash_screen.update_update_progress(20 + int(processed_items / total_items * 60))

        # Update local version info
        with open(os.path.join(self.app_path, 'version.json'), 'w') as f:
            json.dump({"version": manifest['version']}, f)

        # Clean up
        shutil.rmtree(self.temp_dir)

        if self.splash_screen:
            self.splash_screen.update_update_progress(100)
            self.splash_screen.update_status("Update complete!")

    def update_process(self):
        update_available, latest_version = self.check_for_updates()
        if update_available:
            if self.download_update(latest_version):
                self.apply_update()
                return True
            else:
                return False
        return False