import json
import os

from PyQt5.QtCore import QEasingCurve, QEvent, QPoint, QPropertyAnimation, QTimer, Qt
from PyQt5.QtGui import QColor, QCursor
from PyQt5.QtWidgets import (QCheckBox, QColorDialog, QComboBox, QGraphicsDropShadowEffect, QHBoxLayout, QLabel,
                             QLineEdit, QMessageBox,
                             QPushButton, QSlider, QStackedWidget, QTabBar, QTabWidget, QToolTip, QVBoxLayout, QWidget)
from EagleXRGB_Notifications import ModernPopup


class SettingsTab(QWidget):
    def __init__(self, app_instance, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.theme = None
        self.tab_style = None
        self.app_instance = app_instance
        self.settings_file = "config/EagleXRGB_settings.json"
        self.settings = {}
        self.debug_mode = False
        self.minimize_to_tray = True

        # Initialize color variables
        self.bg_color = self.app_instance.bg_color
        self.text_color = self.app_instance.text_color
        self.button_color = self.app_instance.button_color
        self.border_color = self.app_instance.border_color
        self.tab_bg_color = self.app_instance.tab_bg_color
        self.selected_tab_bg_color = self.app_instance.selected_tab_bg_color
        self.selected_tab_text_color = self.app_instance.selected_tab_text_color
        self.input_bg_color = self.app_instance.input_bg_color

        # Initialize color pickers
        self.bg_color_picker = QColorDialog()
        self.text_color_picker = QColorDialog()
        self.button_color_picker = QColorDialog()
        self.border_color_picker = QColorDialog()
        self.tab_bg_color_picker = QColorDialog()
        self.selected_tab_bg_color_picker = QColorDialog()
        self.selected_tab_text_color_picker = QColorDialog()
        self.input_bg_color_picker = QColorDialog()

        # Use the attributes from app_instance
        self.auto_update_enabled = app_instance.auto_update_enabled
        self.launcher_version = app_instance.launcher_version
        self.current_version = app_instance.current_version
        self.auto_updater = app_instance.auto_updater

        self.init_ui()
        self.load_settings()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Color customization section
        color_section = QVBoxLayout()
        color_section.addWidget(QLabel("Color Customization"))

        color_buttons = [
            ("Background Color", 'bg_color'),
            ("Text Color", 'text_color'),
            ("Button Color", 'button_color'),
            ("Border Color", 'border_color'),
            ("Tab Background Color", 'tab_bg_color'),
            ("Selected Tab Background Color", 'selected_tab_bg_color'),
            ("Selected Tab Text Color", 'selected_tab_text_color'),
            ("Input Background Color", 'input_bg_color')
        ]

        for text, attr in color_buttons:
            btn_layout = QHBoxLayout()
            btn = QPushButton(text)
            btn.setFixedSize(250, 40)
            btn.clicked.connect(lambda *, a=attr: self.change_color(a))
            self.apply_button_style(btn)

            preview = QLabel()
            preview.setFixedSize(40, 40)
            preview.setStyleSheet("background-color: #CCCCCC; border: 1px solid #999999;")

            btn_layout.addWidget(btn)
            btn_layout.addWidget(preview)
            btn_layout.addStretch()
            color_section.addLayout(btn_layout)
        layout.addLayout(color_section)

        # Animation settings
        animation_layout = QHBoxLayout()
        animation_layout.addWidget(QLabel("Animation Speed:"))
        self.animation_speed_slider = QSlider(Qt.Horizontal)
        self.animation_speed_slider.setRange(100, 1000)
        self.animation_speed_slider.setValue(500)
        self.animation_speed_slider.setTickPosition(QSlider.TicksBelow)
        self.animation_speed_slider.setTickInterval(100)
        animation_layout.addWidget(self.animation_speed_slider)
        layout.addLayout(animation_layout)

        # Theme selection
        theme_layout = QHBoxLayout()
        theme_layout.addWidget(QLabel("Color Theme:"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Light", "Dark", "Custom"])
        self.theme_combo.currentTextChanged.connect(self.on_theme_changed)
        theme_layout.addWidget(self.theme_combo)
        layout.addLayout(theme_layout)

        # Tab style selection
        tab_style_layout = QHBoxLayout()
        tab_style_layout.addWidget(QLabel("Tab Style:"))
        self.tab_style_combo = QComboBox()
        self.tab_style_combo.addItems(["Modern", "Classic"])
        self.tab_style_combo.currentTextChanged.connect(self.on_tab_style_changed)
        tab_style_layout.addWidget(self.tab_style_combo)
        layout.addLayout(tab_style_layout)

        # Other settings
        self.minimize_to_tray_checkbox = QCheckBox("Minimize to Tray")
        self.minimize_to_tray_checkbox.setChecked(self.app_instance.minimize_to_tray)
        self.minimize_to_tray_checkbox.stateChanged.connect(self.toggle_minimize_to_tray)
        layout.addWidget(self.minimize_to_tray_checkbox)

        self.debug_mode_checkbox = QCheckBox("Enable Debug Mode")
        layout.addWidget(self.debug_mode_checkbox)

        self.styles_input = QLineEdit()
        self.styles_input.setPlaceholderText("Enter custom styles")
        self.styles_input.setStyleSheet("padding: 10px; border: 1px solid #CCCCCC; border-radius: 5px;")
        layout.addWidget(self.styles_input)

        # Auto-update section
        update_section = QVBoxLayout()
        update_section.addWidget(QLabel("Auto-Update Settings"))

        # Add auto-update checkbox
        self.auto_update_checkbox = QCheckBox("Enable Automatic Updates")
        self.auto_update_checkbox.setChecked(self.auto_update_enabled)
        self.auto_update_checkbox.stateChanged.connect(self.toggle_auto_update)
        layout.addWidget(self.auto_update_checkbox)

        # Update version layout
        version_layout = QHBoxLayout()
        version_layout.addWidget(QLabel("Current Version:"))
        self.version_label = QLabel(self.current_version)
        version_layout.addWidget(self.version_label)
        version_layout.addStretch()
        version_layout.addWidget(QLabel("Launcher Version:"))
        self.launcher_version_label = QLabel(self.launcher_version)
        version_layout.addWidget(self.launcher_version_label)
        update_section.addLayout(version_layout)

        self.check_update_btn = QPushButton("Check for Updates")
        self.check_update_btn.clicked.connect(self.check_for_updates)
        self.apply_button_style(self.check_update_btn)
        update_section.addWidget(self.check_update_btn)
        layout.addLayout(update_section)

        # Apply button
        self.apply_btn = QPushButton("Apply Settings")
        self.apply_btn.setFixedSize(200, 40)
        self.apply_btn.clicked.connect(self.apply_settings)
        self.apply_button_style(self.apply_btn)
        layout.addWidget(self.apply_btn, alignment=Qt.AlignCenter)

        self.setLayout(layout)

    def toggle_auto_update(self, state):
        self.auto_update_enabled = bool(state)
        self.app_instance.auto_update_enabled = self.auto_update_enabled
        self.save_settings()

    def update_version_info(self):
        self.version_label.setText(self.current_version)
        self.launcher_version_label.setText(self.launcher_version)

    def check_for_updates(self):
        self.app_instance.toggle_splash_screen(True)
        self.app_instance.splash_screen.show_update_info("Checking for updates...")
        update_available, version_info = self.app_instance.auto_updater.check_for_updates()

        if update_available:
            latest_version = version_info.get('latest_version', 'Unknown')
            self.app_instance.toggle_splash_screen(False)
            response = ModernPopup.show_question(
                self, "Update Available",
                f"A new version ({latest_version}) is available. Would you like to update?"
            )
            if response == QMessageBox.Yes:
                self.download_and_install_update(version_info)
            else:
                self.app_instance.toggle_splash_screen(False)
        else:
            self.app_instance.toggle_splash_screen(False)
            ModernPopup.show_info(self, "No Updates", "You're using the latest version.")

    def download_and_install_update(self, version_info):
        self.app_instance.toggle_splash_screen(True)
        self.app_instance.splash_screen.show_update_info("Downloading update...")

        if self.app_instance.auto_updater.download_update(version_info):
            self.app_instance.splash_screen.show_update_info("Update downloaded. Preparing to install...")
            response = ModernPopup.show_question(
                self, "Update Downloaded",
                "The update has been downloaded. The application will need to restart to install the update. Proceed?"
            )
            if response == QMessageBox.Yes:
                self.app_instance.splash_screen.show_update_info("Installing update...")
                if self.app_instance.auto_updater.apply_update():
                    self.app_instance.splash_screen.show_update_info("Update installed. Restarting application...")
                    QTimer.singleShot(2000, self.app_instance.restart_application)
                else:
                    self.app_instance.toggle_splash_screen(False)
                    ModernPopup.show_error(self, "Update Failed",
                                           "Failed to install the update. Please try again later.")
            else:
                self.app_instance.toggle_splash_screen(False)
        else:
            self.app_instance.toggle_splash_screen(False)
            ModernPopup.show_error(self, "Update Failed", "Failed to download the update. Please try again later.")

    def toggle_minimize_to_tray(self, state):
        self.app_instance.minimize_to_tray = bool(state)
        self.app_instance.save_settings()

    def apply_button_style(self, button):
        button.setStyleSheet("""
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                padding: 5px 10px;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                margin: 4px 2px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #005a9e;
            }
            QPushButton:pressed {
                background-color: #004377;
            }
        """)

    def on_tab_style_changed(self, style):
        self.tab_style = style
        self.apply_settings_to_app()

    def get_general_style(self):
        return f"""
        QWidget {{
            background-color: {self.bg_color};
            color: {self.text_color};
        }}
        QLineEdit, QTextEdit, QComboBox {{
            background-color: {self.input_bg_color};
            color: {self.text_color};
            border: 1px solid {self.border_color};
            padding: 5px;
        }}
        QComboBox::drop-down {{
            border: none;
        }}
        """

    def get_button_style(self):
        return f"""
        QPushButton {{
            background-color: {self.button_color};
            color: {self.text_color};
            border: 1px solid {self.border_color};
            border-radius: 5px;
            padding: 8px 12px;
            font-size: 14px;
            font-weight: bold;
        }}
        QPushButton:hover {{
            background-color: {self.lighten_color(self.button_color)};
        }}
        QPushButton:pressed {{
            background-color: {self.darken_color(self.button_color)};
        }}
        QPushButton:disabled {{
            background-color: #cccccc;
            color: #666666;
            border: 1px solid #999999;
        }}
        """

    def lighten_color(self, color, factor=1.2):
        color = QColor(color)
        h, s, l, _ = color.getHsl()
        lighter_color = QColor.fromHsl(h, s, min(int(l * factor), 255), color.alpha())
        return lighter_color.name()

    def darken_color(self, color, factor=0.8):
        color = QColor(color)
        h, s, l, _ = color.getHsl()
        darker_color = QColor.fromHsl(h, s, max(int(l * factor), 0), color.alpha())
        return darker_color.name()

    def is_dark_color(self, color):
        # Convert color to RGB
        color = QColor(color)
        # Calculate luminance
        luminance = (0.299 * color.red() + 0.587 * color.green() + 0.114 * color.blue()) / 255
        return luminance < 0.5

    def update_color_pickers(self, bg_color, text_color, button_color, border_color, tab_bg_color,
                             selected_tab_bg_color, selected_tab_text_color, input_bg_color):
        self.bg_color = bg_color
        self.text_color = text_color
        self.button_color = button_color
        self.border_color = border_color
        self.tab_bg_color = tab_bg_color
        self.selected_tab_bg_color = selected_tab_bg_color
        self.selected_tab_text_color = selected_tab_text_color
        self.input_bg_color = input_bg_color

        # Update color previews
        self.update_color_preview('bg_color', bg_color)
        self.update_color_preview('text_color', text_color)
        self.update_color_preview('button_color', button_color)
        self.update_color_preview('border_color', border_color)
        self.update_color_preview('tab_bg_color', tab_bg_color)
        self.update_color_preview('selected_tab_bg_color', selected_tab_bg_color)
        self.update_color_preview('selected_tab_text_color', selected_tab_text_color)
        self.update_color_preview('input_bg_color', input_bg_color)

    def on_bg_color_changed(self):
        self.app_instance.bg_color = self.bg_color_picker.color().name()
        self.app_instance.apply_settings()

    def on_text_color_changed(self):
        self.app_instance.text_color = self.text_color_picker.color().name()
        self.app_instance.apply_settings()

    def on_button_color_changed(self):
        self.app_instance.button_color = self.button_color_picker.color().name()
        self.app_instance.apply_settings()

    def on_theme_changed(self, theme):
        self.theme = theme
        if theme == "Light":
            self.bg_color = "#ffffff"
            self.text_color = "#000000"
            self.button_color = "#0078d4"
            self.input_bg_color = "#ffffff"
            self.border_color = "#cccccc"
            self.tab_bg_color = "#f0f0f0"
        elif theme == "Dark":
            self.bg_color = "#1e1e1e"
            self.text_color = "#ffffff"
            self.button_color = "#0078d4"
            self.input_bg_color = "#2d2d2d"
            self.border_color = "#555555"
            self.tab_bg_color = "#2d2d2d"

        self.update_color_previews()
        self.apply_settings_to_app()

    def get_tab_style(self):
        return f"""
        QTabWidget::pane {{
            border: 1px solid {self.border_color};
        }}
        QTabBar::tab {{
            background-color: {self.tab_bg_color};
            color: {self.text_color};
            padding: 10px 20px;
            border: 1px solid {self.border_color};
            border-bottom-color: {self.border_color};
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
        }}
        QTabBar::tab:hover {{
            background-color: {self.lighten_color(self.tab_bg_color)};
        }}
        QTabBar::tab:selected {{
            background-color: {self.selected_tab_bg_color};
            color: {self.selected_tab_text_color};
            border-bottom-color: {self.selected_tab_bg_color};
        }}
        QTabBar::tab:!selected {{
            margin-top: 2px;
        }}
        """

    def change_color(self, attribute_name):
        current_color = getattr(self, attribute_name)
        color_picker = getattr(self, f"{attribute_name}_picker")
        color = color_picker.getColor(QColor(current_color), self, f"Choose {attribute_name.replace('_', ' ').title()}")
        if color.isValid():
            color_name = color.name()
            setattr(self, attribute_name, color_name)
            setattr(self.app_instance, attribute_name, color_name)
            self.update_color_preview(attribute_name, color_name)
            print(f"Changed {attribute_name} to {color_name}")  # Debug print
            self.apply_settings_to_app()

    def update_color_preview(self, attribute_name, color):
        color_buttons = [
            ("Background Color", 'bg_color'),
            ("Text Color", 'text_color'),
            ("Button Color", 'button_color'),
            ("Border Color", 'border_color'),
            ("Tab Background Color", 'tab_bg_color'),
            ("Selected Tab Background Color", 'selected_tab_bg_color'),
            ("Selected Tab Text Color", 'selected_tab_text_color'),
            ("Input Background Color", 'input_bg_color')
        ]
        for index, (_, attr) in enumerate(color_buttons):
            if attr == attribute_name:
                preview = self.findChildren(QLabel)[index + 1]  # +1 to skip the "Color Customization" label
                preview.setStyleSheet(f"background-color: {color}; border: 1px solid #999999;")
                break

    def apply_settings(self):
        self.settings = {
            'bg_color': self.bg_color,
            'text_color': self.text_color,
            'button_color': self.button_color,
            'border_color': self.border_color,
            'tab_bg_color': self.tab_bg_color,
            'selected_tab_bg_color': self.selected_tab_bg_color,
            'selected_tab_text_color': self.selected_tab_text_color,
            'input_bg_color': self.input_bg_color,
            'auto_update_enabled': self.auto_update_checkbox.isChecked(),
            'minimize_to_tray': self.minimize_to_tray_checkbox.isChecked(),
            'debug_mode': self.debug_mode_checkbox.isChecked(),
            'animation_speed': self.animation_speed_slider.value(),
            'theme': self.theme_combo.currentText(),
            'styles': self.styles_input.text()
        }

        button_style = self.get_button_style()
        for button in self.app_instance.findChildren(QPushButton):
            button.setStyleSheet(button_style)
        try:
            with open(self.settings_file, "w") as file:
                json.dump(self.settings, file, indent=4)
            if self.debug_mode:
                print("Settings saved successfully.")
        except Exception as e:
            if self.debug_mode:
                print(f"Failed to save settings: {e}")

        for key, value in self.settings.items():
            setattr(self.app_instance, key, value)
        self.apply_settings_to_app()
        self.app_instance.minimize_to_tray = self.minimize_to_tray_checkbox.isChecked()
        self.animate_apply_button()

    def apply_settings_to_app(self):
        # Update main app's color attributes
        self.app_instance.bg_color = self.bg_color
        self.app_instance.text_color = self.text_color
        self.app_instance.button_color = self.button_color
        self.app_instance.border_color = self.border_color
        self.app_instance.tab_bg_color = self.tab_bg_color
        self.app_instance.selected_tab_bg_color = self.selected_tab_bg_color
        self.app_instance.selected_tab_text_color = self.selected_tab_text_color
        self.app_instance.input_bg_color = self.input_bg_color

        # Apply settings
        self.app_instance.apply_settings()

    def animate_apply_button(self):
        animation = QPropertyAnimation(self.apply_btn, b"geometry")
        animation.setDuration(300)
        animation.setStartValue(self.apply_btn.geometry())
        animation.setEndValue(self.apply_btn.geometry().adjusted(-5, -5, 5, 5))
        animation.setEasingCurve(QEasingCurve.OutBounce)
        animation.start()

    def save_settings(self):
        self.settings = {
            'bg_color': self.bg_color,
            'text_color': self.text_color,
            'button_color': self.button_color,
            'border_color': self.border_color,
            'tab_bg_color': self.tab_bg_color,
            'selected_tab_bg_color': self.selected_tab_bg_color,
            'selected_tab_text_color': self.selected_tab_text_color,
            'input_bg_color': self.input_bg_color,
            'auto_update_enabled': self.auto_update_checkbox.isChecked(),
            'minimize_to_tray': self.minimize_to_tray_checkbox.isChecked(),
            'debug_mode': self.debug_mode_checkbox.isChecked(),
            'tab_style': self.tab_style_combo.currentText(),
            'theme': self.theme_combo.currentText()
        }
        try:
            with open(self.settings_file, "w") as file:
                json.dump(self.settings, file, indent=4)
            print("Settings saved successfully.")
            self.apply_settings_to_app()
        except Exception as e:
            print(f"Failed to save settings: {e}")

    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, "r") as file:
                    self.settings = json.load(file)
                    self.bg_color = self.settings.get("bg_color", self.bg_color)
                    self.text_color = self.settings.get("text_color", self.text_color)
                    self.button_color = self.settings.get("button_color", self.button_color)
                    self.border_color = self.settings.get("border_color", self.border_color)
                    self.tab_bg_color = self.settings.get("tab_bg_color", self.tab_bg_color)
                    self.selected_tab_bg_color = self.settings.get("selected_tab_bg_color", self.selected_tab_bg_color)
                    self.selected_tab_text_color = self.settings.get("selected_tab_text_color",
                                                                     self.selected_tab_text_color)
                    self.input_bg_color = self.settings.get("input_bg_color", self.input_bg_color)
                    self.auto_update_enabled = self.settings.get("auto_update_enabled", True)
                    self.auto_update_checkbox.setChecked(self.auto_update_enabled)
                    self.minimize_to_tray = self.settings.get("minimize_to_tray", self.minimize_to_tray)
                    self.debug_mode = self.settings.get("debug_mode", self.debug_mode)
                    self.tab_style = self.settings.get("tab_style", self.tab_style)
                    self.theme = self.settings.get("theme", "Light")
                    self.theme_combo.setCurrentText(self.theme)
                    self.on_theme_changed(self.theme)  # Apply the theme

                    # Update UI elements
                    self.update_color_previews()
                    self.minimize_to_tray_checkbox.setChecked(self.minimize_to_tray)
                    self.debug_mode_checkbox.setChecked(self.debug_mode)
                    self.tab_style_combo.setCurrentText(self.tab_style)

                    # Apply settings to the main app
                    self.apply_settings_to_app()
            except Exception as e:
                print(f"Failed to load settings: {e}")

    def update_color_previews(self):
        color_attributes = ['bg_color', 'text_color', 'button_color', 'border_color', 'tab_bg_color',
                            'selected_tab_bg_color', 'selected_tab_text_color']
        for attr in color_attributes:
            color = getattr(self, attr)
            if color:
                self.update_color_preview(attr, color)
