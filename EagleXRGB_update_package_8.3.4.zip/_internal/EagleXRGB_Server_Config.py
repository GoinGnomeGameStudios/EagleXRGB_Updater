import ctypes
import ipaddress
import json
import mimetypes
import multiprocessing
import os
import socket
import ssl
import subprocess
import sys
import urllib
from datetime import datetime, timedelta
from http.server import HTTPServer, SimpleHTTPRequestHandler

import requests
from PyQt5.QtCore import QObject, QThread, Qt, pyqtSignal
from PyQt5.QtWidgets import QCheckBox, QDialog, QFileDialog, QFormLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, \
    QWidget
from cryptography import x509
from cryptography.hazmat._oid import NameOID
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from EagleXRGB_custom_widgets import CustomFileDialog


class WorkerSignals(QObject):
    """
    Define the signals for worker thread.
    """
    error = pyqtSignal(str)
    finished = pyqtSignal()
    progress = pyqtSignal(int)


class HTTPServerConfigTab(QWidget):
    save_settings_signal = pyqtSignal()

    def __init__(self, console_tab=None, settings_tab=None, config_file='config/EagleXRGB_https_settings.json', *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.console_tab = console_tab
        self.settings_tab = settings_tab
        self.config_file = config_file
        self.worker_signals = WorkerSignals()
        self.debug_mode = False
        self.file_paths = []
        self.favicon_path = 'icons/favicon.ico'

        # Initialize UI elements
        self.ip_input = QLineEdit('127.0.0.1')
        self.base_dir_input = QLineEdit()
        self.file_btn = QPushButton('Add Files to Serve')
        self.file_list = QLabel('No files selected.')
        self.port_input = QLineEdit()
        self.cert_key_checkbox = QCheckBox('Use custom certificate and key files')
        self.cert_btn = QPushButton('Select Certificate File')
        self.cert_path = QLineEdit()
        self.key_btn = QPushButton('Select Key File')
        self.key_path = QLineEdit()
        self.auto_generate_checkbox = QCheckBox('Auto-generate certificate and key files if not provided')
        self.import_cert_btn = QPushButton('Import Certificate')  # New button
        self.check_file_btn = QPushButton('Check Event Trigger File')
        self.debug_mode_checkbox = QCheckBox("Enable Debug Mode", self)
        self.save_btn = QPushButton('Save Settings')

        # Set up the UI
        self.initUI()

        # Load settings after UI is initialized
        self.load_settings()

    def initUI(self):
        layout = QVBoxLayout()
        # ... (rest of the UI setup code, using the pre-initialized UI elements)

        self.setLayout(layout)

        # Apply customization styles
        self.apply_settings()

        # Apply button styles explicitly
        self.apply_button_styles()

    def initUI(self):
        layout = QVBoxLayout()
        title = QLabel("HTTP Server Configuration")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.ip_input = QLineEdit('127.0.0.1')
        self.ip_input.setToolTip("Enter the IP address for the HTTP server")
        layout.addWidget(QLabel('IP Address:'))
        layout.addWidget(self.ip_input)

        self.base_dir_input = QLineEdit()
        self.base_dir_input.setPlaceholderText('Leave blank to use the script directory')
        self.base_dir_input.setToolTip("Set the base directory for serving files (leave blank to use script directory)")
        layout.addWidget(QLabel('Base Directory:'))
        layout.addWidget(self.base_dir_input)

        base_dir_info = QLabel(
            "If you leave this field blank, the server will use the directory where the script is located.")
        layout.addWidget(base_dir_info)

        file_layout = QFormLayout()
        self.file_paths = []
        self.file_btn = QPushButton('Add Files to Serve')
        self.file_btn.setToolTip("Select files to be served by the HTTP server")
        self.file_btn.clicked.connect(self.openFileDialog)
        self.file_list = QLabel('No files selected.')
        file_layout.addRow(self.file_btn, self.file_list)
        layout.addLayout(file_layout)

        self.port_input = QLineEdit()
        self.port_input.setPlaceholderText('Leave blank for default port (80 for HTTP, 443 for HTTPS)')
        layout.addWidget(QLabel('Port:'))
        layout.addWidget(self.port_input)

        self.cert_key_checkbox = QCheckBox('Use custom certificate and key files')
        layout.addWidget(self.cert_key_checkbox)

        self.cert_btn = QPushButton('Select Certificate File')
        self.cert_btn.clicked.connect(lambda: self.openFileDialog('cert'))
        self.cert_path = QLineEdit()
        self.cert_path.setPlaceholderText('No certificate file selected.')
        self.cert_btn.setEnabled(False)
        layout.addWidget(self.cert_btn)
        layout.addWidget(self.cert_path)

        self.key_btn = QPushButton('Select Key File')
        self.key_btn.clicked.connect(lambda: self.openFileDialog('key'))
        self.key_path = QLineEdit()
        self.key_path.setPlaceholderText('No key file selected.')
        self.key_btn.setEnabled(False)
        layout.addWidget(self.key_btn)
        layout.addWidget(self.key_path)

        self.cert_key_checkbox.stateChanged.connect(self.toggleCertKeySelection)

        self.auto_generate_checkbox = QCheckBox('Auto-generate certificate and key files if not provided')
        layout.addWidget(self.auto_generate_checkbox)

        self.check_file_btn = QPushButton('Check Event Trigger File')
        self.check_file_btn.clicked.connect(self.check_event_trigger_file)
        layout.addWidget(self.check_file_btn)

        # Add the new Import Certificate button
        self.import_cert_btn.clicked.connect(self.import_certificate)
        layout.addWidget(self.import_cert_btn)

        # Add Debug Mode Checkbox
        self.debug_mode_checkbox = QCheckBox("Enable Debug Mode", self)
        self.debug_mode_checkbox.setToolTip("Check to enable debug mode.")
        self.debug_mode_checkbox.stateChanged.connect(self.toggle_debug_mode)
        layout.addWidget(self.debug_mode_checkbox)

        self.save_btn = QPushButton('Save Settings')
        self.save_btn.clicked.connect(self.save_settings)
        layout.addWidget(self.save_btn)

        # Apply centralized button styling
        button_style = self.settings_tab.get_button_style()
        for button in self.findChildren(QPushButton):
            button.setStyleSheet(button_style)

        self.setLayout(layout)

        # Apply customization styles
        self.apply_settings()

        # Apply button styles explicitly
        self.apply_button_styles()

    def update_button_states(self):
        base_directory = self.base_dir_input.text() or os.getcwd()
        cert_file = os.path.join(base_directory, 'EagleXRGB_server_cert.pem')
        key_file = os.path.join(base_directory, 'EagleXRGB_server_key.key')

        certificates_exist = os.path.exists(cert_file) and os.path.exists(key_file)

        self.auto_generate_checkbox.setEnabled(not certificates_exist)
        self.import_cert_btn.setEnabled(certificates_exist)

        if certificates_exist:
            self.cert_path.setText(cert_file)
            self.key_path.setText(key_file)

    def toggle_debug_mode(self, state):
        self.debug_mode = (state == Qt.Checked)
        self.console_tab.updateConsole(f"Debug mode {'enabled' if self.debug_mode else 'disabled'}.")
        # Save settings after change
        self.save_settings()

    def set_button_style(self, button_style):
        # Apply button style to all buttons in this tab
        self.file_btn.setStyleSheet(button_style)
        self.check_file_btn.setStyleSheet(button_style)
        self.save_btn.setStyleSheet(button_style)
        self.key_btn.setStyleSheet(button_style)
        self.cert_btn.setStyleSheet(button_style)

    def apply_settings(self):
        self.settings_tab.apply_settings()

    def apply_button_styles(self):
        if hasattr(self.settings_tab, 'get_button_styles'):
            self.console_tab.updateConsole("get_button_styles exists")
            button_styles = self.settings_tab.get_button_styles()

            # Apply the button styles explicitly to each button
            for button in [
                self.file_btn,
                self.cert_btn,
                self.key_btn,
                self.check_file_btn,
                self.save_btn,
                self.import_cert_btn
            ]:
                button.setStyleSheet(f"QPushButton {{ {button_styles} }}")
        else:
            print("get_button_styles does not exist in CustomizationTab")

    def get_button_styles(self):
        # Example button styles
        return "background-color: #4CAF50; color: white; border: 1px solid #4CAF50; padding: 10px 24px; font-size: 16px;"

    def apply_specific_styles(self, settings_tab):
        # Apply any specific styles for the HTTPServerConfigTab
        pass

    def openFileDialog(self, file_type=None):
        if file_type == 'cert':
            dialog = CustomFileDialog(self, "Select Certificate File", "", "Certificate Files (*.pem);;All Files (*)",
                                      mode="single")
            if dialog.exec_() == QDialog.Accepted:
                file_path = dialog.getSelectedFiles()[0]
                if file_path:
                    self.cert_path.setText(file_path)
        elif file_type == 'key':
            dialog = CustomFileDialog(self, "Select Key File", "", "Key Files (*.key);;All Files (*)", mode="single")
            if dialog.exec_() == QDialog.Accepted:
                file_path = dialog.getSelectedFiles()[0]
                if file_path:
                    self.key_path.setText(file_path)
        else:
            dialog = CustomFileDialog(self, "Select Files to Serve", "", "All Files (*)", mode="multi")
            if dialog.exec_() == QDialog.Accepted:
                self.file_paths = dialog.getSelectedFiles()
                self.file_list.setText('\n'.join(self.file_paths))
                print("Selected file paths:", self.file_paths)  # Debug print

    def fetch_file_from_url(self, url):
        try:
            response = requests.get(url)
            response.raise_for_status()  # Raise an HTTPError for bad responses
            return response.text  # Return the file content as text
        except requests.RequestException as e:
            print(f"Error fetching file from URL: {e}")
            return None

    def check_event_trigger_file(self):
        base_url = f"https://{self.ip_input.text()}"
        if self.port_input.text():
            base_url += f":{self.port_input.text()}"
        url = f"{base_url}/EDCoPilot.EventTrigger.txt"
        content = self.fetch_file_from_url(url)
        if content:
            print("File content fetched successfully:")
            print(content)
        else:
            print("Failed to fetch file content.")

    def toggleCertKeySelection(self):
        state = self.cert_key_checkbox.isChecked()
        self.cert_btn.setEnabled(state)
        self.key_btn.setEnabled(state)
        if not state:
            self.cert_path.setText('')
            self.key_path.setText('')

    def check_existing_cert_key_files(self, base_directory):
        if base_directory and os.path.isdir(base_directory):
            cert_file = os.path.join(base_directory, 'EagleXRGB_server_cert.pem')
            key_file = os.path.join(base_directory, 'EagleXRGB_server_key.key')
            if os.path.exists(cert_file):
                self.cert_path.setText(cert_file)
            if os.path.exists(key_file):
                self.key_path.setText(key_file)
        else:
            if self.console_tab:
                if self.debug_mode:
                    self.console_tab.updateConsole("Error: Base directory does not exist.")

    @staticmethod
    def generate_cert_key(base_directory, ip_address):
        try:
            # Generate a private key
            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

            # Convert the IP address string to an ipaddress.IPv4Address or ipaddress.IPv6Address object
            ip_addr = ipaddress.ip_address(ip_address)

            # Create a self-signed certificate with SAN for the provided IP address
            subject = issuer = x509.Name([
                x509.NameAttribute(NameOID.COUNTRY_NAME, u"US"),
                x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"State"),
                x509.NameAttribute(NameOID.LOCALITY_NAME, u"Locality"),
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"Organization"),
                x509.NameAttribute(NameOID.COMMON_NAME, ip_address),
            ])

            # Add Subject Alternative Name (SAN) with the provided IP address
            alt_names = x509.SubjectAlternativeName([x509.IPAddress(ip_addr)])

            cert = x509.CertificateBuilder() \
                .subject_name(subject) \
                .issuer_name(issuer) \
                .public_key(key.public_key()) \
                .serial_number(x509.random_serial_number()) \
                .not_valid_before(datetime.utcnow()) \
                .not_valid_after(datetime.utcnow() + timedelta(days=365)) \
                .add_extension(alt_names, critical=False) \
                .sign(key, hashes.SHA256(), default_backend())

            # Define paths for certificate and key files
            cert_file_path = os.path.join(base_directory, 'EagleXRGB_server_cert.pem')
            key_file_path = os.path.join(base_directory, 'EagleXRGB_server_key.key')

            # Write the certificate and key to files
            with open(cert_file_path, 'wb') as cert_file:
                cert_file.write(cert.public_bytes(encoding=serialization.Encoding.PEM))
            with open(key_file_path, 'wb') as key_file:
                key_file.write(key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()))

            print(f"Certificate and key generated: {cert_file_path}, {key_file_path}")
            return cert_file_path, key_file_path

        except Exception as e:
            print(f"Error generating certificate and key: {e}")
            return None, None

    def import_certificate(self):
        base_directory = self.base_dir_input.text() or os.getcwd()
        cert_file = self.cert_path.text()
        if os.path.exists(cert_file):
            self.run_import_cert_script(base_directory)
        else:
            self.console_tab.updateConsole("Certificate file not found.")

    def run_import_cert_script(self, base_directory):
        import_cert_script = os.path.join(base_directory, 'EagleXRGB_import_cert.bat')
        cert_file = self.cert_path.text()

        if os.path.exists(import_cert_script):
            self.console_tab.updateConsole(f"Running {import_cert_script} to import certificate...")

            # Check if running with admin privileges
            if self.is_admin():
                command = [import_cert_script, cert_file]
                self.console_tab.updateConsole(f"Executing command: {command}")

                try:
                    result = subprocess.run(command, check=True, text=True, capture_output=True)
                    self.console_tab.updateConsole(f"Batch script output:\n{result.stdout}")
                    if "CertUtil: -addstore command completed successfully." in result.stdout:
                        self.console_tab.updateConsole("Certificate imported successfully.")
                    else:
                        self.console_tab.updateConsole("Certificate import may have failed. Please check the output.")
                except subprocess.CalledProcessError as e:
                    self.console_tab.updateConsole(f"Error occurred while running the batch script: {e}")
                    self.console_tab.updateConsole(f"Batch script output:\n{e.output}")
                except Exception as e:
                    self.console_tab.updateConsole(f"Unexpected error: {e}")
            else:
                self.console_tab.updateConsole("Administrator privileges are required to import the certificate.")
                self.console_tab.updateConsole("Please follow these steps to import the certificate:")
                self.console_tab.updateConsole("1. Right-click on the EagleXRGB_import_cert.bat file")
                self.console_tab.updateConsole("2. Select 'Run as administrator'")
                self.console_tab.updateConsole(f"3. When prompted, enter the full path to the certificate: {cert_file}")
                self.console_tab.updateConsole("After completing these steps, the certificate should be imported.")
        else:
            self.console_tab.updateConsole(f"EagleXRGB_import_cert.bat not found in base directory: {base_directory}")

    def is_admin(self):
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except:
            return False

    @staticmethod
    def add_cert_to_trusted_roots(cert_file):
        # PowerShell command to add the certificate to the Trusted Root Certification Authorities
        powershell_command = f'''
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("{cert_file}")
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root","LocalMachine")
        $store.Open("ReadWrite")
        $store.Add($cert)
        $store.Close()
        '''

        # Run the PowerShell command as Administrator
        try:
            subprocess.run(["powershell", "-Command", powershell_command], shell=True, check=True)
        except subprocess.CalledProcessError as e:
            print(f"Failed to add certificate to Trusted Root Certification Authorities: {e}")

    def save_settings(self):
        base_directory = self.base_dir_input.text() or os.getcwd()
        ip_address = self.ip_input.text()
        port = self.port_input.text().strip()

        # Ensure port is always a valid number
        try:
            port = int(port)
        except ValueError:
            port = 443  # Default to 443 if not a valid number

        # Prepare final file paths
        final_file_paths = []
        for path in self.file_paths:
            if os.path.exists(path):
                final_file_paths.append(path)
            else:
                print(f"File does not exist: {path}")

        if not os.path.isdir(base_directory):
            os.makedirs(base_directory, exist_ok=True)

        if self.cert_key_checkbox.isChecked():
            cert_file_path = self.cert_path.text()
            key_file_path = self.key_path.text()
            if not cert_file_path or not key_file_path:
                if self.auto_generate_checkbox.isChecked():
                    cert_file_path, key_file_path = self.generate_cert_key(base_directory, ip_address)
                    if not cert_file_path or not key_file_path:
                        print("Error: Failed to generate certificate and key files.")
                        return
                else:
                    print("Error: Certificate or key file not provided.")
                    return
            final_cert_path = cert_file_path
            final_key_path = key_file_path
        elif self.auto_generate_checkbox.isChecked():
            final_cert_path, final_key_path = self.generate_cert_key(base_directory, ip_address)
            if not final_cert_path or not final_key_path:
                print("Error: Failed to generate certificate and key files.")
                return
        else:
            final_cert_path = None
            final_key_path = None

        settings = {
            'base_directory': base_directory,
            'ip_address': ip_address,
            'port': port,
            'file_paths': final_file_paths,
            'cert_file': final_cert_path,
            'key_file': final_key_path,
            'use_custom_cert_key': self.cert_key_checkbox.isChecked(),
            'auto_generate_cert_key': self.auto_generate_checkbox.isChecked(),
            'favicon_path': self.favicon_path
        }

        with open(self.config_file, 'w') as f:
            json.dump(settings, f, indent=4)
        print(f"Settings saved to {self.config_file}")
        self.save_settings_signal.emit()

    def load_settings(self):
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                https_settings = json.load(f)
                self.file_paths = https_settings.get('file_paths', [])
                self.ip_input.setText(https_settings.get('ip_address', '127.0.0.1'))

                # Ensure port is always a valid number when loading
                port = https_settings.get('port', 443)
                self.port_input.setText(str(port) if port is not None else '443')

                self.cert_path.setText(https_settings.get('cert_file', ''))
                self.key_path.setText(https_settings.get('key_file', ''))
                self.base_dir_input.setText(https_settings.get('base_directory', ''))
                self.cert_key_checkbox.setChecked(https_settings.get('use_custom_cert_key', False))
                self.auto_generate_checkbox.setChecked(https_settings.get('auto_generate_cert_key', False))
                self.favicon_path = https_settings.get('favicon_path', '')
                self.file_list.setText('\n'.join(self.file_paths))
                if self.console_tab:
                    self.console_tab.updateConsole("HTTPS Settings loaded.")
                return https_settings
        else:
            return {}


class ServerProcess(multiprocessing.Process):
    def __init__(self, command, queue):
        super().__init__()
        self.command = command
        self.queue = queue

    def run(self):
        import importlib.util
        import sys

        spec = importlib.util.spec_from_file_location("server_module", self.command[1])
        server_module = importlib.util.module_from_spec(spec)
        sys.modules["server_module"] = server_module
        spec.loader.exec_module(server_module)

        server_module.run_server(self.command[2], self.queue)


class ServerThread(QThread):
    output_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)

    def __init__(self, command, console_tab):
        super().__init__()
        self.console_tab = console_tab
        self.command = command
        self.process = None
        self.queue = multiprocessing.Queue()

    def run(self):
        try:
            self.console_tab.updateConsole(f"ServerThread: Starting server with command: {' '.join(self.command)}")

            self.process = ServerProcess(self.command, self.queue)
            self.process.start()

            self.console_tab.updateConsole("ServerThread: Server process created successfully")
            self.output_signal.emit(f"Server process started with PID: {self.process.pid}")

            while True:
                try:
                    message = self.queue.get(timeout=0.1)
                    self.console_tab.updateConsole(message)
                except multiprocessing.queues.Empty:
                    if not self.process.is_alive():
                        break

            exit_code = self.process.exitcode
            self.console_tab.updateConsole(f"ServerThread: Server process exited with code: {exit_code}")
            self.output_signal.emit(f"Server process exited with code: {exit_code}")

        except Exception as e:
            self.console_tab.updateConsole(f"ServerThread error: {str(e)}")
            self.error_signal.emit(f"ServerThread error: {str(e)}")

    def stop(self):
        if self.process and self.process.is_alive():
            self.output_signal.emit("Attempting to stop server...")
            self.process.terminate()
            try:
                self.process.join(timeout=5)
                if self.process.is_alive():
                    self.output_signal.emit("Server did not stop gracefully. Forcing termination...")
                    self.process.kill()
                    self.process.join()
                self.output_signal.emit("Server stopped.")
            except Exception as e:
                self.error_signal.emit(f"Error stopping server: {str(e)}")


class CustomHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        self.server.queue.put(f"Received GET request for: {self.path}")
        decoded_path = urllib.parse.unquote(self.path)
        file_name = decoded_path.lstrip('/')

        if self.path == '/favicon.ico':
            if hasattr(self.server, 'favicon_path') and os.path.exists(self.server.favicon_path):
                self.send_response(200)
                self.send_header('Content-type', 'image/x-icon')
                self.end_headers()
                with open(self.server.favicon_path, 'rb') as favicon:
                    self.wfile.write(favicon.read())
                return
            else:
                self.send_error(404, "Favicon not found")
                return

        if file_name in self.server.file_map:
            file_path = self.server.file_map[file_name]
            if os.path.exists(file_path):
                self.send_response(200)
                content_type, _ = mimetypes.guess_type(file_path)
                self.send_header('Content-type', content_type or 'application/octet-stream')
                self.end_headers()
                with open(file_path, 'rb') as file:
                    self.wfile.write(file.read())
                self.server.queue.put(f"Successfully served file: {file_name}")
            else:
                self.send_error(404, "File not found")
                self.server.queue.put(f"Error: File not found at path: {file_path}")
        else:
            self.send_error(404, "File not found")
            self.server.queue.put(f"Error: File {file_name} not in server file map")

    def log_message(self, format, *args):
        self.server.queue.put(f"Server log: {format % args}")


def load_settings(settings_file):
    with open(settings_file, 'r') as f:
        return json.load(f)


def run_server(settings_file, queue):
    settings = load_settings(settings_file)

    ip = settings.get('ip_address', '127.0.0.1')

    # Ensure port is always a valid number
    port = settings.get('port', 443)
    try:
        port = int(port)
    except ValueError:
        port = 443  # Default to 443 if not a valid number

    cert_file = settings.get('cert_file')
    key_file = settings.get('key_file')
    base_directory = settings.get('base_directory')
    file_paths = settings.get('file_paths', [])

    favicon_path = settings.get('favicon_path', '')

    queue.put(f"Starting server with configuration:")
    queue.put(f"  IP: {ip}")
    queue.put(f"  Port: {port}")
    queue.put(f"  Certificate file: {cert_file}")
    queue.put(f"  Key file: {key_file}")
    queue.put(f"  Base directory: {base_directory}")

    os.chdir(base_directory)
    handler = CustomHandler

    try:
        httpd = HTTPServer((ip, port), handler)
        httpd.queue = queue
        httpd.file_map = {os.path.basename(path): path for path in file_paths}
        if favicon_path:
            httpd.favicon_path = favicon_path

        if cert_file and key_file:
            try:
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                context.load_cert_chain(certfile=cert_file, keyfile=key_file)
                httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
                queue.put(f"HTTPS Server running on https://{ip}:{port}")
            except Exception as e:
                queue.put(f"Error setting up HTTPS: {str(e)}")
                return
        else:
            queue.put(f"HTTP Server running on http://{ip}:{port}")

        queue.put("Serving files:")
        for file_name, file_path in httpd.file_map.items():
            queue.put(f"  /{file_name} -> {file_path}")

        queue.put("Server is ready to accept connections")
        httpd.serve_forever()
    except socket.error as e:
        if e.errno == 13:  # Permission denied
            queue.put(
                f"Error: Permission denied. Try running the application as administrator or use a port number > 1024.")
        elif e.errno == 10048:  # Address already in use
            queue.put(f"Error: Port {port} is already in use. Try a different port.")
        else:
            queue.put(f"Socket error: {str(e)}")
    except Exception as e:
        queue.put(f"Unexpected error: {str(e)}")
    finally:
        if 'httpd' in locals():
            httpd.server_close()
        queue.put("Server stopped.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python EagleXRGB_Server_Config.py <path_to_settings_json>")
        sys.exit(1)

    settings_file = sys.argv[1]
    run_server(settings_file, multiprocessing.Queue())
