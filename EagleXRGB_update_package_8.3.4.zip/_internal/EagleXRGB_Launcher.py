import os
import sys
import subprocess
import requests
import json
import logging
from PyQt5.QtWidgets import QApplication, QMessageBox
from EagleXRGB_version_utils import CURRENT_APP_VERSION, base_update_url

# Set up logging
logging.basicConfig(filename='EagleXRGB_Launcher.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


def check_for_updates():
    try:
        logging.info(f"Checking for updates. Current version: {CURRENT_APP_VERSION}")
        response = requests.get(f"{base_update_url}/EagleXRGB_version.json")
        version_info = json.loads(response.text)
        logging.info(f"Latest version from server: {version_info['latest_version']}")
        return version_info['latest_version'] > CURRENT_APP_VERSION, version_info
    except Exception as e:
        logging.error(f"Error checking for updates: {e}", exc_info=True)
        return False, None


def run_updater():
    updater_path = "EagleXRGB_Updater.exe"
    logging.info(f"Starting updater: {updater_path}")
    try:
        subprocess.run([updater_path, CURRENT_APP_VERSION, base_update_url])
    except Exception as e:
        logging.error(f"Error running updater: {e}", exc_info=True)


def run_main_app():
    check_for_deferred_updates()
    app_path = "EagleXRGB_Connector.exe"
    logging.info(f"Starting main application: {app_path}")
    try:
        subprocess.run([app_path])
    except Exception as e:
        logging.error(f"Error running main application: {e}", exc_info=True)


def check_for_deferred_updates():
    if os.path.exists("finalize_update.bat"):
        logging.info("Deferred updates found. Executing finalize_update.bat")
        subprocess.call("finalize_update.bat")
        logging.info("Finalize update process completed")


def main():
    logging.info("Launcher started")
    app = QApplication(sys.argv)

    update_available, version_info = check_for_updates()

    if update_available:
        logging.info("Update available. Prompting user.")
        msg = f"A new update is available.\nCurrent version: {CURRENT_APP_VERSION}\nLatest version: {version_info['latest_version']}\nDo you want to update now?"
        reply = QMessageBox.question(None, 'Update Available', msg, QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)

        if reply == QMessageBox.Yes:
            logging.info("User chose to update. Starting update process.")
            run_updater()
            logging.info("Update process completed. Exiting launcher.")
            sys.exit(0)  # Exit after update
        else:
            logging.info("User chose not to update.")

    logging.info("Starting main application.")
    run_main_app()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.critical(f"Unhandled exception in launcher: {e}", exc_info=True)
        print(f"A critical error occurred. Please check the log file for details.")
