import os
import sys
import subprocess
import json
import logging

import requests
from PyQt5.QtWidgets import QApplication, QMessageBox, QProgressDialog
from PyQt5.QtCore import QThread, pyqtSignal

# Ensure _internal is in the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '_internal'))
from EagleXRGB_version_utils import get_current_version, compare_versions, base_update_url

# Set up logging
logging.basicConfig(filename='EagleXRGB_Launcher.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class UpdateCheckerThread(QThread):
    update_available = pyqtSignal(dict)
    check_complete = pyqtSignal(bool)

    def run(self):
        try:
            current_version = get_current_version()
            logging.info(f"Current version: {current_version}")

            response = requests.get(f"{base_update_url}/EagleXRGB_version.json")
            response.raise_for_status()  # This will raise an HTTPError for bad responses

            version_info = response.json()
            logging.info(f"Latest version from server: {version_info['latest_version']}")

            comparison_result = compare_versions(version_info['latest_version'], current_version)
            logging.info(f"Version comparison result: {comparison_result}")

            if comparison_result > 0:
                logging.info("Update is available")
                self.update_available.emit(version_info)
            else:
                logging.info("No update available")
                self.check_complete.emit(False)
        except requests.exceptions.RequestException as e:
            logging.error(f"Error fetching update information: {e}", exc_info=True)
            self.check_complete.emit(False)
        except json.JSONDecodeError as e:
            logging.error(f"Error parsing update information: {e}", exc_info=True)
            self.check_complete.emit(False)
        except Exception as e:
            logging.error(f"Unexpected error checking for updates: {e}", exc_info=True)
            self.check_complete.emit(False)


class UpdaterThread(QThread):
    progress_update = pyqtSignal(int, str)
    update_complete = pyqtSignal(bool, str)

    def __init__(self, version_info):
        super().__init__()
        self.version_info = version_info

    def run(self):
        try:
            updater_path = os.path.join(os.path.dirname(sys.executable), 'EagleXRGB_Updater.exe')
            logging.info(f"Attempting to run updater at: {updater_path}")

            if not os.path.exists(updater_path):
                raise FileNotFoundError(f"Updater executable not found at {updater_path}")

            result = subprocess.run([updater_path, json.dumps(self.version_info)],
                                    capture_output=True, text=True, check=True)

            logging.info(f"Updater output: {result.stdout}")
            if result.stderr:
                logging.warning(f"Updater errors: {result.stderr}")

            self.update_complete.emit(True, "Update completed successfully!")
        except subprocess.CalledProcessError as e:
            error_msg = f"Update failed: {e.stderr}"
            logging.error(error_msg)
            self.update_complete.emit(False, error_msg)
        except FileNotFoundError as e:
            error_msg = str(e)
            logging.error(error_msg)
            self.update_complete.emit(False, error_msg)
        except Exception as e:
            error_msg = f"Unexpected error during update: {str(e)}"
            logging.error(error_msg, exc_info=True)
            self.update_complete.emit(False, error_msg)


class Launcher:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.load_settings()

    def load_settings(self):
        try:
            with open('config/EagleXRGB_settings.json', 'r') as f:
                self.settings = json.load(f)
            logging.info(f"Settings loaded: {self.settings}")
        except FileNotFoundError:
            self.settings = {'auto_update': True}
            logging.warning("Settings file not found. Using default settings.")

    def check_for_updates(self):
        logging.info("Checking for updates")
        self.update_checker = UpdateCheckerThread()
        self.update_checker.update_available.connect(self.on_update_available)
        self.update_checker.check_complete.connect(self.on_check_complete)
        self.update_checker.start()

    def on_update_available(self, version_info):
        logging.info(f"Update available: {version_info}")
        if self.settings.get('auto_update', True):
            logging.info("Auto-update is enabled. Starting update process.")
            self.start_update(version_info)
        else:
            logging.info("Auto-update is disabled. Prompting user.")
            reply = QMessageBox.question(None, 'Update Available',
                                         f"A new update (version {version_info['latest_version']}) is available. Do you want to update now?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)

            if reply == QMessageBox.Yes:
                logging.info("User chose to update. Starting update process.")
                self.start_update(version_info)
            else:
                logging.info("User chose not to update. Launching main app.")
                self.launch_main_app()

    def on_check_complete(self, update_available):
        if not update_available:
            logging.info("No update available. Launching main app.")
            self.launch_main_app()

    def start_update(self, version_info):
        self.progress_dialog = QProgressDialog("Updating...", "Cancel", 0, 100)
        self.progress_dialog.setWindowTitle("EagleXRGB Updater")
        self.progress_dialog.setAutoClose(False)
        self.progress_dialog.setAutoReset(False)

        self.updater_thread = UpdaterThread(version_info)
        self.updater_thread.progress_update.connect(self.update_progress)
        self.updater_thread.update_complete.connect(self.on_update_complete)
        self.updater_thread.start()

        self.progress_dialog.exec_()

    def update_progress(self, value, message):
        self.progress_dialog.setValue(value)
        self.progress_dialog.setLabelText(message)

    def on_update_complete(self, success, message):
        self.progress_dialog.close()
        if success:
            QMessageBox.information(None, "Update Complete",
                                    "The application has been updated successfully. It will now restart.")
            self.restart_application()
        else:
            QMessageBox.warning(None, "Update Failed",
                                f"The update process failed: {message}\nThe application will start with the current version.")
            self.launch_main_app()

    def launch_main_app(self):
        logging.info("Launching main application")
        try:
            main_app_path = os.path.join(os.path.dirname(sys.executable), "EagleXRGB_Connector.exe")
            logging.info(f"Attempting to launch main app from: {main_app_path}")

            if not os.path.exists(main_app_path):
                raise FileNotFoundError(f"Main application executable not found at {main_app_path}")

            subprocess.Popen([main_app_path])
            logging.info("Main application launched successfully")
        except FileNotFoundError as e:
            logging.error(f"Main application executable not found: {e}", exc_info=True)
            QMessageBox.critical(None, "Launch Error",
                                 f"The main application executable was not found. Please ensure it is in the correct location: {main_app_path}")
        except Exception as e:
            logging.error(f"Failed to launch main application: {e}", exc_info=True)
            QMessageBox.critical(None, "Launch Error", f"Failed to start the main application: {str(e)}")
        finally:
            sys.exit(0)

    def restart_application(self):
        logging.info("Restarting application")
        try:
            launcher_path = sys.executable
            subprocess.Popen([launcher_path])
            logging.info("Application restart initiated")
        except Exception as e:
            logging.error(f"Failed to restart application: {e}", exc_info=True)
            QMessageBox.critical(None, "Restart Error", "Failed to restart the application. Please start it manually.")
        finally:
            sys.exit(0)

    def run(self):
        logging.info("Launcher run method called")
        self.check_for_updates()
        sys.exit(self.app.exec_())


if __name__ == "__main__":
    try:
        logging.info("Starting EagleXRGB Launcher")
        launcher = Launcher()
        launcher.run()
    except Exception as e:
        logging.critical(f"Unhandled exception in launcher: {e}", exc_info=True)
        print(f"A critical error occurred. Please check the log file for details.")
