import os
import sys
import subprocess
import json
import logging

import requests
from PyQt5.QtWidgets import QApplication, QMessageBox, QProgressDialog
from PyQt5.QtCore import QThread, pyqtSignal

# Ensure _internal is in the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '_internal'))
from EagleXRGB_version_utils import get_current_version, compare_versions, base_update_url

# Set up logging
logging.basicConfig(filename='EagleXRGB_Launcher.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class UpdateCheckerThread(QThread):
    update_available = pyqtSignal(dict)
    check_complete = pyqtSignal(bool)

    def run(self):
        try:
            current_version = get_current_version()
            response = requests.get(f"{base_update_url}/EagleXRGB_version.json")
            version_info = response.json()

            if compare_versions(version_info['latest_version'], current_version) > 0:
                self.update_available.emit(version_info)
            else:
                self.check_complete.emit(False)
        except Exception as e:
            logging.error(f"Error checking for updates: {e}")
            self.check_complete.emit(False)


class UpdaterThread(QThread):
    progress_update = pyqtSignal(int, str)
    update_complete = pyqtSignal(bool, str)

    def __init__(self, version_info):
        super().__init__()
        self.version_info = version_info

    def run(self):
        try:
            updater_path = os.path.join(os.path.dirname(sys.executable), 'EagleXRGB_Updater.exe')
            logging.info(f"Attempting to run updater at: {updater_path}")

            if not os.path.exists(updater_path):
                raise FileNotFoundError(f"Updater executable not found at {updater_path}")

            result = subprocess.run([updater_path, json.dumps(self.version_info)],
                                    capture_output=True, text=True, check=True)

            logging.info(f"Updater output: {result.stdout}")
            if result.stderr:
                logging.warning(f"Updater errors: {result.stderr}")

            self.update_complete.emit(True, "Update completed successfully!")
        except subprocess.CalledProcessError as e:
            error_msg = f"Update failed: {e.stderr}"
            logging.error(error_msg)
            self.update_complete.emit(False, error_msg)
        except FileNotFoundError as e:
            error_msg = str(e)
            logging.error(error_msg)
            self.update_complete.emit(False, error_msg)
        except Exception as e:
            error_msg = f"Unexpected error during update: {str(e)}"
            logging.error(error_msg, exc_info=True)
            self.update_complete.emit(False, error_msg)

class Launcher:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.load_settings()

    def load_settings(self):
        try:
            with open('config/EagleXRGB_settings.json', 'r') as f:
                self.settings = json.load(f)
        except FileNotFoundError:
            self.settings = {'auto_update': True}

    def check_for_updates(self):
        self.update_checker = UpdateCheckerThread()
        self.update_checker.update_available.connect(self.on_update_available)
        self.update_checker.check_complete.connect(self.on_check_complete)
        self.update_checker.start()

    def on_update_available(self, version_info):
        if self.settings.get('auto_update', True):
            self.start_update(version_info)
        else:
            reply = QMessageBox.question(None, 'Update Available',
                                         f"A new update (version {version_info['latest_version']}) is available. Do you want to update now?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)

            if reply == QMessageBox.Yes:
                self.start_update(version_info)
            else:
                self.launch_main_app()

    def on_check_complete(self, update_available):
        if not update_available:
            self.launch_main_app()

    def start_update(self, version_info):
        self.progress_dialog = QProgressDialog("Updating...", "Cancel", 0, 100)
        self.progress_dialog.setWindowTitle("EagleXRGB Updater")
        self.progress_dialog.setAutoClose(False)
        self.progress_dialog.setAutoReset(False)

        self.updater_thread = UpdaterThread(version_info)
        self.updater_thread.progress_update.connect(self.update_progress)
        self.updater_thread.update_complete.connect(self.on_update_complete)
        self.updater_thread.start()

        self.progress_dialog.exec_()

    def update_progress(self, value, message):
        self.progress_dialog.setValue(value)
        self.progress_dialog.setLabelText(message)

    def on_update_complete(self, success, message):
        self.progress_dialog.close()
        if success:
            QMessageBox.information(None, "Update Complete", "The application has been updated successfully. It will now restart.")
            self.restart_application()
        else:
            QMessageBox.warning(None, "Update Failed", f"The update process failed: {message}\nThe application will start with the current version.")
            self.launch_main_app()

    def launch_main_app(self):
        logging.info("Launching main application")
        try:
            main_app_path = os.path.join(os.path.dirname(sys.executable), "EagleXRGB_Connector.exe")
            subprocess.Popen([main_app_path])
            logging.info("Main application launched successfully")
        except Exception as e:
            logging.error(f"Failed to launch main application: {e}", exc_info=True)
            QMessageBox.critical(None, "Launch Error", "Failed to start the main application. Please try again.")
        finally:
            sys.exit(0)

    def restart_application(self):
        logging.info("Restarting application")
        try:
            launcher_path = sys.executable
            subprocess.Popen([launcher_path])
            logging.info("Application restart initiated")
        except Exception as e:
            logging.error(f"Failed to restart application: {e}", exc_info=True)
            QMessageBox.critical(None, "Restart Error", "Failed to restart the application. Please start it manually.")
        finally:
            sys.exit(0)

    def run(self):
        self.check_for_updates()
        sys.exit(self.app.exec_())


if __name__ == "__main__":
    try:
        logging.info("Starting EagleXRGB Launcher")
        launcher = Launcher()
        launcher.run()
    except Exception as e:
        logging.critical(f"Unhandled exception in launcher: {e}", exc_info=True)
        print(f"A critical error occurred. Please check the log file for details.")
