import os
import sys
import json
import shutil
import zipfile
import logging

import requests
from PyQt5.QtCore import QObject, pyqtSignal

logging.basicConfig(filename='EagleXRGB_Updater.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')

class Updater(QObject):
    progress_update = pyqtSignal(int, str)

    def __init__(self, version_info):
        super().__init__()
        self.version_info = version_info
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.backup_dir = os.path.join(self.base_dir, 'EagleXRGB_backup')
        self.update_dir = os.path.join(self.base_dir, 'EagleXRGB_update')

    def run_update(self):
        try:
            self.prepare_update()
            self.download_update_package()
            self.backup_current_version()
            self.extract_update_package()
            self.apply_updates()
            self.finalize_update()
            return True
        except Exception as e:
            logging.error(f"Update failed: {str(e)}", exc_info=True)
            self.rollback_update()
            return False

    def prepare_update(self):
        self.progress_update.emit(0, "Preparing for update...")
        if os.path.exists(self.update_dir):
            shutil.rmtree(self.update_dir)
        os.makedirs(self.update_dir)

    def backup_current_version(self):
        self.progress_update.emit(10, "Backing up current version...")
        if os.path.exists(self.backup_dir):
            shutil.rmtree(self.backup_dir)
        shutil.copytree(self.base_dir, self.backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_backup', 'EagleXRGB_update'))

    def download_update_package(self):
        self.progress_update.emit(10, "Downloading update package...")
        update_package_url = f"{self.version_info['base_url']}/{self.version_info['update_package']}"
        response = requests.get(update_package_url, stream=True)
        response.raise_for_status()
        update_package_path = os.path.join(self.update_dir, self.version_info['update_package'])
        with open(update_package_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        self.version_info['update_package'] = update_package_path

    def extract_update_package(self):
        self.progress_update.emit(30, "Extracting update package...")
        update_package = self.version_info['update_package']
        if not os.path.exists(update_package):
            raise FileNotFoundError(f"Update package not found: {update_package}")
        with zipfile.ZipFile(update_package, 'r') as zip_ref:
            zip_ref.extractall(self.update_dir)

    def apply_updates(self):
        self.progress_update.emit(50, "Applying updates...")
        manifest_path = os.path.join(self.update_dir, self.version_info['manifest'])
        with open(manifest_path, 'r') as f:
            manifest = json.load(f)

        for file_info in manifest['files_to_update']:
            self.update_file(file_info)

        for folder_info in manifest.get('folders_to_update', []):
            self.update_folder(folder_info)

        self.remove_obsolete_items(manifest)

    def update_file(self, file_info):
        src = os.path.join(self.update_dir, file_info['path'])
        dest = os.path.join(self.base_dir, file_info['path'])
        try:
            shutil.copy2(src, dest)
        except PermissionError:
            logging.warning(f"File locked, deferring update: {dest}")
            self.defer_update(file_info)

    def update_folder(self, folder_info):
        src = os.path.join(self.update_dir, folder_info['path'])
        dest = os.path.join(self.base_dir, folder_info['path'])
        if folder_info['action'] == 'merge':
            self.merge_folders(src, dest, folder_info.get('ignore_patterns', []))
        elif folder_info['action'] == 'create_if_not_exists':
            os.makedirs(dest, exist_ok=True)

    def merge_folders(self, src, dest, ignore_patterns):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dest, item)
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self.merge_folders(s, d, ignore_patterns)
            else:
                if not any(pattern in item for pattern in ignore_patterns):
                    shutil.copy2(s, d)

    def remove_obsolete_items(self, manifest):
        for file_path in manifest.get('files_to_remove', []):
            full_path = os.path.join(self.base_dir, file_path)
            if os.path.exists(full_path):
                os.remove(full_path)

        for folder_path in manifest.get('folders_to_remove', []):
            full_path = os.path.join(self.base_dir, folder_path)
            if os.path.exists(full_path):
                shutil.rmtree(full_path)

    def defer_update(self, file_info):
        deferred_updates = []
        deferred_file = os.path.join(self.base_dir, 'deferred_updates.json')
        if os.path.exists(deferred_file):
            with open(deferred_file, 'r') as f:
                deferred_updates = json.load(f)
        deferred_updates.append(file_info)
        with open(deferred_file, 'w') as f:
            json.dump(deferred_updates, f)

    def finalize_update(self):
        self.progress_update.emit(90, "Finalizing update...")
        # Remove the update directory
        if os.path.exists(self.update_dir):
            shutil.rmtree(self.update_dir)

        # Update version information
        version_file = os.path.join(self.base_dir, 'EagleXRGB_version.json')
        with open(version_file, 'w') as f:
            json.dump(self.version_info, f)

        self.progress_update.emit(100, "Update completed successfully!")

    def rollback_update(self):
        self.progress_update.emit(0, "Rolling back update...")
        if os.path.exists(self.backup_dir):
            # Remove current (potentially partially updated) files
            for item in os.listdir(self.base_dir):
                if item != 'EagleXRGB_backup':
                    item_path = os.path.join(self.base_dir, item)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)

            # Restore from backup
            for item in os.listdir(self.backup_dir):
                s = os.path.join(self.backup_dir, item)
                d = os.path.join(self.base_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d)
                else:
                    shutil.copy2(s, d)

            # Remove backup directory
            shutil.rmtree(self.backup_dir)

        self.progress_update.emit(100, "Rollback completed.")


if __name__ == "__main__":
    # This allows the Updater to be run as a standalone script
    if len(sys.argv) < 2:
        print("Usage: python EagleXRGB_Updater.py <version_info_json>")
        sys.exit(1)

    version_info = json.loads(sys.argv[1])
    updater = Updater(version_info)
    success = updater.run_update()
    sys.exit(0 if success else 1)
