import configparser
import os
import sys
import json
import shutil
import zipfile
import logging
import requests
import time
import psutil
import win32file
import win32con
from PyQt5.QtCore import QObject, pyqtSignal
from EagleXRGB_version_utils import base_update_url, get_current_version

logging.basicConfig(filename='EagleXRGB_Updater.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class Updater(QObject):
    progress_update = pyqtSignal(int, str)

    def __init__(self, version_info):
        super().__init__()
        self.version_info = version_info
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.backup_dir = os.path.join(self.base_dir, 'EagleXRGB_backup')
        self.update_dir = os.path.join(self.base_dir, 'EagleXRGB_update')
        self.manifest = None
        self.base_url = base_update_url
        self.updater_exe = os.path.join(self.base_dir, 'EagleXRGB_Updater.exe')
        self.temp_updater_exe = os.path.join(self.update_dir, 'EagleXRGB_Updater_new.exe')

    def run_update(self):
        try:
            self.prepare_update()
            self.download_update_package()
            self.extract_update_package()
            self.load_manifest()
            self.terminate_running_processes()
            for step in self.manifest['update_steps']:
                method_name = step.lower().replace(' ', '_').replace('-', '_')
                if hasattr(self, method_name):
                    getattr(self, method_name)()
                else:
                    logging.warning(f"Method {method_name} not found in Updater class.")
            self.create_post_update_batch()
            self.finalize_update()
            return True
        except Exception as e:
            logging.error(f"Update failed: {str(e)}", exc_info=True)
            self.rollback_update()
            return False

    def terminate_running_processes(self):
        process_names = ['EagleXRGB_Launcher.exe', 'EagleXRGB_Connector.exe']
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] in process_names:
                try:
                    proc.terminate()
                    proc.wait(timeout=10)
                except psutil.NoSuchProcess:
                    pass
                except psutil.TimeoutExpired:
                    proc.kill()
                logging.info(f"Terminated process: {proc.info['name']}")

    def prepare_update(self):
        self.progress_update.emit(5, "Preparing for update...")
        if os.path.exists(self.update_dir):
            shutil.rmtree(self.update_dir)
        os.makedirs(self.update_dir)

    def download_update_package(self):
        self.progress_update.emit(10, "Downloading update package...")
        update_package_url = f"{self.base_url}/{self.version_info['update_package']}"
        logging.info(f"Downloading update package from: {update_package_url}")
        response = requests.get(update_package_url, stream=True)
        response.raise_for_status()
        update_package_path = os.path.join(self.update_dir, self.version_info['update_package'])
        with open(update_package_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

    def extract_update_package(self):
        self.progress_update.emit(15, "Extracting update package...")
        update_package_path = os.path.join(self.update_dir, self.version_info['update_package'])
        with zipfile.ZipFile(update_package_path, 'r') as zip_ref:
            zip_ref.extractall(self.update_dir)

    def load_manifest(self):
        self.progress_update.emit(20, "Loading update manifest...")
        manifest_path = os.path.join(self.update_dir, self.version_info['manifest'])
        with open(manifest_path, 'r') as f:
            self.manifest = json.load(f)

    def backup_current_version(self):
        self.progress_update.emit(25, "Backing up current version...")
        if os.path.exists(self.backup_dir):
            shutil.rmtree(self.backup_dir)
        shutil.copytree(self.base_dir, self.backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_backup', 'EagleXRGB_update'))

    def update_critical_files(self):
        self.progress_update.emit(40, "Updating critical files...")
        self._update_files(critical=True)

    def update_noncritical_files(self):
        self.progress_update.emit(60, "Updating non-critical files...")
        self._update_files(critical=False)

    def _update_files(self, critical):
        for file_info in self.manifest['files_to_update']:
            if file_info.get('critical', False) == critical:
                src = os.path.join(self.update_dir, file_info['path'])
                dest = os.path.join(self.base_dir, file_info['path'])

                # Skip updating the updater itself
                if os.path.basename(dest).lower() == 'eaglexrgb_updater.exe':
                    shutil.copy2(src, self.temp_updater_exe)
                    continue

                if file_info.get('action', 'replace') == 'replace':
                    self._safe_file_operation(shutil.copy2, src, dest)
                elif file_info['action'] == 'update':
                    self._merge_or_update_file(src, dest, file_info)

    def create_post_update_batch(self):
        batch_content = f"""
            @echo off
            timeout /t 5 /nobreak
            move /y "{self.temp_updater_exe}" "{self.updater_exe}"
            start "" "{self.updater_exe}"
            del "%~f0"
        """
        batch_file = os.path.join(self.base_dir, 'complete_update.bat')
        with open(batch_file, 'w') as f:
            f.write(batch_content)

    def _merge_or_update_file(self, src, dest, file_info):
        file_type = file_info.get('type', 'unknown')
        if file_type == 'json':
            self._merge_json_files(src, dest)
        elif file_type == 'ini':
            self._merge_ini_files(src, dest)
        elif file_type == 'txt':
            self._update_text_file(src, dest)
        else:
            logging.warning(f"Unknown file type for merging: {file_type}. Replacing file.")
            self._safe_file_operation(shutil.copy2, src, dest)

    def _merge_json_files(self, src, dest):
        try:
            with open(src, 'r') as f:
                new_data = json.load(f)

            if os.path.exists(dest):
                with open(dest, 'r') as f:
                    existing_data = json.load(f)

                # Deep merge the dictionaries
                merged_data = self._deep_merge(existing_data, new_data)
            else:
                merged_data = new_data

            with open(dest, 'w') as f:
                json.dump(merged_data, f, indent=4)

            logging.info(f"Successfully merged JSON file: {dest}")
        except Exception as e:
            logging.error(f"Error merging JSON file {dest}: {str(e)}")
            raise

    def _deep_merge(self, dict1, dict2):
        for key, value in dict2.items():
            if isinstance(value, dict):
                dict1[key] = self._deep_merge(dict1.get(key, {}), value)
            else:
                dict1[key] = value
        return dict1

    def _merge_ini_files(self, src, dest):
        try:
            new_config = configparser.ConfigParser()
            new_config.read(src)

            if os.path.exists(dest):
                existing_config = configparser.ConfigParser()
                existing_config.read(dest)

                for section in new_config.sections():
                    if not existing_config.has_section(section):
                        existing_config.add_section(section)
                    for key, value in new_config.items(section):
                        existing_config.set(section, key, value)
            else:
                existing_config = new_config

            with open(dest, 'w') as f:
                existing_config.write(f)

            logging.info(f"Successfully merged INI file: {dest}")
        except Exception as e:
            logging.error(f"Error merging INI file {dest}: {str(e)}")
            raise

    def _update_text_file(self, src, dest):
        try:
            with open(src, 'r') as f:
                new_content = f.read()

            if os.path.exists(dest):
                with open(dest, 'r') as f:
                    existing_content = f.read()

                # Append new content to existing content
                updated_content = existing_content + "\n\n# Updated content\n" + new_content
            else:
                updated_content = new_content

            with open(dest, 'w') as f:
                f.write(updated_content)

            logging.info(f"Successfully updated text file: {dest}")
        except Exception as e:
            logging.error(f"Error updating text file {dest}: {str(e)}")
            raise

    def _safe_file_operation(self, operation, *args):
        max_attempts = 5
        for attempt in range(max_attempts):
            try:
                if operation == shutil.copy2:
                    self._copy_file_windows(*args)
                elif operation == os.remove:
                    self._remove_file_windows(args[0])
                elif operation == shutil.rmtree:
                    shutil.rmtree(args[0], ignore_errors=True)
                else:
                    operation(*args)
                break
            except Exception as e:
                if attempt < max_attempts - 1:
                    time.sleep(2)  # Wait for 2 seconds before retrying
                else:
                    logging.error(
                        f"Failed to perform operation after {max_attempts} attempts: {operation.__name__} {args}")
                    raise

    def _copy_file_windows(self, src, dst):
        try:
            win32file.CopyFile(src, dst, 0)
        except win32file.error as e:
            if e.winerror == 32:  # File is in use
                self._replace_file_on_reboot(src, dst)
            else:
                raise

    def _remove_file_windows(self, path):
        try:
            os.remove(path)
        except PermissionError:
            self._replace_file_on_reboot(None, path)

    def _replace_file_on_reboot(self, src, dst):
        if src:
            win32file.MoveFileEx(src, dst, win32file.MOVEFILE_REPLACE_EXISTING | win32file.MOVEFILE_DELAY_UNTIL_REBOOT)
        else:
            win32file.MoveFileEx(dst, None, win32file.MOVEFILE_DELAY_UNTIL_REBOOT)

    def merge_internal_folder(self):
        internal_folder = next((folder for folder in self.manifest.get('folders_to_update', [])
                                if folder['path'] == '_internal'), None)
        if internal_folder:
            src = os.path.join(self.update_dir, internal_folder['path'])
            dest = os.path.join(self.base_dir, internal_folder['path'])
            ignore_patterns = internal_folder.get('ignore_patterns', [])
            self._merge_folders(src, dest, ignore_patterns)
        else:
            logging.warning("_internal folder not found in folders_to_update.")

    def _merge_folders(self, src, dest, ignore_patterns):
        if not os.path.exists(src):
            logging.warning(f"Source folder does not exist: {src}")
            return
        if not os.path.exists(dest):
            os.makedirs(dest)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dest, item)
            if os.path.isdir(s):
                self._merge_folders(s, d, ignore_patterns)
            else:
                if not any(pattern in item for pattern in ignore_patterns):
                    self._safe_file_operation(shutil.copy2, s, d)

    def create_missing_folders(self):
        self.progress_update.emit(80, "Creating missing folders...")
        for folder_info in self.manifest['folders_to_update']:
            if folder_info['action'] == 'create_if_not_exists':
                folder_path = os.path.join(self.base_dir, folder_info['path'])
                os.makedirs(folder_path, exist_ok=True)

    def remove_obsolete_files_and_folders(self):
        self.progress_update.emit(85, "Removing obsolete files and folders...")
        for file_path in self.manifest['files_to_remove']:
            full_path = os.path.join(self.base_dir, file_path)
            if os.path.exists(full_path):
                os.remove(full_path)

        for folder_path in self.manifest['folders_to_remove']:
            full_path = os.path.join(self.base_dir, folder_path)
            if os.path.exists(full_path):
                shutil.rmtree(full_path)

    def update_version_information(self):
        self.progress_update.emit(90, "Updating version information...")
        current_version = get_current_version()
        self.version_info['previous_version'] = current_version
        version_file = os.path.join(self.base_dir, 'EagleXRGB_version.json')
        with open(version_file, 'w') as f:
            json.dump(self.version_info, f)

    def finalize_update(self):
        self.progress_update.emit(95, "Finalizing update...")
        if os.path.exists(self.update_dir):
            shutil.rmtree(self.update_dir)
        self.progress_update.emit(100, "Update completed successfully!")

        # Run the post-update batch file
        batch_file = os.path.join(self.base_dir, 'complete_update.bat')
        os.startfile(batch_file)
        sys.exit(0)  # Exit the updater to allow the batch file to complete the update

    def rollback_update(self):
        self.progress_update.emit(0, "Rolling back update...")
        if os.path.exists(self.backup_dir):
            for item in os.listdir(self.base_dir):
                if item != 'EagleXRGB_backup':
                    item_path = os.path.join(self.base_dir, item)
                    if os.path.isfile(item_path):
                        self._safe_file_operation(os.remove, item_path)
                    elif os.path.isdir(item_path):
                        self._safe_file_operation(shutil.rmtree, item_path)

            for item in os.listdir(self.backup_dir):
                s = os.path.join(self.backup_dir, item)
                d = os.path.join(self.base_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d)
                else:
                    self._safe_file_operation(shutil.copy2, s, d)

            self._safe_file_operation(shutil.rmtree, self.backup_dir)
        self.progress_update.emit(100, "Rollback completed.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python EagleXRGB_Updater.py <version_info_json>")
        sys.exit(1)

    version_info = json.loads(sys.argv[1])
    updater = Updater(version_info)
    success = updater.run_update()
    sys.exit(0 if success else 1)
