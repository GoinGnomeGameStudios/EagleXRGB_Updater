import os
import sys
import json
import shutil
import zipfile
import logging
import requests
from PyQt5.QtCore import QObject, pyqtSignal

logging.basicConfig(filename='EagleXRGB_Updater.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')

class Updater(QObject):
    progress_update = pyqtSignal(int, str)

    def __init__(self, version_info):
        super().__init__()
        self.version_info = version_info
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.backup_dir = os.path.join(self.base_dir, 'EagleXRGB_backup')
        self.update_dir = os.path.join(self.base_dir, 'EagleXRGB_update')
        self.manifest = None

    def run_update(self):
        try:
            self.prepare_update()
            self.download_update_package()
            self.extract_update_package()
            self.load_manifest()
            for step in self.manifest['update_steps']:
                getattr(self, step.lower().replace(' ', '_'))()
            self.finalize_update()
            return True
        except Exception as e:
            logging.error(f"Update failed: {str(e)}", exc_info=True)
            self.rollback_update()
            return False

    def prepare_update(self):
        self.progress_update.emit(5, "Preparing for update...")
        if os.path.exists(self.update_dir):
            shutil.rmtree(self.update_dir)
        os.makedirs(self.update_dir)

    def download_update_package(self):
        self.progress_update.emit(10, "Downloading update package...")
        update_package_url = f"{version_info['base_url']}/{version_info['update_package']}"
        response = requests.get(update_package_url, stream=True)
        response.raise_for_status()
        update_package_path = os.path.join(self.update_dir, self.version_info['update_package'])
        with open(update_package_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

    def extract_update_package(self):
        self.progress_update.emit(15, "Extracting update package...")
        update_package_path = os.path.join(self.update_dir, self.version_info['update_package'])
        with zipfile.ZipFile(update_package_path, 'r') as zip_ref:
            zip_ref.extractall(self.update_dir)

    def load_manifest(self):
        self.progress_update.emit(20, "Loading update manifest...")
        manifest_path = os.path.join(self.update_dir, version_info['manifest'])
        with open(manifest_path, 'r') as f:
            self.manifest = json.load(f)

    def backup_current_version(self):
        self.progress_update.emit(25, "Backing up current version...")
        if os.path.exists(self.backup_dir):
            shutil.rmtree(self.backup_dir)
        shutil.copytree(self.base_dir, self.backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_backup', 'EagleXRGB_update'))

    def update_critical_files(self):
        self.progress_update.emit(40, "Updating critical files...")
        self._update_files(critical=True)

    def update_noncritical_files(self):
        self.progress_update.emit(60, "Updating non-critical files...")
        self._update_files(critical=False)

    def _update_files(self, critical):
        for file_info in self.manifest['files_to_update']:
            if file_info['critical'] == critical:
                src = os.path.join(self.update_dir, file_info['path'])
                dest = os.path.join(self.base_dir, file_info['path'])
                if file_info['action'] == 'replace':
                    shutil.copy2(src, dest)
                elif file_info['action'] == 'update':
                    # Implement update logic here (e.g., merge configurations)
                    pass

    def merge_internal_folder(self):
        self.progress_update.emit(70, "Merging _internal folder...")
        internal_folder = next(folder for folder in self.manifest['folders_to_update'] if folder['path'] == '_internal')
        src = os.path.join(self.update_dir, internal_folder['path'])
        dest = os.path.join(self.base_dir, internal_folder['path'])
        ignore_patterns = internal_folder.get('ignore_patterns', [])
        self._merge_folders(src, dest, ignore_patterns)

    def _merge_folders(self, src, dest, ignore_patterns):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dest, item)
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self._merge_folders(s, d, ignore_patterns)
            else:
                if not any(pattern in item for pattern in ignore_patterns):
                    shutil.copy2(s, d)

    def create_missing_folders(self):
        self.progress_update.emit(80, "Creating missing folders...")
        for folder_info in self.manifest['folders_to_update']:
            if folder_info['action'] == 'create_if_not_exists':
                folder_path = os.path.join(self.base_dir, folder_info['path'])
                os.makedirs(folder_path, exist_ok=True)

    def remove_obsolete_files_and_folders(self):
        self.progress_update.emit(85, "Removing obsolete files and folders...")
        for file_path in self.manifest['files_to_remove']:
            full_path = os.path.join(self.base_dir, file_path)
            if os.path.exists(full_path):
                os.remove(full_path)

        for folder_path in self.manifest['folders_to_remove']:
            full_path = os.path.join(self.base_dir, folder_path)
            if os.path.exists(full_path):
                shutil.rmtree(full_path)

    def update_version_information(self):
        self.progress_update.emit(90, "Updating version information...")
        version_file = os.path.join(self.base_dir, 'EagleXRGB_version.json')
        with open(version_file, 'w') as f:
            json.dump(self.version_info, f)

    def finalize_update(self):
        self.progress_update.emit(95, "Finalizing update...")
        if os.path.exists(self.update_dir):
            shutil.rmtree(self.update_dir)
        self.progress_update.emit(100, "Update completed successfully!")

    def rollback_update(self):
        self.progress_update.emit(0, "Rolling back update...")
        if os.path.exists(self.backup_dir):
            for item in os.listdir(self.base_dir):
                if item != 'EagleXRGB_backup':
                    item_path = os.path.join(self.base_dir, item)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)

            for item in os.listdir(self.backup_dir):
                s = os.path.join(self.backup_dir, item)
                d = os.path.join(self.base_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d)
                else:
                    shutil.copy2(s, d)

            shutil.rmtree(self.backup_dir)
        self.progress_update.emit(100, "Rollback completed.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python EagleXRGB_Updater.py <version_info_json>")
        sys.exit(1)

    version_info = json.loads(sys.argv[1])
    updater = Updater(version_info)
    success = updater.run_update()
    sys.exit(0 if success else 1)