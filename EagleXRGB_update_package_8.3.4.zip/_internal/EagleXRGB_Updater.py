import ctypes
import hashlib
import os
import sys
import json
import shutil
import zipfile
import requests
import logging
from logging.handlers import RotatingFileHandler
import traceback
from datetime import datetime
from PyQt5.QtWidgets import QApplication, QProgressDialog
from PyQt5.QtCore import Qt, QObject, pyqtSignal
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature
from packaging import version

from EagleXRGB_version_utils import (
    get_current_version,
    get_updater_version,
    get_latest_version,
    compare_versions,
    get_update_info,
    base_update_url,
    get_base_path
)

# Set up logging
log_file = os.path.join(get_base_path(), 'logs', 'EagleXRGB_updater.log')
os.makedirs(os.path.dirname(log_file), exist_ok=True)
log_handler = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=5)
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
log_handler.setFormatter(log_formatter)

logger = logging.getLogger('EagleXRGB_Updater')
logger.setLevel(logging.DEBUG)
logger.addHandler(log_handler)

# Add a stream handler for console output
console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)
logger.addHandler(console_handler)


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


class Updater(QObject):
    progress_signal = pyqtSignal(int, str)

    def __init__(self, version_info):
        super().__init__()
        self.version_info = version_info
        self.current_version = version_info['current_version']
        self.latest_version = version_info['latest_version']
        self.update_url = version_info['update_url']
        self.base_path = get_base_path()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update_temp')
        self.backup_dir = os.path.join(self.base_path, 'EagleXRGB_backup')
        self.public_key = self.load_public_key()

    def run_update(self):
        if not is_admin():
            logger.error("This script must be run with administrator privileges.")
            return False
        try:
            logger.info(f"Starting update process from version {self.current_version} to {self.latest_version}")
            self.progress_signal.emit(0, "Checking for updates...")
            update_info = self.get_update_info()
            if not update_info:
                logger.info("No updates available.")
                self.progress_signal.emit(100, "No updates available.")
                return False

            self.progress_signal.emit(10, "Downloading update package...")
            package_path = self.download_and_verify_update(update_info)
            if not package_path:
                logger.error("Failed to download or verify the update package.")
                return False

            self.progress_signal.emit(30, "Extracting update package...")
            self.extract_update_package(package_path)

            self.progress_signal.emit(40, "Loading update manifest...")
            manifest = self.load_manifest(update_info['manifest'])

            self.progress_signal.emit(50, "Backing up current version...")
            self.backup_current_version()

            self.progress_signal.emit(60, "Applying updates...")
            self.apply_updates(manifest)

            self.progress_signal.emit(90, "Cleaning up...")
            self.cleanup()

            logger.info("Update completed successfully.")
            self.progress_signal.emit(100, "Update completed successfully!")
            return True
        except Exception as e:
            logger.error(f"Update failed: {str(e)}")
            logger.error(traceback.format_exc())
            self.progress_signal.emit(0, f"Update failed: {str(e)}")
            self.rollback()
            self.report_error(e)
            return False

    def get_update_info(self):
        try:
            response = requests.get(f"{self.update_url}/update_metadata.json")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Error fetching update info: {str(e)}")
            raise

    def is_update_needed(self, latest_version, latest_updater_version):
        current_version = get_current_version()
        current_updater_version = get_updater_version()
        logging.info(f"Comparing versions - Current: {current_version}, Latest: {latest_version}")
        logging.info(
            f"Comparing updater versions - Current: {current_updater_version}, Latest: {latest_updater_version}")
        return (latest_version > current_version) or (latest_updater_version > current_updater_version)

    def is_newer_version(self, new_version):
        return version.parse(new_version) > version.parse(self.current_version)

    def load_public_key(self):
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.dirname(os.path.abspath(__file__))

        key_path = os.path.join(base_path, 'public_key.pem')
        with open(key_path, "rb") as key_file:
            return serialization.load_pem_public_key(key_file.read())

    def check_for_updates(self):
        try:
            latest_version = get_latest_version()
            if latest_version is None:
                print("Failed to fetch latest version information.")
                return False

            if compare_versions(latest_version, self.current_version) > 0:
                update_info = get_update_info()
                if update_info:
                    return self.download_and_verify_update(update_info)
            return False
        except Exception as e:
            print(f"Error checking for updates: {e}")
            return False

    def download_and_verify_update(self, update_info):
        try:
            package_url = update_info['package_url']
            signature_url = update_info['signature_url']

            # Download package
            package_response = requests.get(package_url)
            package_response.raise_for_status()
            package_data = package_response.content

            # Verify package hash
            calculated_hash = hashlib.sha256(package_data).hexdigest()
            if calculated_hash != update_info['package_hash']:
                raise ValueError("Package hash verification failed")

            # Download and verify signature
            signature_response = requests.get(signature_url)
            signature_response.raise_for_status()
            signature = signature_response.content
            if not self.verify_signature(package_data, signature):
                raise ValueError("Signature verification failed")

            # If all verifications pass, save the package
            package_path = os.path.join(self.temp_dir, update_info['package_name'])
            os.makedirs(self.temp_dir, exist_ok=True)
            with open(package_path, "wb") as f:
                f.write(package_data)

            return package_path
        except Exception as e:
            logger.error(f"Error downloading or verifying update: {e}")
            return None

    def verify_signature(self, package_data, signature):
        try:
            self.public_key.verify(
                signature,
                package_data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except InvalidSignature:
            return False

    def extract_update_package(self, package_path):
        logging.info(f"Extracting update package: {package_path}")
        with zipfile.ZipFile(package_path, 'r') as zip_ref:
            zip_ref.extractall(self.temp_dir)
        logging.info(f"Update package extracted to: {self.temp_dir}")

    def load_manifest(self, manifest_name):
        manifest_path = os.path.join(self.temp_dir, manifest_name)
        logging.info(f"Loading manifest from: {manifest_path}")
        with open(manifest_path, 'r') as f:
            manifest = json.load(f)
        logging.info(f"Loaded manifest: {manifest}")
        return manifest

    def backup_current_version(self):
        logging.info(f"Backing up current version to: {self.backup_dir}")
        shutil.copytree(self.base_path, self.backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_update_temp', 'EagleXRGB_backup'))
        logging.info("Backup completed")

    def apply_updates(self, manifest):
        logging.info("Applying updates...")
        for file_info in manifest['files_to_update']:
            self.update_file(file_info)

        for folder_info in manifest['folders_to_update']:
            self.update_folder(folder_info)

        for file_to_remove in manifest['files_to_remove']:
            self.remove_file(file_to_remove)

        for folder_to_remove in manifest['folders_to_remove']:
            self.remove_folder(folder_to_remove)
        logging.info("Updates applied successfully")

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dest = os.path.join(self.base_path, file_info['path'])
        logging.info(f"Updating file: {dest}")
        if file_info['action'] == 'replace':
            shutil.copy2(src, dest)
        elif file_info['action'] == 'update':
            # Implement custom update logic if needed
            shutil.copy2(src, dest)

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dest = os.path.join(self.base_path, folder_info['path'])
        logging.info(f"Updating folder: {dest}")
        if folder_info['action'] == 'merge':
            self.merge_folders(src, dest, folder_info.get('ignore_patterns', []))
        elif folder_info['action'] == 'create_if_not_exists':
            os.makedirs(dest, exist_ok=True)

    def merge_folders(self, src, dest, ignore_patterns):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dest, item)
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self.merge_folders(s, d, ignore_patterns)
            else:
                if not any(pattern in item for pattern in ignore_patterns):
                    shutil.copy2(s, d)

    def remove_file(self, file_path):
        full_path = os.path.join(self.base_path, file_path)
        logging.info(f"Removing file: {full_path}")
        if os.path.exists(full_path):
            os.remove(full_path)

    def remove_folder(self, folder_path):
        full_path = os.path.join(self.base_path, folder_path)
        logging.info(f"Removing folder: {full_path}")
        if os.path.exists(full_path):
            shutil.rmtree(full_path)

    def cleanup(self):
        logging.info("Cleaning up temporary files...")
        shutil.rmtree(self.temp_dir)
        shutil.rmtree(self.backup_dir)
        logging.info("Cleanup completed")

    def rollback(self):
        logging.info("Rolling back to previous version...")
        if os.path.exists(self.backup_dir):
            shutil.rmtree(self.base_path)
            shutil.copytree(self.backup_dir, self.base_path)
            shutil.rmtree(self.backup_dir)
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        logging.info("Rollback completed")

    def report_error(self, error):
        error_report = {
            "timestamp": datetime.now().isoformat(),
            "current_version": self.current_version,
            "target_version": self.latest_version,
            "error_message": str(error),
            "traceback": traceback.format_exc()
        }
        error_file = os.path.join(get_base_path(), 'logs', 'error_report.json')
        with open(error_file, 'w') as f:
            json.dump(error_report, f, indent=2)
        logging.info(f"Error report saved to: {error_file}")
        # Here you could add code to send the error report to a server or email it to developers


def run_updater(version_info):
    app = QApplication(sys.argv)
    updater = Updater(version_info)
    progress_dialog = QProgressDialog("Updating...", "Cancel", 0, 100)
    progress_dialog.setWindowModality(Qt.WindowModal)
    progress_dialog.setWindowTitle("EagleXRGB Updater")

    def update_progress(value, message):
        progress_dialog.setValue(value)
        progress_dialog.setLabelText(message)

    updater.progress_signal.connect(update_progress)

    progress_dialog.show()
    success = updater.run_update()
    progress_dialog.close()

    if success:
        logger.info("Update completed successfully. Please restart the application.")
        print("Update completed successfully. Please restart the application.")
    else:
        logger.warning("Update failed. Please try again or contact support.")
        print("Update failed. Please try again or contact support.")

    return success


if __name__ == "__main__":
    if len(sys.argv) < 2:
        logger.error("Usage: python EagleXRGB_Updater.py <version_info_json>")
        print("Usage: python EagleXRGB_Updater.py <version_info_json>")
        sys.exit(1)

    if not is_admin():
        logger.error("Updater must be run with administrator privileges.")
        print("Updater must be run with administrator privileges.")
        sys.exit(1)

    try:
        version_info = json.loads(sys.argv[1])
        success = run_updater(version_info)
        sys.exit(0 if success else 1)
    except json.JSONDecodeError:
        logger.error("Invalid version_info JSON provided.")
        print("Invalid version_info JSON provided.")
        sys.exit(1)
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        logger.error(traceback.format_exc())
        print(f"An error occurred: {str(e)}")
        sys.exit(1)
