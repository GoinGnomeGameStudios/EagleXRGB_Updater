import os
import sys
import json
import requests
import shutil
import zipfile
import logging
from PyQt5.QtWidgets import QApplication, QWidget, QProgressBar, QLabel, QVBoxLayout
from PyQt5.QtCore import Qt, QThread, pyqtSignal

# Set up logging
logging.basicConfig(filename='EagleXRGB_Updater.log', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')


class UpdaterThread(QThread):
    progress_signal = pyqtSignal(int, str)
    finished_signal = pyqtSignal(bool, str)

    def __init__(self, current_version, update_url):
        super().__init__()
        self.current_version = current_version
        self.update_url = update_url

    def run(self):
        try:
            logging.info(f"Update process started. Current version: {self.current_version}")

            self.progress_signal.emit(0, "Checking for updates...")
            version_info = self.get_version_info()

            if version_info['latest_version'] <= self.current_version:
                logging.info("No updates available.")
                self.finished_signal.emit(False, "No updates available.")
                return

            logging.info(f"Update available. Latest version: {version_info['latest_version']}")

            self.progress_signal.emit(10, "Downloading update package...")
            update_package = self.download_update_package(version_info['update_package'])

            self.progress_signal.emit(40, "Downloading update manifest...")
            manifest = self.get_update_manifest(version_info['manifest'])

            self.progress_signal.emit(50, "Performing update...")
            self.perform_update(update_package, manifest)

            logging.info("Update completed successfully.")
            self.progress_signal.emit(100, "Update completed successfully!")
            self.finished_signal.emit(True, "Update completed successfully!")

        except Exception as e:
            logging.error(f"Update failed: {str(e)}", exc_info=True)
            self.finished_signal.emit(False, f"Update failed: {str(e)}")

    def get_version_info(self):
        logging.info("Fetching version info...")
        response = requests.get(f"{self.update_url}/EagleXRGB_version.json")
        return response.json()

    def download_update_package(self, package_name):
        logging.info(f"Downloading update package: {package_name}")
        response = requests.get(f"{self.update_url}/{package_name}", stream=True)
        with open("update_package.zip", "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return "update_package.zip"

    def get_update_manifest(self, manifest_name):
        logging.info(f"Fetching update manifest: {manifest_name}")
        response = requests.get(f"{self.update_url}/{manifest_name}")
        return response.json()

    def perform_update(self, update_package, manifest):
        logging.info("Starting update process...")

        logging.info("Extracting update package...")
        with zipfile.ZipFile(update_package, 'r') as zip_ref:
            zip_ref.extractall("update_files")

        logging.info("Backing up current version...")
        self.backup_current_version()

        logging.info("Updating files...")
        self.update_files(manifest['files_to_update'])

        logging.info("Updating folders...")
        self.update_folders(manifest['folders_to_update'])

        logging.info("Removing obsolete files and folders...")
        self.remove_obsolete(manifest['files_to_remove'], manifest['folders_to_remove'])

        logging.info("Cleaning up temporary files...")
        os.remove(update_package)
        shutil.rmtree("update_files")

    def backup_current_version(self):
        shutil.copytree(".", "EagleXRGB_backup", ignore=shutil.ignore_patterns("EagleXRGB_backup"))
        logging.info("Backup created: EagleXRGB_backup")

    def update_files(self, files_to_update):
        for file_info in files_to_update:
            source_path = os.path.join("update_files", file_info['path'])
            dest_path = file_info['path']

            if file_info['action'] == 'replace' or file_info['action'] == 'update':
                shutil.copy2(source_path, dest_path)
                logging.info(f"Updated file: {dest_path}")

    def update_folders(self, folders_to_update):
        for folder_info in folders_to_update:
            source_path = os.path.join("update_files", folder_info['path'])
            dest_path = folder_info['path']

            if folder_info['action'] == 'merge':
                self.merge_folders(source_path, dest_path, folder_info.get('ignore_patterns', []))
                logging.info(f"Merged folder: {dest_path}")
            elif folder_info['action'] == 'create_if_not_exists':
                os.makedirs(dest_path, exist_ok=True)
                logging.info(f"Created folder: {dest_path}")

    def merge_folders(self, source, destination, ignore_patterns):
        for item in os.listdir(source):
            s = os.path.join(source, item)
            d = os.path.join(destination, item)
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self.merge_folders(s, d, ignore_patterns)
            else:
                if not any(pattern in item for pattern in ignore_patterns):
                    shutil.copy2(s, d)
                    logging.info(f"Copied file: {d}")

    def remove_obsolete(self, files_to_remove, folders_to_remove):
        for file_path in files_to_remove:
            if os.path.exists(file_path):
                os.remove(file_path)
                logging.info(f"Removed file: {file_path}")

        for folder_path in folders_to_remove:
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
                logging.info(f"Removed folder: {folder_path}")


class UpdaterUI(QWidget):
    def __init__(self, current_version, update_url):
        super().__init__()
        self.current_version = current_version
        self.update_url = update_url
        self.initUI()

    def initUI(self):
        self.setWindowTitle('EagleXRGB Updater')
        self.setGeometry(300, 300, 400, 150)

        layout = QVBoxLayout()

        self.status_label = QLabel('Checking for updates...', self)
        layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar(self)
        layout.addWidget(self.progress_bar)

        self.setLayout(layout)

        # Start the update process automatically
        self.start_update()

    def start_update(self):
        self.updater_thread = UpdaterThread(self.current_version, self.update_url)
        self.updater_thread.progress_signal.connect(self.update_progress)
        self.updater_thread.finished_signal.connect(self.update_finished)
        self.updater_thread.start()

    def update_progress(self, value, status):
        self.progress_bar.setValue(value)
        self.status_label.setText(status)
        logging.info(f"Update progress: {value}% - {status}")

    def update_finished(self, success, message):
        self.status_label.setText(message)
        if success:
            logging.info("Update successful. Restarting application.")
            os.startfile("EagleXRGB_Launcher.exe")
            self.close()
        else:
            logging.error(f"Update failed: {message}")
            # Wait for user to close the updater


def main():
    logging.info("Updater started")
    app = QApplication(sys.argv)
    current_version = sys.argv[1] if len(sys.argv) > 1 else "0.0.0"
    update_url = sys.argv[2] if len(sys.argv) > 2 else "https://example.com/updates"
    logging.info(f"Current version: {current_version}, Update URL: {update_url}")
    updater = UpdaterUI(current_version, update_url)
    updater.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        logging.critical(f"Unhandled exception in updater: {e}", exc_info=True)
        print(f"A critical error occurred. Please check the log file for details.")