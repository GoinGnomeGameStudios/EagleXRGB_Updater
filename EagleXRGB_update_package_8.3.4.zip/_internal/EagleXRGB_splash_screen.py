from PyQt5.QtWidgets import QSplashScreen, QProgressBar, QLabel, QVBoxLayout, QWidget
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import Qt, pyqtSignal

class SplashScreen(QSplashScreen):
    update_signal = pyqtSignal(str, int, str, int, str)

    def __init__(self, font_size=10, bar_height=20, is_bold=False):
        super().__init__(QPixmap("images/EagleXRGB_openrgb-connector-splash_screen.png"))
        self.returncode = None
        self.setWindowFlag(Qt.WindowStaysOnTopHint)

        # Main layout
        layout = QVBoxLayout()

        # Create and style font
        font = QFont()
        font.setPointSize(font_size)
        font.setBold(is_bold)

        # Status Label
        self.status_label = self.create_label("Initializing...", font)
        layout.addWidget(self.status_label)

        # Download Progress Bar and Label
        self.download_progress = self.create_progress_bar(bar_height)
        self.download_label = self.create_label("Download Progress: 0%", font)
        layout.addWidget(self.download_progress)
        layout.addWidget(self.download_label)

        # Update Progress Bar and Label
        self.update_progress = self.create_progress_bar(bar_height)
        self.update_label = self.create_label("Update Progress: 0%", font)
        layout.addWidget(self.update_progress)
        layout.addWidget(self.update_label)

        # Create a widget to hold the layout
        widget = QWidget(self)
        widget.setLayout(layout)

        # Set the widget size and position
        widget.setGeometry(0, self.height() - 150, self.width(), 140)

        # Connect the update signal to the update method
        self.update_signal.connect(self.update_all)

        # Initially hide progress bars and labels
        self.download_progress.hide()
        self.download_label.hide()
        self.update_progress.hide()
        self.update_label.hide()

    def create_label(self, text, font):
        label = QLabel(text)
        label.setAlignment(Qt.AlignCenter)
        label.setFont(font)
        label.setStyleSheet("color: white;")
        return label

    def create_progress_bar(self, height):
        progress_bar = QProgressBar(self)
        progress_bar.setAlignment(Qt.AlignCenter)
        progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid grey;
                border-radius: 5px;
                text-align: center;
                height: {height}px;
            }}
            QProgressBar::chunk {{
                background-color: #05B8CC;
                width: 20px;
            }}
        """)
        return progress_bar

    def update_status(self, message):
        self.status_label.setText(message)
        self.repaint()

    def update_download_progress(self, value):
        self.download_progress.setValue(value)
        self.download_label.setText(f"Download Progress: {value}%")
        self.download_progress.show()
        self.download_label.show()
        self.update_progress.hide()
        self.update_label.hide()
        self.repaint()

    def update_update_progress(self, value):
        self.update_progress.setValue(value)
        self.update_label.setText(f"Update Progress: {value}%")
        self.update_progress.show()
        self.update_label.show()
        self.download_progress.hide()
        self.download_label.hide()
        self.repaint()

    def update_all(self, task, value, status, overall_progress, overall_status):
        self.status_label.setText(overall_status)
        if task == "download":
            self.update_download_progress(value)
        elif task == "update":
            self.update_update_progress(value)
        self.repaint()

    def update_splash_screen(self, task, progress, message, overall_progress, overall_status):
        self.update_signal.emit(task, progress, message, overall_progress, overall_status)