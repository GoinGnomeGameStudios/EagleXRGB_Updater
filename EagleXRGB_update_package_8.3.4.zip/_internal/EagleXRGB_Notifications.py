from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtCore import Qt


class ModernPopup(QMessageBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Popup)
        self.setStyleSheet("""
        QMessageBox {
            background-color: #2D2D2D;
            color: #FFFFFF;
            border: 1px solid #555555;
            border-radius: 10px;
        }
        QLabel {
            color: #FFFFFF;
        }
        QPushButton {
            background-color: #0078D4;
            color: white;
            border: none;
            padding: 5px 15px;
            margin: 5px;
            border-radius: 5px;
        }
        QPushButton:hover {
            background-color: #1084D9;
        }
        """)

    @staticmethod
    def show_info(parent, title, message):
        popup = ModernPopup(parent)
        popup.setIcon(QMessageBox.Information)
        popup.setWindowTitle(title)
        popup.setText(message)
        popup.setStandardButtons(QMessageBox.Ok)
        return popup.exec_()

    @staticmethod
    def show_error(parent, title, message):
        popup = ModernPopup(parent)
        popup.setIcon(QMessageBox.Critical)
        popup.setWindowTitle(title)
        popup.setText(message)
        popup.setStandardButtons(QMessageBox.Ok)
        return popup.exec_()

    @staticmethod
    def show_question(parent, title, message):
        popup = ModernPopup(parent)
        popup.setIcon(QMessageBox.Question)
        popup.setWindowTitle(title)
        popup.setText(message)
        popup.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        return popup.exec_()