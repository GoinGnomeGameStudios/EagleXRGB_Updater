import sys
import os
import win32com.shell.shell as shell
import win32con
import json


def elevate_updater():
    if sys.platform != 'win32':
        print("Elevation is only supported on Windows.")
        return False

    try:
        updater_path = os.path.join(os.path.dirname(sys.executable), 'EagleXRGB_Updater.exe')
        version_info = sys.argv[1]  # This is the JSON string passed from the main app

        # Request elevation
        result = shell.ShellExecuteEx(
            lpVerb='runas',
            lpFile=sys.executable,
            lpParameters=f'"{updater_path}" {version_info}',
            nShow=win32con.SW_SHOW
        )

        if result['hInstApp'] <= 32:
            print("Elevation failed or was cancelled by the user.")
            return False
        return True
    except Exception as e:
        print(f"Error during elevation: {str(e)}")
        return False


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python EagleXRGB_UpdaterElevator.py <version_info_json>")
        sys.exit(1)

    success = elevate_updater()
    sys.exit(0 if success else 1)