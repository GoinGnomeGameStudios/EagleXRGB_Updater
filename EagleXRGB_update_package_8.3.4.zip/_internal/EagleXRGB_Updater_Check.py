import hashlib
import os
import shutil
import subprocess
import sys
import json
import logging
import time
import zipfile
from datetime import datetime

import requests
from packaging import version
from EagleXRGB_version_utils import get_updater_version

class UpdateFlagSystem:
    def __init__(self, base_path):
        self.base_path = base_path
        self.flag_file = os.path.join(base_path, 'update_flag.json')

    def set_update_flag(self, manifest):
        """Set the update flag based on the manifest content."""
        update_info = {
            'version': manifest['version'],
            'files_to_update': manifest['files_to_update'],
            'folders_to_update': manifest['folders_to_update'],
            'files_to_remove': manifest.get('files_to_remove', []),
            'folders_to_remove': manifest.get('folders_to_remove', []),
            'updater_needs_update': any(file['path'] == 'EagleXRGB_Auto_updater.exe' for file in manifest['files_to_update']),
            'main_exe_updated': any(file['path'] == 'EDC_EagleXRGB_Connector.exe' for file in manifest['files_to_update'])
        }
        with open(self.flag_file, 'w') as f:
            json.dump(update_info, f, indent=2)
        logging.info(f"Update flag set: {json.dumps(update_info, indent=2)}")

    def get_update_flag(self):
        """Retrieve the update flag information."""
        if os.path.exists(self.flag_file):
            with open(self.flag_file, 'r') as f:
                return json.load(f)
        return None

    def clear_update_flag(self):
        """Clear the update flag after successful update."""
        if os.path.exists(self.flag_file):
            os.remove(self.flag_file)
            logging.info("Update flag cleared")


class AutoUpdater:
    def __init__(self, update_url, current_version, splash_screen):
        self.update_url = update_url
        self.current_version = current_version
        self.updater_version = get_updater_version()
        self.splash_screen = splash_screen
        self.base_path = self.get_app_dir()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.exe_name = os.path.basename(sys.executable)
        self.update_info = {}  # Will be populated when checking for updates
        self.manifest = None  # Initialize manifest attribute
        self.manifest_file = os.path.join(self.base_path, 'EagleXRGB_update_manifest.json')
        self.files_updated = []  # Initialize files_updated list
        self.updater_needs_update = False  # Initialize updater_needs_update flag
        self.flag_system = UpdateFlagSystem(self.base_path)
        self.setup_logging()

    def load_manifest(self):
        manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
        if not os.path.exists(manifest_path):
            raise FileNotFoundError(f"Update manifest not found: {manifest_path}")

        with open(manifest_path, 'r') as f:
            self.manifest = json.load(f)
        logging.info(f"Manifest loaded: {json.dumps(self.manifest, indent=2)}")


    def setup_logging(self):
        logging.basicConfig(filename='update_check.log', level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def get_app_dir(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            logging.info(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.current_version)
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")

            if latest_version > current_version:
                self.update_info = remote_version_info
                self.update_info['new_version'] = str(latest_version)
                return True, self.update_info
            return False, None
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"

    def download_update(self, version_info):
        if not version_info or 'update_package' not in version_info:
            logging.error("Invalid version info")
            return False

        try:
            update_url = f"{self.update_url}/{version_info['update_package']}"
            logging.info(f"Downloading update package from: {update_url}")
            response = requests.get(update_url, stream=True)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, 'update_package.zip')

            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded = 0

            with open(package_path, 'wb') as f:
                for data in response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        self.splash_screen.update_progress(progress, "Downloading update...")

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def prepare_for_update(self, version_info):
        update_info = {
            'main_exe_path': sys.executable,
            'update_url': self.update_url,
            'current_version': self.current_version,
            'new_version': version_info['latest_version']
        }
        update_info_path = os.path.join(self.temp_dir, 'EagleXRGB_update_info.json')
        with open(update_info_path, 'w') as f:
            json.dump(update_info, f)
        return update_info_path


    def read_manifest(self):
        try:
            with open(self.manifest_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"Error reading manifest file: {str(e)}", exc_info=True)
            raise


    def apply_update(self):
        try:
            # Extract update package and process manifest
            self.extract_update_package()
            manifest = self.read_manifest()

            # Set update flag with necessary information
            update_info = {
                'files_to_update': manifest['files_to_update'],
                'folders_to_update': manifest['folders_to_update'],
                'updater_needs_update': any(file['path'] == 'EagleXRGB_Auto_updater.exe' for file in manifest['files_to_update']),
                'main_exe_updated': any(file['path'] == 'EDC_EagleXRGB_Connector.exe' for file in manifest['files_to_update']),
                'new_version': self.update_info['new_version']
            }
            self.flag_system.set_update_flag(update_info)

            # Perform update of main executable and other files/folders
            self.update_main_application_files(update_info)

            # Signal completion (but don't clear flag yet)
            self.signal_completion()

            return True
        except Exception as e:
            logging.error(f"Error applying update: {str(e)}", exc_info=True)
            return False

    def signal_completion(self):
        completion_info = {
            "status": "complete",
            "files_updated": self.files_updated,
            "updater_needs_update": self.updater_needs_update,
            "main_exe_path": os.path.join(self.base_path, 'EDC_EagleXRGB_Connector.exe'),
            "update_dir": self.temp_dir,
            "manifest_file": os.path.join(self.base_path, 'EagleXRGB_update_manifest.json')
        }
        completion_file = os.path.join(self.base_path, 'update_complete.json')
        try:
            with open(completion_file, 'w') as f:
                json.dump(completion_info, f, indent=2)
            logging.info(f"Update completion signaled: {completion_file}")
        except Exception as e:
            logging.error(f"Failed to create completion file: {str(e)}", exc_info=True)
            raise

    def extract_update_package(self, progress_callback):
        progress_callback.emit(20, "Extracting update package...")
        package_path = os.path.join(self.temp_dir, 'update_package.zip')
        with zipfile.ZipFile(package_path, 'r') as zip_ref:
            zip_ref.extractall(self.temp_dir)
        logging.info("Update package extracted successfully")

    def update_main_application_files(self, progress_callback):
        progress_callback.emit(40, "Updating main application files...")
        for file_info in self.manifest['files_to_update']:
            if file_info['path'] != 'EagleXRGB_Auto_updater.exe':
                self.update_file(file_info)
            else:
                self.updater_needs_update = True
        for folder_info in self.manifest['folders_to_update']:
            self.update_folder(folder_info)

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if file_info['path'] == self.exe_name:
            return  # We'll handle the EXE separately

        if os.path.exists(src):
            if file_info['action'] == 'replace' or not os.path.exists(dst):
                self.safe_file_operation(shutil.copy2, src, dst)
                self.files_updated.append(dst)
                logging.info(f"Updated file: {file_info['path']}")
        else:
            logging.warning(f"Source file not found: {src}")

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        if os.path.exists(src):
            if folder_info['action'] == 'merge':
                self.merge_folders(src, dst)
            elif folder_info['action'] == 'create_if_not_exists':
                if not os.path.exists(dst):
                    self.safe_file_operation(shutil.copytree, src, dst)
                    logging.info(f"Created folder: {folder_info['path']}")
            elif folder_info['action'] == 'replace':
                if os.path.exists(dst):
                    self.safe_file_operation(shutil.rmtree, dst)
                self.safe_file_operation(shutil.copytree, src, dst)
                logging.info(f"Replaced folder: {folder_info['path']}")
        else:
            logging.warning(f"Source folder not found: {src}")

    def safe_file_operation(self, operation, *args, max_attempts=10, delay=2):
        for attempt in range(max_attempts):
            try:
                operation(*args)
                return
            except PermissionError as e:
                if attempt < max_attempts - 1:
                    logging.warning(f"Permission error, retrying in {delay} seconds: {str(e)}")
                    time.sleep(delay)
                else:
                    raise

    def merge_folders(self, src, dst):
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                self.merge_folders(s, d)
            else:
                self.safe_file_operation(shutil.copy2, s, d)
                logging.info(f"Updated file in merge: {d}")

    def update_local_version_file(self, new_version_info):
        try:
            with open(self.version_file, 'w') as f:
                json.dump(new_version_info, f, indent=2)
            logging.info(f"Updated local version file to version {new_version_info['latest_version']}")
        except Exception as e:
            logging.error(f"Error updating local version file: {str(e)}")
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def automatic_update(self):
        update_available, version_info = self.check_for_updates()
        if update_available and version_info:
            logging.info(f"Update available: {version_info.get('latest_version', 'Unknown')}")
            if self.download_update(version_info):
                return self.apply_update()
        return False

    def handle_post_update(self):
        logging.info("Handling post-update tasks")
        try:
            # Verify the update
            self.verify_update()

            # Update the local version file
            with open(self.version_file, 'r') as f:
                version_info = json.load(f)
            self.update_local_version_file(version_info)

            logging.info("Post-update tasks completed successfully")
        except Exception as e:
            logging.error(f"Error during post-update tasks: {str(e)}", exc_info=True)

    def verify_update(self):
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                logging.info(f"Verifying update (Attempt {attempt + 1}/{max_attempts})")

                # Step 1: Check the version of the main executable
                self.splash_screen.update_progress(20, "Verifying main executable version...")
                main_exe_version = self.verify_executable_version()
                logging.info(f"Main executable version: {main_exe_version}")

                # Step 2: Check the version of the updater
                self.splash_screen.update_progress(40, "Verifying updater version...")
                updater_version = self.verify_updater_version()
                logging.info(f"Updater version: {updater_version}")

                # Step 3: Verify critical files and directories
                self.splash_screen.update_progress(60, "Verifying critical files...")
                self.verify_critical_files()
                logging.info("Critical files verified successfully")

                # Step 4: Check the version file
                self.splash_screen.update_progress(80, "Verifying version file...")
                self.verify_version_file()
                logging.info("Version file verified successfully")

                # Step 5: Verify file integrity (if checksums are provided in the manifest)
                self.splash_screen.update_progress(90, "Verifying file integrity...")
                self.verify_file_integrity()
                logging.info("File integrity verified successfully")

                logging.info("Update verification completed successfully")
                self.splash_screen.update_progress(100, "Update verification complete")
                return True
            except Exception as e:
                logging.error(f"Verification attempt {attempt + 1} failed: {str(e)}", exc_info=True)
                if attempt < max_attempts - 1:
                    time.sleep(2)  # Wait before retrying
                else:
                    raise Exception(f"Update verification failed after {max_attempts} attempts: {str(e)}")

    def verify_executable_version(self):
        main_exe = os.path.basename(sys.executable)
        result = subprocess.run([sys.executable, '--version'], capture_output=True, text=True, timeout=10)
        version_output = result.stdout.strip()
        expected_version = self.get_expected_version()
        if version_output != expected_version:
            raise Exception(f"Executable version mismatch. Expected {expected_version}, got {version_output}")
        return version_output

    def verify_updater_version(self):
        updater_path = os.path.join(self.base_path, 'EagleXRGB_Auto_updater.exe')
        if not os.path.exists(updater_path):
            raise FileNotFoundError(f"Updater executable not found: {updater_path}")
        result = subprocess.run([updater_path, '--version'], capture_output=True, text=True, timeout=10)
        updater_version = result.stdout.strip()
        expected_updater_version = self.get_expected_updater_version()
        if updater_version != expected_updater_version:
            raise Exception(f"Updater version mismatch. Expected {expected_updater_version}, got {updater_version}")
        return updater_version

    def verify_critical_files(self):
        critical_files = [
            'EDC_EagleXRGB_Connector.exe',
            'EagleXRGB_Auto_updater.exe',
            'config/EagleXRGB_https_settings.json',
            # Add more critical files as needed
        ]
        for file in critical_files:
            file_path = os.path.join(self.base_path, file)
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Critical file missing: {file}")

    def verify_version_file(self):
        if not os.path.exists(self.version_file):
            raise FileNotFoundError("Version file is missing")
        with open(self.version_file, 'r') as f:
            version_info = json.load(f)
        if 'latest_version' not in version_info or 'update_date' not in version_info:
            raise ValueError("Version file is incomplete")
        if version_info['latest_version'] != self.get_expected_version():
            raise ValueError(
                f"Version file mismatch. Expected {self.get_expected_version()}, got {version_info['latest_version']}")

    def verify_file_integrity(self):
        if self.manifest is None:
            raise ValueError("Manifest not loaded. Cannot verify file integrity.")
        for file_info in self.manifest.get('files_to_update', []):
            if 'checksum' in file_info:
                file_path = os.path.join(self.base_path, file_info['path'])
                if not os.path.exists(file_path):
                    raise FileNotFoundError(f"File missing: {file_info['path']}")
                calculated_checksum = self.calculate_file_checksum(file_path)
                if calculated_checksum != file_info['checksum']:
                    raise ValueError(f"Checksum mismatch for file: {file_info['path']}")

    def calculate_file_checksum(self, file_path):
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    def get_expected_version(self):
        return self.update_info.get('new_version', self.current_version)

    def get_expected_updater_version(self):
        return self.update_info.get('updater_version', get_updater_version())

    def cleanup_update_files(self):
        self.splash_screen.update_progress(50, "Cleaning up temporary files...")
        # ... (existing cleanup code) ...
        self.splash_screen.update_progress(100, "Cleanup complete")

    def launch_main_application_post_update(self):
        main_exe_path = os.path.join(self.base_path, 'EDC_EagleXRGB_Connector.exe')
        subprocess.Popen([main_exe_path, '--post-update'])
        logging.info("Launched main application for post-update tasks")


