import os
import random
import shutil
import sys
import json
import logging
import time
import zipfile
from datetime import datetime
import fcntl
import psutil
import requests
from packaging import version

from EagleXRGB_version_utils import get_launcher_version, get_updater_version


class UpdateFlagSystem:
    def __init__(self, base_path):
        self.base_path = base_path
        self.flag_file = os.path.join(base_path, 'update_flag.json')

    def set_update_flag(self, update_info):
        with open(self.flag_file, 'w') as f:
            json.dump(update_info, f, indent=2)
        logging.info(f"Update flag set: {json.dumps(update_info, indent=2)}")

    def get_update_flag(self):
        if os.path.exists(self.flag_file):
            with open(self.flag_file, 'r') as f:
                return json.load(f)
        return None

    def clear_update_flag(self):
        if os.path.exists(self.flag_file):
            os.remove(self.flag_file)
            logging.info("Update flag cleared")

class FileLock:
    def __init__(self, file_path):
        self.file_path = file_path
        self.lock_file = f"{file_path}.lock"

    def __enter__(self):
        self.lock_fd = open(self.lock_file, 'w')
        fcntl.lockf(self.lock_fd, fcntl.LOCK_EX)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        fcntl.lockf(self.lock_fd, fcntl.LOCK_UN)
        self.lock_fd.close()
        os.remove(self.lock_file)


class AutoUpdater:
    def __init__(self, update_url, current_version, current_launcher_version, current_updater_version, splash_screen=None):
        self.update_url = update_url
        self.current_version = current_version
        self.current_launcher_version = current_launcher_version
        self.current_updater_version = current_updater_version
        self.splash_screen = splash_screen
        self.base_path = self.get_app_dir()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.manifest_file = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
        self.setup_logging()
        self.latest_version_info = None


    @staticmethod
    def get_app_dir():
        return os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))


    @staticmethod
    def setup_logging():
        logging.basicConfig(
            filename='updater_check.log',
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    def read_manifest(self):
        try:
            with open(self.manifest_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logging.error(f"Error reading manifest file: {str(e)}")
            return None

    def update_components(self):
        manifest = self.read_manifest()
        if not manifest:
            logging.error("No valid manifest found. Cannot proceed with update.")
            return False

        try:
            for file_info in manifest['files_to_update']:
                if file_info['path'] == 'EagleXRGB_Launcher.exe':
                    self.update_launcher(file_info)
                elif file_info['path'] == 'EagleXRGB_Auto_updater.exe':
                    self.update_updater(file_info)
                else:
                    self.update_file(file_info)

            for folder_info in manifest['folders_to_update']:
                self.update_folder(folder_info)

            self.remove_files_and_folders(
                manifest.get('files_to_remove', []),
                manifest.get('folders_to_remove', [])
            )

            self.update_local_version_file(
                manifest['version'],
                manifest.get('launcher_version'),
                manifest.get('updater_version')
            )
            logging.info("Update completed successfully.")
            return True
        except Exception as e:
            logging.error(f"Error during update: {str(e)}", exc_info=True)
            return False

    def update_launcher(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if os.path.exists(src):
            # Create a .new file for the launcher update
            new_dst = dst + '.new'
            self.safe_file_operation(shutil.copy2, src, new_dst)
            logging.info(f"Launcher update prepared: {new_dst}")
        else:
            logging.warning(f"New launcher not found: {src}")

    def update_updater(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if os.path.exists(src):
            # Create a .new file for the updater update
            new_dst = dst + '.new'
            self.safe_file_operation(shutil.copy2, src, new_dst)
            logging.info(f"Updater update prepared: {new_dst}")
        else:
            logging.warning(f"New updater not found: {src}")

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            response = requests.get(version_url)
            response.raise_for_status()
            self.latest_version_info = response.json()

            latest_version = version.parse(self.latest_version_info['latest_version'])
            current_version = version.parse(self.current_version)
            latest_launcher_version = version.parse(self.latest_version_info['launcher_version'])
            current_launcher_version = version.parse(self.current_launcher_version)
            latest_updater_version = version.parse(self.latest_version_info['updater_version'])
            current_updater_version = version.parse(self.current_updater_version)

            app_update_available = latest_version > current_version
            launcher_update_available = latest_launcher_version > current_launcher_version
            updater_update_available = latest_updater_version > current_updater_version

            logging.info(f"Current app version: {current_version}, Latest app version: {latest_version}")
            logging.info(f"Current launcher version: {current_launcher_version}, Latest launcher version: {latest_launcher_version}")
            logging.info(f"Current updater version: {current_updater_version}, Latest updater version: {latest_updater_version}")

            return (app_update_available or launcher_update_available or updater_update_available), self.latest_version_info
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def apply_update(self):
        try:
            manifest = self.read_manifest()
            if not manifest:
                logging.error("No valid manifest found. Cannot proceed with update.")
                return False

            self.update_files_and_folders(manifest)
            self.remove_files_and_folders(
                manifest.get('files_to_remove', []),
                manifest.get('folders_to_remove', [])
            )

            self.update_local_version_file(
                manifest['version'],
                manifest.get('launcher_version'),
                manifest.get('updater_version')
            )
            logging.info("Update applied successfully.")
            return True
        except Exception as e:
            logging.error(f"Error applying update: {str(e)}", exc_info=True)
            return False

    def check_and_update_updater(self):
        manifest = self.read_manifest()
        if manifest:
            for item in manifest.get('files_to_update', []):
                if item['path'] == 'EagleXRGB_Auto_updater.exe' and item['action'] == 'update':
                    self.update_updater_executable()
                    break

    def update_updater_executable(self):
        src = os.path.join(self.temp_dir, 'EagleXRGB_Auto_updater.exe')
        dst = os.path.join(self.base_path, 'EagleXRGB_Auto_updater.exe')
        if os.path.exists(src):
            shutil.copy2(src, dst)
            logging.info(f"Updated updater executable: {dst}")

    def cleanup_update_files(self, temp_dir):
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                logging.info(f"Removed temporary update directory: {temp_dir}")
            except Exception as e:
                logging.error(f"Failed to remove temporary directory {temp_dir}: {str(e)}")


    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"

    def download_update(self, version_info):
        if not version_info or 'update_package' not in version_info:
            logging.error("Invalid version info")
            return False

        try:
            update_url = f"{self.update_url}/{version_info['update_package']}"
            logging.info(f"Downloading update package from: {update_url}")
            response = requests.get(update_url, stream=True)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, 'update_package.zip')

            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded_size = 0

            with open(package_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=block_size):
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
                        progress = int((downloaded_size / total_size) * 100)
                        if self.splash_screen:
                            self.splash_screen.update_progress(progress, "Downloading update")

            logging.info(f"Update package downloaded successfully to {package_path}")
            self.extract_update_package(package_path)
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def extract_update_package(self, package_path):
        try:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)
            logging.info(f"Update package extracted successfully to {self.temp_dir}")
        except Exception as e:
            logging.error(f"Error extracting update package: {e}")

    def prepare_for_update(self, version_info):
        update_info = {
            'main_exe_path': sys.executable,
            'update_url': self.update_url,
            'current_version': self.current_version,
            'new_version': version_info['latest_version']
        }
        update_info_path = os.path.join(self.temp_dir, 'EagleXRGB_update_info.json')
        with open(update_info_path, 'w') as f:
            json.dump(update_info, f)
        return update_info_path

    def update_files_and_folders(self, manifest):
        total_items = len(manifest.get('files_to_update', [])) + len(manifest.get('folders_to_update', []))
        current_item = 0

        for item in manifest.get('files_to_update', []) + manifest.get('folders_to_update', []):
            if 'path' in item:
                if os.path.isfile(os.path.join(self.temp_dir, item['path'])):
                    self.update_file(item)
                else:
                    self.update_folder(item)
            current_item += 1
            progress = int((current_item / total_items) * 100)
            logging.info(f"Update progress: {progress}%")
            if self.splash_screen:
                self.splash_screen.update_progress(progress, "Updating")

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if os.path.exists(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if file_info['action'] == 'replace':
                shutil.copy2(src, dst)
            elif file_info['action'] == 'update':
                shutil.copy2(src, dst + '.new')
            logging.info(f"Updated file: {file_info['path']}")
        else:
            logging.warning(f"Source file not found: {src}")

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        if os.path.exists(src):
            if folder_info['action'] == 'merge':
                self.merge_folders(src, dst)
            elif folder_info['action'] == 'create_if_not_exists':
                os.makedirs(dst, exist_ok=True)
            logging.info(f"Updated folder: {folder_info['path']}")
        else:
            logging.warning(f"Source folder not found: {src}")

    def safe_file_operation(self, operation, *args, max_attempts=10, delay=2):
        for attempt in range(max_attempts):
            try:
                operation(*args)
                return
            except PermissionError as e:
                if attempt < max_attempts - 1:
                    logging.warning(f"Permission error, retrying in {delay} seconds: {str(e)}")
                    time.sleep(delay)
                else:
                    raise

    def merge_folders(self, src, dst):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self.merge_folders(s, d)
            else:
                shutil.copy2(s, d)

    def copy_with_retry(self, src, dst, max_attempts=5):
        for attempt in range(max_attempts):
            try:
                shutil.copy2(src, dst)
                return
            except PermissionError as e:
                if attempt < max_attempts - 1:
                    wait_time = (2 ** attempt) + random.uniform(0, 1)  # Exponential backoff with jitter
                    logging.warning(f"Permission error copying {src} to {dst}. Retrying in {wait_time:.2f} seconds...")
                    time.sleep(wait_time)
                else:
                    logging.error(f"Failed to copy {src} to {dst} after {max_attempts} attempts: {e}")
                    raise

    def remove_files_and_folders(self, files_to_remove, folders_to_remove):
        for file_path in files_to_remove:
            full_path = os.path.join(self.base_path, file_path)
            if os.path.exists(full_path):
                os.remove(full_path)
                logging.info(f"Removed file: {file_path}")

        for folder_path in folders_to_remove:
            full_path = os.path.join(self.base_path, folder_path)
            if os.path.exists(full_path):
                shutil.rmtree(full_path)
                logging.info(f"Removed folder: {folder_path}")

    def update_local_version_file(self, new_version, new_launcher_version, new_updater_version):
        try:
            with open(self.version_file, 'r+') as f:
                version_info = json.load(f)
                version_info['latest_version'] = new_version
                version_info['launcher_version'] = new_launcher_version
                version_info['updater_version'] = new_updater_version
                f.seek(0)
                json.dump(version_info, f, indent=2)
                f.truncate()
            logging.info(f"Updated local version file to version {new_version}")
        except Exception as e:
            logging.error(f"Error updating local version file: {str(e)}")

    def automatic_update(self):
        update_available, version_info = self.check_for_updates()
        if update_available and version_info:
            logging.info(f"Update available: {version_info.get('latest_version', 'Unknown')}")
            if self.download_update(version_info):
                return self.apply_update()
        return False

    @staticmethod
    def setup_logging():
        log_file = 'updater_check.log'
        logging.basicConfig(
            filename=log_file,
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        console.setFormatter(formatter)
        logging.getLogger('').addHandler(console)

    @staticmethod
    def get_app_dir():
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    def terminate_locking_processes(self):
        for proc in psutil.process_iter(['pid', 'name', 'open_files']):
            try:
                for file in proc.open_files():
                    if file.path.startswith(self.base_path):
                        logging.warning(
                            f"Terminating process {proc.name()} (PID: {proc.pid}) that's locking a file in the update directory")
                        proc.terminate()
                        break
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

        # Wait for processes to terminate
        time.sleep(2)
