import msvcrt
import os
import random
import sys
import json
import shutil
import logging
import time
import types
import zipfile
import subprocess
from datetime import datetime

import psutil
import requests
from PyQt5.QtGui import QIcon, QImageReader
from PyQt5.QtWidgets import QApplication, QMessageBox, QStyle, QWidget
from PyQt5.QtCore import QThread, pyqtSignal, QTimer
from requests import RequestException

from EagleXRGB_splash_screen import SplashScreen
from EagleXRGB_version_utils import get_updater_version


class UpdaterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EagleXRGB Auto Updater")
        self.setWindowIcon(self.get_icon('eaglex-openrgb-connector-icon'))

    def get_icon(self, icon_name):
        icon_paths = [
            os.path.join(os.path.dirname(sys.executable), 'icons', f'{icon_name}.png'),
            os.path.join(os.path.dirname(sys.executable), f'{icon_name}.png'),
            os.path.join(os.path.dirname(__file__), 'icons', f'{icon_name}.png'),
            os.path.join(os.path.dirname(__file__), f'{icon_name}.png')
        ]

        for icon_path in icon_paths:
            if os.path.exists(icon_path):
                logging.info(f"Loading icon from path: {icon_path}")
                icon = QIcon(icon_path)
                if not icon.isNull():
                    logging.info(f"Successfully loaded icon: {icon_name}")
                    return icon

        logging.warning(f"Failed to load icon: {icon_name}, using fallback")
        return self.style().standardIcon(QStyle.SP_FileIcon)

    def verify_icon_files(self):
        logging.info("Verifying icon files:")
        possible_icon_dirs = [
            os.path.join(os.path.dirname(sys.executable), 'icons'),
            os.path.join(os.path.dirname(__file__), 'icons')
        ]

        for icons_dir in possible_icon_dirs:
            if os.path.exists(icons_dir):
                logging.info(f"Icons directory found: {icons_dir}")
                for filename in os.listdir(icons_dir):
                    if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                        file_path = os.path.join(icons_dir, filename)
                        file_size = os.path.getsize(file_path)
                        reader = QImageReader(file_path)
                        if reader.canRead():
                            image_size = reader.size()
                            logging.info(
                                f"Icon file: {filename}, Size: {file_size} bytes, Dimensions: {image_size.width()}x{image_size.height()}")
                        else:
                            logging.warning(f"Cannot read image file: {filename}, Size: {file_size} bytes")
                return

        logging.error("Icons directory not found in any expected location")


class UpdaterThread(QThread):
    update_progress = pyqtSignal(int, str)
    update_completed = pyqtSignal(bool, str)

    def __init__(self, updater):
        super().__init__()
        self.updater = updater

    def run(self):
        try:
            self.updater.apply_update(self.update_progress)
            self.update_completed.emit(True, "Update completed successfully.")
        except Exception as e:
            logging.error(f"Error during update: {str(e)}", exc_info=True)
            self.update_completed.emit(False, f"Update failed: {str(e)}")


# Try to import Windows-specific modules
try:
    import win32file
    import win32con
    import pywintypes

    WINDOWS_MODULES_AVAILABLE = True
except ImportError:
    WINDOWS_MODULES_AVAILABLE = False

# For Unix-like systems
if os.name != 'nt':
    import fcntl


class FileLock:
    def __init__(self, file_path, mode):
        self.file_path = file_path
        self.mode = mode
        self.file_obj = None

    def __enter__(self):
        if os.name == 'nt':  # Windows
            if WINDOWS_MODULES_AVAILABLE:
                try:
                    self.file_obj = win32file.CreateFile(
                        self.file_path,
                        win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                        0,  # Exclusive access
                        None,
                        win32file.OPEN_ALWAYS,
                        win32file.FILE_ATTRIBUTE_NORMAL,
                        None
                    )
                except pywintypes.error as e:
                    if e.winerror == 32:  # ERROR_SHARING_VIOLATION
                        self.terminate_locking_processes(self.file_path)
                        time.sleep(1)
                        return self.__enter__()
                    raise
            else:
                # Fallback method for Windows without pywin32
                self.file_obj = open(self.file_path, self.mode)
        else:  # Unix-like
            self.file_obj = open(self.file_path, self.mode)
            fcntl.flock(self.file_obj.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return self.file_obj

    @staticmethod
    def terminate_locking_processes(file_path):
        for proc in psutil.process_iter(['pid', 'name', 'open_files']):
            try:
                if any(file.path == file_path for file in proc.open_files()):
                    logging.warning(f"Terminating process {proc.name()} (PID: {proc.pid}) that's locking the file.")
                    proc.terminate()
                    proc.wait(timeout=5)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass


    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.file_obj:
            if os.name == 'nt' and WINDOWS_MODULES_AVAILABLE:
                self.file_obj.Close()
            else:
                if os.name != 'nt':
                    fcntl.flock(self.file_obj.fileno(), fcntl.LOCK_UN)
                self.file_obj.close()


class Updater:
    def __init__(self, update_info_path):
        self.setup_logging()
        with open(update_info_path, 'r') as f:
            self.update_info = json.load(f)

        self.base_path = os.path.dirname(os.path.abspath(sys.executable))
        self.update_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.temp_dir = self.update_dir
        self.completion_file = os.path.join(self.base_path, 'update_complete.json')
        self.manifest_file = os.path.join(self.update_dir, 'EagleXRGB_update_manifest.json')

        self.main_exe_path = os.path.abspath(self.update_info['main_exe_path'])
        self.main_exe = os.path.basename(self.main_exe_path)
        self.updater_exe = 'EagleXRGB_Auto_updater.exe'
        self.update_package = self.update_info['update_package']
        self.backup_dir = os.path.join(self.base_path, 'EagleXRGB_backup')

        self.max_retries = 5
        self.base_delay = 1
        self.files_updated = []
        self.updater_needs_update = False
        self.current_process = psutil.Process()

        self.verify_paths()
        logging.info("Updater initialized successfully")

    def verify_paths(self):
        if not os.path.exists(self.main_exe_path):
            logging.error(f"Main executable not found at: {self.main_exe_path}")
            raise FileNotFoundError(f"Main executable not found: {self.main_exe_path}")
        logging.info(f"Main executable verified at: {self.main_exe_path}")

    @staticmethod
    def get_updater_version():
        return get_updater_version()

    def setup_logging(self):
        log_file = os.path.join(os.path.dirname(sys.executable), 'updater.log')
        logging.basicConfig(filename=log_file, level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def wait_for_process_to_end(self, timeout=30):
        start_time = time.time()
        while time.time() - start_time < timeout:
            if not any(proc.name() == self.main_exe for proc in psutil.process_iter(['name'])):
                return True
            time.sleep(1)
        return False

    def force_close_main_app(self):
        for process in psutil.process_iter(['pid', 'name']):
            if process.name() == self.main_exe:
                try:
                    process.terminate()
                    process.wait(timeout=10)
                    if process.is_running():
                        process.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        time.sleep(2)  # Give some time for file handles to be released

    def download_update(self, progress_callback):
        try:
            new_version = self.update_info['new_version']
            update_package_name = f"EagleXRGB_update_package_{new_version}.zip"
            update_url = f"{self.update_info['update_url']}/{update_package_name}"

            logging.info(f"Attempting to download update package from: {update_url}")

            response = requests.get(update_url, stream=True, timeout=30)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, update_package_name)

            total_size = int(response.headers.get('content-length', 0))
            logging.info(f"Total download size: {total_size} bytes")

            block_size = 8192
            downloaded = 0

            with open(package_path, 'wb') as f:
                for data in response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        progress_callback.emit(progress, f"Downloading update... {progress}%")
                    logging.debug(f"Downloaded {downloaded} of {total_size} bytes")

            if downloaded == total_size or total_size == 0:
                logging.info(f"Update package '{update_package_name}' downloaded successfully")
                return True
            else:
                logging.error(f"Download incomplete. Expected {total_size}, got {downloaded} bytes")
                return False

        except RequestException as e:
            logging.error(f"Network error while downloading update: {str(e)}")
            return False
        except Exception as e:
            logging.error(f"Unexpected error during download: {str(e)}")
            return False

    def load_manifest(self):
        manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
        if not os.path.exists(manifest_path):
            raise FileNotFoundError(f"Update manifest not found: {manifest_path}")

        with open(manifest_path, 'r') as f:
            self.manifest = json.load(f)
        logging.info(f"Manifest content: {json.dumps(self.manifest, indent=2)}")

    def apply_update(self, progress_callback):
        try:
            # Step 1: Create backup
            progress_callback.emit(5, "Creating backup...")
            self.create_backup()

            # Step 2: Terminate all related processes
            progress_callback.emit(10, "Terminating processes...")
            self.terminate_all_processes()

            # Step 3: Extract the update package
            progress_callback.emit(20, "Extracting update package...")
            self.extract_update_package()

            # Step 4: Load the manifest
            progress_callback.emit(30, "Loading update manifest...")
            self.load_manifest()

            # Step 5: Update main application files
            progress_callback.emit(40, "Updating main application files...")
            self.update_main_application_files(progress_callback)

            # Step 6: Move manifest file to base directory for post-update process
            shutil.copy2(self.manifest_file, self.base_path)
            logging.info(f"Copied manifest file to: {self.base_path}")

            # Step 7: Signal completion
            progress_callback.emit(95, "Signaling completion...")
            self.signal_completion()

            progress_callback.emit(100, "Update completed.")
            logging.info("Update process completed successfully.")

            return True, "Update completed successfully."
        except Exception as e:
            logging.error(f"Error applying update: {str(e)}", exc_info=True)
            return False, f"Update failed: {str(e)}"

    def extract_update_package(self):
        logging.info(f"Extracting update package: {self.update_package}")
        with zipfile.ZipFile(self.update_package, 'r') as zip_ref:
            zip_ref.extractall(self.temp_dir)
        logging.info(f"Update package extracted to: {self.temp_dir}")

    def create_backup(self):
        if os.path.exists(self.backup_dir):
            shutil.rmtree(self.backup_dir)
        shutil.copytree(self.base_path, self.backup_dir,
                        ignore=shutil.ignore_patterns('EagleXRGB_backup', 'EagleXRGB_update'))
        logging.info(f"Backup created at {self.backup_dir}")

    def terminate_all_processes(self):
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.name() in ['EDC_EagleXRGB_Connector.exe', 'EagleXRGB_Auto_updater.exe']:
                if proc.pid != self.current_process.pid:  # Don't terminate the current process
                    try:
                        logging.info(f"Attempting to terminate process: {proc.name()} (PID: {proc.pid})")
                        proc.terminate()
                        proc.wait(timeout=10)
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.TimeoutExpired):
                        try:
                            logging.warning(f"Forcefully killing process: {proc.name()} (PID: {proc.pid})")
                            proc.kill()
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            logging.error(f"Failed to kill process: {proc.name()} (PID: {proc.pid})")
                else:
                    logging.info(f"Skipping termination of current process: {proc.name()} (PID: {proc.pid})")

        time.sleep(2)  # Give some time for processes to fully terminate
        logging.info("Process termination completed")

    def rollback_update(self, progress_callback):
        progress_callback.emit(0, "Initiating rollback process...")
        if os.path.exists(self.backup_dir):
            try:
                self.terminate_all_processes()
                for root, dirs, files in os.walk(self.backup_dir):
                    for file in files:
                        src = os.path.join(root, file)
                        dst = os.path.join(self.base_path, os.path.relpath(src, self.backup_dir))
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        self.copy_file_with_retry(src, dst)
                progress_callback.emit(90, "Rollback completed")
                logging.info("Rollback completed successfully")
            except Exception as e:
                logging.error(f"Error during rollback: {str(e)}", exc_info=True)
                progress_callback.emit(100, "Rollback failed. Please reinstall the application.")
        else:
            logging.error("Backup directory not found, unable to rollback")
            progress_callback.emit(50, "Rollback failed: No backup found")

    def cleanup_update_files(self):
        logging.info("Cleaning up update files...")
        try:
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
            if os.path.exists(self.update_package):
                os.remove(self.update_package)
            logging.info("Cleanup completed successfully")
        except Exception as e:
            logging.error(f"Error during cleanup: {str(e)}")

    def update_main_application_files(self, progress_callback):
        total_files = len(self.manifest['files_to_update'])
        for index, file_info in enumerate(self.manifest['files_to_update']):
            if file_info['path'] != 'EagleXRGB_Auto_updater.exe':
                self.update_file(file_info)
                progress = 30 + int((index / total_files) * 50)
                progress_callback.emit(progress, f"Updating: {file_info['path']}")

    def launch_main_application_post_update(self):
        if not self.main_exe_path:
            logging.error("Main executable path is not set. Cannot launch main application.")
            return

        logging.info(f"Attempting to launch main application: {self.main_exe_path}")
        try:
            subprocess.Popen([self.main_exe_path, '--post-update'])
            logging.info(f"Main application launched successfully with --post-update flag")
        except Exception as e:
            logging.error(f"Failed to launch main application: {str(e)}")

    def update_executables(self, manifest):
        for item in manifest.get('files_to_update', []):
            if item['path'] == self.main_exe:
                self.update_main_executable()

    def update_main_executable(self):
        src = os.path.join(self.temp_dir, self.main_exe)
        dst = self.update_info['main_exe_path']
        if os.path.exists(src):
            self.safe_file_operation(shutil.copy2, src, dst)
            logging.info(f"Updated main executable: {dst}")
        else:
            logging.error(f"Main executable not found in update package: {src}")

    def update_updater_executable(self):
        src = os.path.join(self.temp_dir, self.updater_exe)
        dst = os.path.join(self.base_path, self.updater_exe)
        if os.path.exists(src):
            self.safe_file_operation(shutil.copy2, src, dst)
            logging.info(f"Updated updater executable: {dst}")
        else:
            logging.error(f"Updater executable not found in update package: {src}")

    def signal_completion(self):
        completion_info = {
            "status": "complete",
            "files_updated": self.files_updated,
            "updater_needs_update": self.updater_needs_update,
            "main_exe_path": self.main_exe_path,
            "update_dir": self.update_dir,
            "manifest_file": os.path.join(self.base_path, 'EagleXRGB_update_manifest.json')
        }
        try:
            with open(self.completion_file, 'w') as f:
                json.dump(completion_info, f, indent=2)
            logging.info(f"Update completion signaled: {self.completion_file}")
        except Exception as e:
            logging.error(f"Failed to create completion file: {str(e)}", exc_info=True)
            raise

    def update_files_and_folders(self, progress_callback):
        total_items = len(self.manifest['files_to_update']) + len(self.manifest['folders_to_update'])
        current_item = 0

        for file_info in self.manifest['files_to_update']:
            if file_info['path'] != 'EagleXRGB_Auto_updater.exe':
                self.update_file(file_info)
            current_item += 1
            progress = 60 + int((current_item / total_items) * 30)
            progress_callback.emit(progress, f"Updating file: {file_info['path']}")

        for folder_info in self.manifest['folders_to_update']:
            if folder_info['path'] != '_internal':
                self.update_folder(folder_info)
            current_item += 1
            progress = 60 + int((current_item / total_items) * 30)
            progress_callback.emit(progress, f"Updating folder: {folder_info['path']}")

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if os.path.exists(src):
            retry_count = 0
            while retry_count < 5:
                try:
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    self.copy_file_with_retry(src, dst)
                    self.files_updated.append(dst)
                    logging.info(f"Updated file: {file_info['path']}")
                    break
                except PermissionError:
                    retry_count += 1
                    time.sleep(1)
            if retry_count == 5:
                raise PermissionError(f"Failed to update file after 5 attempts: {file_info['path']}")

    def copy_file_with_retry(self, src, dst):
        for _ in range(5):
            try:
                win32file.CopyFile(src, dst, False)
                return
            except pywintypes.error as e:
                if e.winerror == 32:  # File is in use
                    time.sleep(1)
                else:
                    raise
        raise PermissionError(f"Failed to copy file after 5 attempts: {src} to {dst}")

    def check_updater_status(self):
        updater_info = next((f for f in self.manifest['files_to_update'] if f['path'] == 'EagleXRGB_Auto_updater.exe'),
                            None)
        if updater_info:
            self.updater_needs_update = True
            logging.info("Updater needs to be updated.")

    @staticmethod
    def replace_file(src, dst):
        if os.name == 'nt':
            win32file.MoveFileEx(src, dst, win32file.MOVEFILE_REPLACE_EXISTING)
        else:
            os.replace(src, dst)

    def safe_file_operation(self, operation, *args, **kwargs):
        for attempt in range(self.max_retries):
            try:
                self.terminate_file_locking_processes(args[0])
                return operation(*args, **kwargs)
            except (IOError, OSError) as e:
                if attempt == self.max_retries - 1:
                    raise
                delay = self.base_delay * (2 ** attempt) + random.uniform(0, 1)
                logging.warning(
                    f"File operation failed, retrying in {delay:.2f} seconds... ({attempt + 1}/{self.max_retries})")
                time.sleep(delay)

    def terminate_file_locking_processes(self, file_path):
        for proc in psutil.process_iter(['pid', 'name', 'open_files']):
            try:
                if any(file.path == file_path for file in proc.open_files()):
                    logging.warning(f"Terminating process {proc.name()} (PID: {proc.pid}) that's locking the file.")
                    proc.terminate()
                    proc.wait(timeout=5)
                    if proc.is_running():
                        proc.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
        time.sleep(1)  # Give some time for file handles to be released

    def file_lock(self, file_path, mode='r'):
        file = open(file_path, mode)
        try:
            if os.name == 'nt':  # Windows
                msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
            else:  # Unix-like
                fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (IOError, OSError):
            file.close()
            raise
        return file

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        logging.info(f"Updating folder: {folder_info['path']}")
        logging.info(f"Source: {src}")
        logging.info(f"Destination: {dst}")

        if folder_info['action'] == 'merge':
            self.merge_folders(src, dst)
        elif folder_info['action'] == 'replace':
            if os.path.exists(dst):
                self.safe_file_operation(shutil.rmtree, dst)
            self.safe_file_operation(shutil.copytree, src, dst)
            logging.info(f"Replaced folder: {dst}")
        elif folder_info['action'] == 'create_if_not_exists':
            if not os.path.exists(dst):
                self.safe_file_operation(shutil.copytree, src, dst)
                logging.info(f"Created folder: {dst}")
            else:
                logging.info(f"Folder already exists, skipping: {dst}")

    def merge_folders(self, src, dst):
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                self.merge_folders(s, d)
            else:
                self.safe_file_operation(shutil.copy2, s, d)
                logging.info(f"Copied file: {d}")

    def update_local_version_file(self, new_version):
        temp_file = self.version_file + '.tmp'
        try:
            version_info = {
                "latest_version": new_version,
                "update_date": datetime.now().isoformat()
            }
            with open(temp_file, 'w') as f:
                json.dump(version_info, f, indent=2)
            os.replace(temp_file, self.version_file)
            logging.info(f"Updated local version file to version {new_version}")
        except Exception as e:
            logging.error(f"Error updating local version file: {str(e)}")
            if os.path.exists(temp_file):
                os.remove(temp_file)

    def _write_json(self, file_path, data):
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)

    def verify_update(self):
        if not os.path.exists(self.update_info['main_exe_path']):
            raise Exception("Main executable not found after update")
        if not os.path.exists(self.version_file):
            raise Exception("Version file not found after update")

        # Check the version of the updated executable
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                result = subprocess.run([self.update_info['main_exe_path'], '--version'],
                                        capture_output=True, text=True, timeout=10)
                updated_version = result.stdout.strip()
                if updated_version != self.update_info['new_version']:
                    raise Exception(
                        f"Version mismatch after update. Expected {self.update_info['new_version']}, got {updated_version}")
                logging.info(f"Verified updated version: {updated_version}")
                return  # Successful verification
            except subprocess.TimeoutExpired:
                logging.warning(
                    f"Timeout while checking updated executable version (attempt {attempt + 1}/{max_attempts})")
            except Exception as e:
                logging.error(
                    f"Error checking updated executable version (attempt {attempt + 1}/{max_attempts}): {str(e)}")

            if attempt < max_attempts - 1:
                time.sleep(2)  # Wait before retrying

        raise Exception("Failed to verify the updated executable version after multiple attempts")

    def remove_specified_folders(self, manifest):
        folders_to_remove = manifest.get('folders_to_remove', [])
        for folder in folders_to_remove:
            folder_path = os.path.join(self.base_path, folder)
            if os.path.exists(folder_path):
                try:
                    shutil.rmtree(folder_path)
                    logging.info(f"Removed folder: {folder_path}")
                except Exception as e:
                    logging.error(f"Failed to remove folder {folder_path}: {str(e)}")

    def clean_up(self):
        # Remove files specified in the manifest
        for file in self.manifest.get('files_to_remove', []):
            file_path = os.path.join(self.base_path, file)
            if os.path.exists(file_path):
                os.remove(file_path)
                logging.info(f"Removed file: {file}")

        # Remove folders specified in the manifest
        for folder in self.manifest.get('folders_to_remove', []):
            folder_path = os.path.join(self.base_path, folder)
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
                logging.info(f"Removed folder: {folder}")

        # Remove the temporary directory
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            logging.info(f"Removed temporary directory: {self.temp_dir}")


def setup_logging():
    logging.basicConfig(filename='update_check.log', level=logging.DEBUG,
                        format='%(asctime)s - %(levelname)s - %(message)s')


def main():
    try:
        setup_logging()
        logging.info("Updater started")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Arguments: {sys.argv}")
        logging.info(f"Current working directory: {os.getcwd()}")

        if len(sys.argv) > 1 and sys.argv[1] == '--version':
            print(get_updater_version())
            return 0

        app = QApplication(sys.argv)

        if len(sys.argv) < 2:
            error_message = "No update info provided. Usage: EagleXRGB_Auto_updater.py <path_to_update_info.json>"
            logging.error(error_message)
            QMessageBox.critical(None, "Updater Error", error_message)
            return 1

        update_info_path = os.path.abspath(sys.argv[1])
        logging.info(f"Update info path: {update_info_path}")

        if not os.path.exists(update_info_path):
            error_message = f"Update info file not found: {update_info_path}"
            logging.error(error_message)
            QMessageBox.critical(None, "Updater Error", error_message)
            return 1

        with open(update_info_path, 'r') as f:
            update_info = json.load(f)
        logging.info(f"Update info contents: {json.dumps(update_info, indent=2)}")

        splash = SplashScreen()
        splash.show()

        updater = Updater(update_info_path)
        updater_thread = UpdaterThread(updater)

        def update_progress(value, status):
            splash.update_progress(value, status)
            logging.info(f"Update progress: {value}% - {status}")

        def update_completed(success, message):
            if success:
                splash.show_update_info("Update complete. Launching main application...")
                logging.info("Update completed successfully. Launching main application.")
                if os.path.exists(updater.completion_file):
                    logging.info(f"Completion file found: {updater.completion_file}")
                    launch_main_application(updater.main_exe_path)
                else:
                    logging.error(f"Completion file not found: {updater.completion_file}")
                    QMessageBox.critical(None, "Update Error",
                                         "Update completion file not found. Unable to launch main application.")
            else:
                splash.show_update_info("Update failed. Please try again.")
                logging.error(f"Update failed: {message}")
                QMessageBox.critical(None, "Update Failed", message)
            QTimer.singleShot(2000, app.quit)

        def launch_main_application(main_exe_path):
            logging.info(f"Attempting to launch main application from path: {main_exe_path}")
            if os.path.exists(main_exe_path):
                logging.info(f"Main executable found at: {main_exe_path}")
                try:
                    subprocess.Popen([main_exe_path, '--post-update'])
                    logging.info("Main application launch process started")
                except Exception as e:
                    logging.error(f"Failed to launch main application: {str(e)}", exc_info=True)
                    QMessageBox.critical(None, "Launch Error", f"Failed to launch main application: {str(e)}")
            else:
                logging.error(f"Main application executable not found at: {main_exe_path}")
                QMessageBox.critical(None, "Launch Error", f"Main application executable not found: {main_exe_path}")

        updater_thread.update_progress.connect(update_progress)
        updater_thread.update_completed.connect(update_completed)
        updater_thread.start()

        return app.exec_()

    except Exception as e:
        logging.error(f"Unhandled exception in updater: {str(e)}", exc_info=True)
        QMessageBox.critical(None, "Critical Error", f"An unhandled exception occurred in the updater: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
