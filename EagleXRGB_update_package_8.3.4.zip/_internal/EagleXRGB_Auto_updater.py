import sys
import os
import shutil
import json
import logging
import winreg

from PyQt5.QtWidgets import QApplication

from EagleXRGB_Updater_Check import AutoUpdater, UpdateFlagSystem
from EagleXRGB_splash_screen import SplashScreen
from EagleXRGB_version_utils import get_app_version, get_updater_version


def setup_logging():
    log_file = 'auto_updater.log'
    logging.basicConfig(
        filename=log_file,
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)


class EagleXRGBAutoUpdater:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.splash_screen = SplashScreen()
        self.splash_screen.show()
        self.base_path = os.path.dirname(os.path.abspath(sys.executable))
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.manifest_file = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.setup_logging()

    def setup_logging(self):
        logging.basicConfig(filename='auto_updater.log', level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def run(self):
        if '--update' in sys.argv:
            self.perform_update()
        else:
            logging.error("Updater should be run with --update flag")
        self.app.exec_()

    def perform_update(self):
        try:
            self.splash_screen.update_progress(0, "Reading update manifest...")
            manifest = self.read_manifest()
            if not manifest:
                self.splash_screen.update_progress(100, "Update failed: Invalid manifest")
                logging.error("No valid manifest found. Cannot proceed with update.")
                return

            total_items = len(manifest['files_to_update']) + len(manifest['folders_to_update'])
            current_item = 0

            for file_info in manifest['files_to_update']:
                current_item += 1
                progress = int((current_item / total_items) * 80)  # 80% of progress for files and folders
                self.splash_screen.update_progress(progress, f"Updating file: {file_info['path']}")
                self.update_file(file_info)

            for folder_info in manifest['folders_to_update']:
                current_item += 1
                progress = int((current_item / total_items) * 80)
                self.splash_screen.update_progress(progress, f"Updating folder: {folder_info['path']}")
                self.update_folder(folder_info)

            self.splash_screen.update_progress(90, "Cleaning up...")
            self.remove_files_and_folders(
                manifest.get('files_to_remove', []),
                manifest.get('folders_to_remove', [])
            )

            self.splash_screen.update_progress(95, "Finalizing update...")
            self.update_local_version_file(manifest['version'])

            self.splash_screen.update_progress(100, "Update completed successfully")
            logging.info("Update completed successfully.")
        except Exception as e:
            self.splash_screen.update_progress(100, f"Update failed: {str(e)}")
            logging.error(f"Error during update: {str(e)}", exc_info=True)

    def read_manifest(self):
        try:
            with open(self.manifest_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logging.error(f"Error reading manifest file: {str(e)}")
            return None

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if os.path.exists(src):
            try:
                shutil.copy2(src, dst)
                logging.info(f"Updated file: {file_info['path']}")
            except PermissionError:
                self.schedule_file_replacement(src, dst)
        else:
            logging.warning(f"Source file not found: {src}")

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        if os.path.exists(src):
            if folder_info['action'] == 'merge':
                self.merge_folders(src, dst)
            elif folder_info['action'] == 'replace':
                shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst)
            logging.info(f"Updated folder: {folder_info['path']}")
        else:
            logging.warning(f"Source folder not found: {src}")

    def merge_folders(self, src, dst):
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self.merge_folders(s, d)
            else:
                shutil.copy2(s, d)

    def remove_files_and_folders(self, files_to_remove, folders_to_remove):
        for file_path in files_to_remove:
            full_path = os.path.join(self.base_path, file_path)
            if os.path.exists(full_path):
                os.remove(full_path)
                logging.info(f"Removed file: {file_path}")

        for folder_path in folders_to_remove:
            full_path = os.path.join(self.base_path, folder_path)
            if os.path.exists(full_path):
                shutil.rmtree(full_path, ignore_errors=True)
                logging.info(f"Removed folder: {folder_path}")

    def update_local_version_file(self, new_version):
        try:
            with open(self.version_file, 'r+') as f:
                version_info = json.load(f)
                version_info['latest_version'] = new_version
                f.seek(0)
                json.dump(version_info, f, indent=2)
                f.truncate()
            logging.info(f"Updated local version file to version {new_version}")
        except Exception as e:
            logging.error(f"Error updating local version file: {str(e)}")

    def schedule_file_replacement(self, src, dst):
        try:
            winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"System\CurrentControlSet\Control\Session Manager")
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"System\CurrentControlSet\Control\Session Manager", 0,
                                 winreg.KEY_ALL_ACCESS)
            winreg.SetValueEx(key, "PendingFileRenameOperations", 0, winreg.REG_MULTI_SZ,
                              [fr"\??\{dst}", fr"\??\{src}"])
            logging.info(f"Scheduled replacement of {dst} with {src} on next reboot")
        except Exception as e:
            logging.error(f"Failed to schedule file replacement: {str(e)}")


if __name__ == "__main__":
    updater = EagleXRGBAutoUpdater()
    updater.run()
