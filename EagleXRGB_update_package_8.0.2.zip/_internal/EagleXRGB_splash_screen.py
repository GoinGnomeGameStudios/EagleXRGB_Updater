from PyQt5.QtWidgets import QSplashScreen, QProgressBar, QLabel, QVBoxLayout, QWidget
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import Qt


class SplashScreen(QSplashScreen):
    def __init__(self):
        super().__init__(QPixmap("images/eaglex-openrgb-connector-splash_screen.png"))
        self.setWindowFlag(Qt.WindowStaysOnTopHint)

        # Main layout
        layout = QVBoxLayout()

        # Status Label
        self.status_label = QLabel("Initializing...")
        self.status_label.setAlignment(Qt.AlignCenter)
        font = QFont()
        font.setPointSize(10)
        self.status_label.setFont(font)
        self.status_label.setStyleSheet("color: white;")
        layout.addWidget(self.status_label)

        # Download Progress Bar
        self.download_progress = QProgressBar(self)
        self.download_progress.setAlignment(Qt.AlignCenter)
        self.download_progress.setStyleSheet("""
            QProgressBar {
                border: 2px solid grey;
                border-radius: 5px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #05B8CC;
                width: 20px;
            }
        """)
        layout.addWidget(self.download_progress)

        # Download Label
        self.download_label = QLabel("Progress: 0%")
        self.download_label.setAlignment(Qt.AlignCenter)
        self.download_label.setStyleSheet("color: white;")
        layout.addWidget(self.download_label)

        # Create a widget to hold the layout
        widget = QWidget(self)
        widget.setLayout(layout)

        # Set the widget size and position
        widget.setGeometry(0, self.height() - 100, self.width(), 90)

    def update_status(self, message):
        self.status_label.setText(message)
        self.repaint()

    def update_download_progress(self, value):
        self.download_progress.setValue(value)
        self.download_label.setText(f"Progress: {value}%")
        self.repaint()

    def update_update_progress(self, value):
        # For simplicity, we'll use the same progress bar for both download and update
        self.update_download_progress(value)