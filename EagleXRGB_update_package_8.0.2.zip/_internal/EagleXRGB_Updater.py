import os
import sys
import json
import requests
import zipfile
import shutil
import logging
from packaging import version
from datetime import datetime

class AutoUpdater:
    def __init__(self, update_url):
        self.base_path = self.get_app_dir()
        self.update_url = update_url
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.update_ready_flag = os.path.join(self.base_path, 'update_ready.flag')
        self.exe_name = 'EDC_EagleXRGB_Connector.exe'

        # Setup logging
        log_file = os.path.join(self.base_path, 'update_log.txt')
        logging.basicConfig(filename=log_file, level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')
        logging.info(f"AutoUpdater initialized. Base path: {self.base_path}, Update URL: {update_url}")

    def get_app_dir(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        else:
            return os.path.dirname(os.path.abspath(__file__))

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            logging.info(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.get_current_version())
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")
            return latest_version > current_version, remote_version_info
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"

    def download_update(self, version_info):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        os.makedirs(self.temp_dir)

        logging.info(f"Using temp directory: {self.temp_dir}")
        try:
            manifest_url = f"{self.update_url}/{version_info['manifest']}"
            update_url = f"{self.update_url}/{version_info['update_package']}"

            # Download manifest
            logging.info(f"Downloading manifest from: {manifest_url}")
            manifest_response = requests.get(manifest_url)
            manifest_response.raise_for_status()
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            with open(manifest_path, 'wb') as f:
                f.write(manifest_response.content)

            # Download update package
            logging.info(f"Downloading update package from: {update_url}")
            update_response = requests.get(update_url)
            update_response.raise_for_status()
            package_path = os.path.join(self.temp_dir, 'update_package.zip')
            with open(package_path, 'wb') as f:
                f.write(update_response.content)

            # Create update ready flag
            with open(self.update_ready_flag, 'w') as f:
                json.dump(version_info, f)

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def apply_update(self):
        if not os.path.exists(self.update_ready_flag):
            logging.info("No update ready to apply")
            return False

        try:
            with open(self.update_ready_flag, 'r') as f:
                version_info = json.load(f)

            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            zip_path = os.path.join(self.temp_dir, 'update_package.zip')

            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)

            # Update EXE file
            new_exe_path = os.path.join(self.temp_dir, self.exe_name)
            if os.path.exists(new_exe_path):
                old_exe_path = os.path.join(self.base_path, self.exe_name)
                os.replace(new_exe_path, old_exe_path)
                logging.info(f"Updated {self.exe_name}")

            for file in manifest['files_to_update']:
                src = os.path.join(self.temp_dir, file)
                dst = os.path.join(self.base_path, file)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                logging.info(f"Updated file: {file}")

            for folder in manifest['folders_to_update']:
                src = os.path.join(self.temp_dir, folder)
                dst = os.path.join(self.base_path, folder)
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
                logging.info(f"Updated folder: {folder}")

            for file in manifest['files_to_remove']:
                file_path = os.path.join(self.base_path, file)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    logging.info(f"Removed file: {file}")

            for folder in manifest['folders_to_remove']:
                folder_path = os.path.join(self.base_path, folder)
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
                    logging.info(f"Removed folder: {folder}")

            self.update_local_version_file(version_info)

            # Clean up
            shutil.rmtree(self.temp_dir)
            os.remove(self.update_ready_flag)
            logging.info("Update applied successfully and cleanup completed")
            return True
        except Exception as e:
            logging.error(f"Error applying update: {e}")
            return False

    def update_local_version_file(self, new_version_info):
        current_time = datetime.now().isoformat()
        local_version_info = {
            "latest_version": new_version_info['latest_version'],
            "update_date": current_time
        }
        with open(self.version_file, 'w') as f:
            json.dump(local_version_info, f, indent=2)
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def update_process(self):
        logging.info("Starting update process")
        update_available, version_info = self.check_for_updates()
        if update_available:
            logging.info("Update is available. Attempting to download.")
            if self.download_update(version_info):
                logging.info("Update downloaded. It will be applied on next startup.")
                return True
            else:
                logging.error("Failed to download update")
        else:
            logging.info("No update available")
        return False

    def check_and_apply_update(self):
        if os.path.exists(self.update_ready_flag):
            logging.info("Update ready flag found. Applying update...")
            return self.apply_update()
        return False