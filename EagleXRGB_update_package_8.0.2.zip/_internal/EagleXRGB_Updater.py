import os
import json
import requests
import zipfile
import shutil
import logging
from packaging import version
from datetime import datetime


class AutoUpdater:
    def __init__(self, app_path, update_url):
        self.app_path = app_path
        self.update_url = update_url
        self.temp_dir = os.path.join(app_path, 'temp_update')
        self.version_file = os.path.join(app_path, 'EagleXRGB_version.json')

        # Setup logging
        log_file = os.path.join(app_path, 'update_log.txt')
        logging.basicConfig(filename=log_file, level=logging.INFO,
                            format='%(asctime)s - %(levelname)s - %(message)s')
        print(f"Logging to: {log_file}")

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            print(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.get_current_version())
            print(f"Current version: {current_version}, Latest version: {latest_version}")
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")
            return latest_version > current_version, remote_version_info
        except requests.RequestException as e:
            print(f"Error checking for updates: {e}")
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        return "0.0.0"  # Default version if file doesn't exist

    def download_update(self, version_info):
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)

        try:
            # Download the manifest
            manifest_url = f"{self.update_url}/{version_info['manifest']}"
            print(f"Downloading manifest from: {manifest_url}")
            manifest_response = requests.get(manifest_url)
            manifest_response.raise_for_status()

            with open(os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json'), 'wb') as f:
                f.write(manifest_response.content)

            # Download the update package
            update_url = f"{self.update_url}/{version_info['update_package']}"
            print(f"Downloading update package from: {update_url}")
            update_response = requests.get(update_url)
            update_response.raise_for_status()

            with open(os.path.join(self.temp_dir, 'update_package.zip'), 'wb') as f:
                f.write(update_response.content)

            print("Update package downloaded successfully")
            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            print(f"Error downloading update: {e}")
            logging.error(f"Error downloading update: {e}")
            return False

    def apply_update(self, new_version_info):
        try:
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            zip_path = os.path.join(self.temp_dir, 'update_package.zip')

            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)

            # Update files
            for file in manifest['files_to_update']:
                src = os.path.join(self.temp_dir, file)
                dst = os.path.join(self.app_path, file)
                shutil.copy2(src, dst)
                print(f"Updated file: {file}")

            # Update folders
            for folder in manifest['folders_to_update']:
                src = os.path.join(self.temp_dir, folder)
                dst = os.path.join(self.app_path, folder)
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
                print(f"Updated folder: {folder}")

            # Remove files
            for file in manifest['files_to_remove']:
                file_path = os.path.join(self.app_path, file)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    print(f"Removed file: {file}")

            # Remove folders
            for folder in manifest['folders_to_remove']:
                folder_path = os.path.join(self.app_path, folder)
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
                    print(f"Removed folder: {folder}")

            # Update local version file
            self.update_local_version_file(new_version_info)

            # Clean up
            shutil.rmtree(self.temp_dir)
            print("Update applied successfully")
            logging.info("Update applied successfully")
            return True
        except Exception as e:
            print(f"Error applying update: {e}")
            logging.error(f"Error applying update: {e}")
            return False

    def update_local_version_file(self, new_version_info):
        current_time = datetime.now().isoformat()
        local_version_info = {
            "latest_version": new_version_info['latest_version'],
            "update_date": current_time
        }
        with open(self.version_file, 'w') as f:
            json.dump(local_version_info, f, indent=2)
        print(f"Updated local version file to version {new_version_info['latest_version']}")
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def update_process(self):
        update_available, version_info = self.check_for_updates()
        if update_available:
            if self.download_update(version_info):
                if self.apply_update(version_info):
                    print("Update process completed successfully")
                    logging.info("Update process completed successfully")
                    return True
                else:
                    print("Failed to apply update")
                    logging.error("Failed to apply update")
            else:
                print("Failed to download update")
                logging.error("Failed to download update")
        else:
            print("No update available")
            logging.info("No update available")
        return False
