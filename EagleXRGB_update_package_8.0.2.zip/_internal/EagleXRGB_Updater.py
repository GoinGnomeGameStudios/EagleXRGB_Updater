import os
import sys
import json
import requests
import zipfile
import shutil
import logging
from packaging import version
from datetime import datetime
import tempfile


class AutoUpdater:
    def __init__(self, update_url):
        self.base_path = self.get_app_dir()
        self.update_url = update_url
        self.temp_dir = self.get_writable_temp_dir()
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')

        # Setup logging
        log_file = os.path.join(self.base_path, 'update_log.txt')
        logging.basicConfig(filename=log_file, level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')
        print(f"Logging to: {log_file}")
        logging.info(f"AutoUpdater initialized. Base path: {self.base_path}, Update URL: {update_url}")
        logging.info(f"Temp directory: {self.temp_dir}")
        logging.info(f"Version file: {self.version_file}")

    def get_base_path(self, app_path):
        if getattr(sys, 'frozen', False):
            # Running as compiled executable
            return os.path.dirname(app_path)
        else:
            # Running in a normal Python environment
            return app_path

    def get_writable_dir(self):
        if os.access(self.base_path, os.W_OK):
            return self.base_path
        return os.path.join(os.path.expanduser("~"), "EagleXRGB")

    def get_app_dir(self):
        if getattr(sys, 'frozen', False):
            # Running as compiled executable
            return os.path.dirname(sys.executable)
        else:
            # Running in a normal Python environment
            return os.path.dirname(os.path.abspath(__file__))

    def get_writable_temp_dir(self):
        try:
            return tempfile.mkdtemp(prefix="EagleXRGB_update_", dir=self.base_path)
        except:
            return os.path.join(self.base_path, 'temp_update')

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            logging.info(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.get_current_version())
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")
            return latest_version > current_version, remote_version_info
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"  # Default version if file doesn't exist

    def download_update(self, version_info):
        logging.info(f"Using temp directory: {self.temp_dir}")
        try:
            # Download the manifest
            manifest_url = f"{self.update_url}/{version_info['manifest']}"
            logging.info(f"Downloading manifest from: {manifest_url}")
            manifest_response = requests.get(manifest_url)
            manifest_response.raise_for_status()

            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            with open(manifest_path, 'wb') as f:
                f.write(manifest_response.content)
            logging.info(f"Manifest downloaded to: {manifest_path}")

            # Download the update package
            update_url = f"{self.update_url}/{version_info['update_package']}"
            logging.info(f"Downloading update package from: {update_url}")
            update_response = requests.get(update_url)
            update_response.raise_for_status()

            package_path = os.path.join(self.temp_dir, 'update_package.zip')
            with open(package_path, 'wb') as f:
                f.write(update_response.content)
            logging.info(f"Update package downloaded to: {package_path}")

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def apply_update(self, new_version_info):
        try:
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            zip_path = os.path.join(self.temp_dir, 'update_package.zip')

            logging.info(f"Reading manifest from: {manifest_path}")
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            logging.info(f"Extracting update package: {zip_path}")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)

            # Update files
            for file in manifest['files_to_update']:
                src = os.path.join(self.temp_dir, file)
                dst = os.path.join(self.base_path, file)
                logging.info(f"Updating file: {src} -> {dst}")
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)

            # Update folders
            for folder in manifest['folders_to_update']:
                src = os.path.join(self.temp_dir, folder)
                dst = os.path.join(self.base_path, folder)
                logging.info(f"Updating folder: {src} -> {dst}")
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)

            # Remove files
            for file in manifest['files_to_remove']:
                file_path = os.path.join(self.base_path, file)
                if os.path.exists(file_path):
                    logging.info(f"Removing file: {file_path}")
                    os.remove(file_path)

            # Remove folders
            for folder in manifest['folders_to_remove']:
                folder_path = os.path.join(self.base_path, folder)
                if os.path.exists(folder_path):
                    logging.info(f"Removing folder: {folder_path}")
                    shutil.rmtree(folder_path)

            # Update local version file
            self.update_local_version_file(new_version_info)

            # Clean up
            logging.info(f"Cleaning up temp directory: {self.temp_dir}")
            shutil.rmtree(self.temp_dir)
            logging.info("Update applied successfully")
            return True
        except Exception as e:
            logging.error(f"Error applying update: {e}")
            return False

    def update_local_version_file(self, new_version_info):
        current_time = datetime.now().isoformat()
        local_version_info = {
            "latest_version": new_version_info['latest_version'],
            "update_date": current_time
        }
        logging.info(f"Updating local version file: {self.version_file}")
        os.makedirs(os.path.dirname(self.version_file), exist_ok=True)
        with open(self.version_file, 'w') as f:
            json.dump(local_version_info, f, indent=2)
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def update_process(self):
        logging.info("Starting update process")
        update_available, version_info = self.check_for_updates()
        if update_available:
            logging.info("Update is available. Attempting to download.")
            if self.download_update(version_info):
                logging.info("Update downloaded. Attempting to apply.")
                if self.apply_update(version_info):
                    logging.info("Update process completed successfully")
                    return True
                else:
                    logging.error("Failed to apply update")
            else:
                logging.error("Failed to download update")
        else:
            logging.info("No update available")
        return False