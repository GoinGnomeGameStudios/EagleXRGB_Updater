import os
import sys
import json
import shutil
import subprocess
import logging
from datetime import datetime

import requests
from packaging import version

class AutoUpdater:
    def __init__(self, update_url, current_version):
        self.update_url = update_url
        self.current_version = current_version
        self.base_path = self.get_app_dir()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.update_ready_flag = os.path.join(self.base_path, 'update_ready.flag')
        self.exe_name = 'EDC_EagleXRGB_Connector.exe'

        logging.basicConfig(filename='update.log', level=logging.DEBUG)

    def get_app_dir(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            logging.info(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.get_current_version())
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")
            return latest_version > current_version, remote_version_info
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"

    def download_update(self, version_info):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        os.makedirs(self.temp_dir)

        logging.info(f"Using temp directory: {self.temp_dir}")
        try:
            manifest_url = f"{self.update_url}/{version_info['manifest']}"
            update_url = f"{self.update_url}/{version_info['update_package']}"

            # Download manifest
            logging.info(f"Downloading manifest from: {manifest_url}")
            manifest_response = requests.get(manifest_url)
            manifest_response.raise_for_status()
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            with open(manifest_path, 'wb') as f:
                f.write(manifest_response.content)

            # Download update package
            logging.info(f"Downloading update package from: {update_url}")
            update_response = requests.get(update_url)
            update_response.raise_for_status()
            package_path = os.path.join(self.temp_dir, 'update_package.zip')
            with open(package_path, 'wb') as f:
                f.write(update_response.content)

            # Create update ready flag
            with open(self.update_ready_flag, 'w') as f:
                json.dump(version_info, f)

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def apply_update(self):
        if not os.path.exists(self.update_ready_flag):
            logging.info("No update ready to apply")
            return False

        try:
            with open(self.update_ready_flag, 'r') as f:
                version_info = json.load(f)

            with open(os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json'), 'r') as f:
                manifest = json.load(f)

            # Update files and folders
            for file in manifest['files_to_update']:
                src = os.path.join(self.temp_dir, file)
                dst = os.path.join(self.base_path, file)
                if file == self.exe_name:
                    continue  # We'll handle the EXE separately
                shutil.copy2(src, dst)
                logging.info(f"Updated file: {file}")

            for folder in manifest['folders_to_update']:
                src = os.path.join(self.temp_dir, folder)
                dst = os.path.join(self.base_path, folder)
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
                logging.info(f"Updated folder: {folder}")

            # Remove files and folders
            for file in manifest['files_to_remove']:
                file_path = os.path.join(self.base_path, file)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    logging.info(f"Removed file: {file}")

            for folder in manifest['folders_to_remove']:
                folder_path = os.path.join(self.base_path, folder)
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
                    logging.info(f"Removed folder: {folder}")

            # Prepare batch script for EXE replacement and restart
            batch_script = os.path.join(self.base_path, 'finish_update.bat')
            with open(batch_script, 'w') as f:
                f.write('@echo off\n')
                f.write('timeout /t 2 /nobreak\n')
                f.write(f'move /Y "{os.path.join(self.temp_dir, self.exe_name)}" "{os.path.join(self.base_path, self.exe_name)}"\n')
                f.write(f'start "" "{os.path.join(self.base_path, self.exe_name)}"\n')
                f.write(f'del "%~f0"\n')

            # Run the batch script
            subprocess.Popen(batch_script, shell=True)

            # Update local version file
            self.update_local_version_file(version_info)

            # Exit the current instance
            logging.info("Update applied successfully. Restarting application.")
            sys.exit()

        except Exception as e:
            logging.error(f"Error applying update: {e}")
            return False

    def verify_update(self):
        try:
            with open(self.version_file, 'r') as f:
                current_version = json.load(f)['latest_version']
            if version.parse(current_version) > version.parse(self.current_version):
                logging.info(f"Update successful. New version: {current_version}")
                return True
            else:
                logging.error(f"Update failed or not applied. Current version: {current_version}")
                return False
        except Exception as e:
            logging.error(f"Error verifying update: {e}")
            return False

    def update_local_version_file(self, new_version_info):
        current_time = datetime.now().isoformat()
        local_version_info = {
            "latest_version": new_version_info['latest_version'],
            "update_date": current_time
        }
        with open(self.version_file, 'w') as f:
            json.dump(local_version_info, f, indent=2)
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def check_and_apply_update(self):
        if os.path.exists(self.update_ready_flag):
            logging.info("Update ready flag found. Applying update...")
            return self.apply_update()
        return False

    def update_process(self):
        logging.info("Starting update process")
        update_available, version_info = self.check_for_updates()
        if update_available:
            logging.info("Update is available. Attempting to download.")
            if self.download_update(version_info):
                logging.info("Update downloaded. It will be applied on next startup.")
                return True
            else:
                logging.error("Failed to download update")
        else:
            logging.info("No update available")
        return False

    def check_and_apply_update(self):
        if os.path.exists(self.update_ready_flag):
            logging.info("Update ready flag found. Applying update...")
            return self.apply_update()
        return False