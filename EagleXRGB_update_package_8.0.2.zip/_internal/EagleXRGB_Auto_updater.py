import os
import sys
import json
import shutil
import logging
import time
import zipfile
import subprocess
import psutil
import requests
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMessageBox, QWidget
from PyQt5.QtCore import QThread, pyqtSignal, QTimer
from requests import RequestException

from EagleXRGB_splash_screen import SplashScreen


class UpdaterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EagleXRGB Auto Updater")
        self.setWindowIcon(QIcon('icons/eaglex-openrgb-connector-icon.png'))


class UpdaterThread(QThread):
    update_progress = pyqtSignal(int, str)
    update_completed = pyqtSignal(bool, str)

    def __init__(self, updater):
        super().__init__()
        self.updater = updater

    def run(self):
        try:
            self.updater.apply_update(self.update_progress)
            self.update_completed.emit(True, "Update completed successfully.")
        except Exception as e:
            logging.error(f"Error during update: {str(e)}", exc_info=True)
            self.update_completed.emit(False, f"Update failed: {str(e)}")


class Updater:
    def __init__(self, update_info_path):
        self.setup_logging()
        with open(update_info_path, 'r') as f:
            self.update_info = json.load(f)
        self.base_path = os.path.dirname(self.update_info['main_exe_path'])
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.main_exe = os.path.basename(self.update_info['main_exe_path'])

    def setup_logging(self):
        logging.basicConfig(filename='updater.log', level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def wait_for_process_to_end(self, timeout=30):
        start_time = time.time()
        while time.time() - start_time < timeout:
            if not any(proc.name() == self.main_exe for proc in psutil.process_iter(['name'])):
                return True
            time.sleep(1)
        return False

    def force_close_main_app(self):
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == self.main_exe:
                logging.info(f"Attempting to close {self.main_exe} (PID: {proc.pid})")
                try:
                    proc.terminate()
                    proc.wait(timeout=10)
                except psutil.TimeoutExpired:
                    logging.warning(f"Termination timed out, forcing closure of {self.main_exe}")
                    proc.kill()
                except Exception as e:
                    logging.error(f"Error closing {self.main_exe}: {str(e)}")

    def download_update(self, progress_callback):
        try:
            new_version = self.update_info['new_version']
            update_package_name = f"EagleXRGB_update_package_{new_version}.zip"
            update_url = f"{self.update_info['update_url']}/{update_package_name}"

            logging.info(f"Attempting to download update package from: {update_url}")

            response = requests.get(update_url, stream=True, timeout=30)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, update_package_name)

            total_size = int(response.headers.get('content-length', 0))
            logging.info(f"Total download size: {total_size} bytes")

            block_size = 8192
            downloaded = 0

            with open(package_path, 'wb') as f:
                for data in response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        progress_callback.emit(progress, f"Downloading update... {progress}%")
                    logging.debug(f"Downloaded {downloaded} of {total_size} bytes")

            if downloaded == total_size or total_size == 0:
                logging.info(f"Update package '{update_package_name}' downloaded successfully")
                return True
            else:
                logging.error(f"Download incomplete. Expected {total_size}, got {downloaded} bytes")
                return False

        except RequestException as e:
            logging.error(f"Network error while downloading update: {str(e)}")
            return False
        except Exception as e:
            logging.error(f"Unexpected error during download: {str(e)}")
            return False

    def apply_update(self, progress_callback):
        try:
            # Step 1: Ensure main application is closed
            progress_callback.emit(0, f"Closing {self.main_exe}...")
            logging.info(f"Attempting to close {self.main_exe}")
            self.force_close_main_app()

            # Wait to ensure the process is fully closed
            time.sleep(2)

            # Step 2: Download the update package
            progress_callback.emit(10, "Downloading update package...")
            logging.info("Starting update package download...")
            if not self.download_update(progress_callback):
                raise Exception(f"Failed to download update package from {self.update_info['update_url']}")

            # Step 3: Extract the update package
            progress_callback.emit(50, "Extracting update package...")
            logging.info("Extracting update package...")
            new_version = self.update_info['new_version']
            update_package_name = f"EagleXRGB_update_package_{new_version}.zip"
            package_path = os.path.join(self.temp_dir, update_package_name)
            if not os.path.exists(package_path):
                raise FileNotFoundError(f"Update package not found: {package_path}")

            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)
            progress_callback.emit(60, "Update package extracted")

            # Step 4: Read the update manifest
            progress_callback.emit(30, "Reading update manifest...")
            logging.info("Reading update manifest...")
            manifest_path = os.path.join(self.temp_dir, 'EagleXRGB_update_manifest.json')
            if not os.path.exists(manifest_path):
                raise FileNotFoundError("Update manifest not found")

            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            # Step 5: Update files and folders
            progress_callback.emit(40, "Updating files and folders...")
            logging.info("Updating files and folders...")
            self.update_files_and_folders(manifest, progress_callback)

            # Step 6: Update main executable
            progress_callback.emit(80, f"Updating {self.main_exe}...")
            logging.info(f"Updating {self.main_exe}...")
            self.update_main_executable()

            # Step 7: Update local version file
            progress_callback.emit(90, "Updating version information...")
            logging.info("Updating version information...")
            self.update_local_version_file()

            # Step 8: Verify update
            progress_callback.emit(95, "Verifying update...")
            logging.info("Verifying update...")
            self.verify_update()

            # Step 9: Clean up
            progress_callback.emit(98, "Cleaning up...")
            logging.info("Cleaning up...")
            self.clean_up()

            logging.info("Update applied successfully.")
            progress_callback.emit(100, "Update completed successfully")
        except Exception as e:
            logging.error(f"Error applying update: {str(e)}", exc_info=True)
            raise

    def update_files_and_folders(self, manifest, progress_callback):
        total_items = len(manifest.get('files_to_update', [])) + len(manifest.get('folders_to_update', []))
        current_item = 0

        for item in manifest.get('files_to_update', []) + manifest.get('folders_to_update', []):
            if 'path' in item:
                src = os.path.join(self.temp_dir, item['path'])
                dst = os.path.join(self.base_path, item['path'])
                if os.path.isfile(src):
                    self.update_file(src, dst, item['action'])
                else:
                    self.update_folder(src, dst, item['action'])
            current_item += 1
            progress = 40 + int((current_item / total_items) * 40)  # Progress from 40% to 80%
            progress_callback.emit(progress, f"Updating: {item['path']}")

    def update_file(self, src, dst, action):
        if action == 'replace' or not os.path.exists(dst):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            logging.info(f"Updated file: {dst}")

    def update_folder(self, src, dst, action):
        if action == 'merge':
            self.merge_folders(src, dst)
        elif action == 'replace':
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            logging.info(f"Replaced folder: {dst}")
        elif action == 'create_if_not_exists' and not os.path.exists(dst):
            shutil.copytree(src, dst)
            logging.info(f"Created folder: {dst}")

    def merge_folders(self, src, dst):
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                self.merge_folders(s, d)
            else:
                shutil.copy2(s, d)
                logging.info(f"Updated file in merge: {d}")

    def update_main_executable(self):
        src = os.path.join(self.temp_dir, self.main_exe)
        dst = self.update_info['main_exe_path']
        if os.path.exists(src):
            # Rename the old executable
            old_exe = dst + '.old'
            if os.path.exists(old_exe):
                os.remove(old_exe)
            os.rename(dst, old_exe)

            # Copy the new executable
            shutil.copy2(src, dst)
            logging.info(f"Updated main executable: {dst}")

            # Remove the old executable
            try:
                os.remove(old_exe)
                logging.info(f"Removed old executable: {old_exe}")
            except Exception as e:
                logging.warning(f"Failed to remove old executable: {str(e)}")
        else:
            raise Exception(f"Main executable not found in update package: {src}")

    def update_local_version_file(self):
        new_version_info = {
            "latest_version": self.update_info['new_version'],
            "update_date": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        with open(self.version_file, 'w') as f:
            json.dump(new_version_info, f, indent=2)
        logging.info(f"Updated local version file to version {self.update_info['new_version']}")

    def verify_update(self):
        if not os.path.exists(self.update_info['main_exe_path']):
            raise Exception("Main executable not found after update")
        if not os.path.exists(self.version_file):
            raise Exception("Version file not found after update")

        # Check the version of the updated executable
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                result = subprocess.run([self.update_info['main_exe_path'], '--version'],
                                        capture_output=True, text=True, timeout=10)
                updated_version = result.stdout.strip()
                if updated_version != self.update_info['new_version']:
                    raise Exception(
                        f"Version mismatch after update. Expected {self.update_info['new_version']}, got {updated_version}")
                logging.info(f"Verified updated version: {updated_version}")
                return  # Successful verification
            except subprocess.TimeoutExpired:
                logging.warning(
                    f"Timeout while checking updated executable version (attempt {attempt + 1}/{max_attempts})")
            except Exception as e:
                logging.error(
                    f"Error checking updated executable version (attempt {attempt + 1}/{max_attempts}): {str(e)}")

            if attempt < max_attempts - 1:
                time.sleep(2)  # Wait before retrying

        raise Exception("Failed to verify the updated executable version after multiple attempts")

    def clean_up(self):
        try:
            shutil.rmtree(self.temp_dir)
            logging.info(f"Removed temporary update directory: {self.temp_dir}")
        except Exception as e:
            logging.error(f"Failed to remove temporary update directory: {str(e)}")


def main():
    app = QApplication(sys.argv)

    # Create the main window to set the taskbar icon
    main_window = UpdaterWindow()

    if len(sys.argv) < 2:
        QMessageBox.critical(None, "Error", "No update info provided")
        return

    update_info_path = sys.argv[1]
    with open(update_info_path, 'r') as f:
        update_info = json.load(f)

    splash = SplashScreen()
    splash.show()

    updater = Updater(update_info_path)
    updater_thread = UpdaterThread(updater)

    def update_progress(value, status):
        splash.update_progress(value, status)
        logging.info(f"Update progress: {value}% - {status}")

    def update_completed(success, message):
        if success:
            splash.show_update_info("Update complete. Restarting application...")
            logging.info("Update completed successfully. Restarting main application.")
            QTimer.singleShot(2000, lambda: restart_main_app(updater.update_info['main_exe_path']))
        else:
            splash.show_update_info("Update failed. Please try again.")
            logging.error(f"Update failed: {message}")
            QMessageBox.critical(None, "Update Failed", message)
            QTimer.singleShot(2000, app.quit)

    def restart_main_app(main_exe_path):
        logging.info(f"Attempting to restart main application: {main_exe_path}")
        try:
            subprocess.Popen([main_exe_path])
            logging.info("Main application restart initiated.")
        except Exception as e:
            logging.error(f"Failed to restart main application: {str(e)}", exc_info=True)
        finally:
            app.quit()

    updater_thread.update_progress.connect(update_progress)
    updater_thread.update_completed.connect(update_completed)
    updater_thread.start()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
