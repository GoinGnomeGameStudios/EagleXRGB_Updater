import os
import shutil
import sys
import json
import logging
import time
from datetime import datetime

import requests
from packaging import version

class AutoUpdater:
    def __init__(self, update_url, current_version, splash_screen):
        self.update_url = update_url
        self.current_version = current_version
        self.splash_screen = splash_screen
        self.base_path = self.get_app_dir()
        self.temp_dir = os.path.join(self.base_path, 'EagleXRGB_update')
        self.version_file = os.path.join(self.base_path, 'EagleXRGB_version.json')
        self.setup_logging()

    def setup_logging(self):
        logging.basicConfig(filename='update_check.log', level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

    def get_app_dir(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    def check_for_updates(self):
        try:
            version_url = f"{self.update_url}/EagleXRGB_version.json"
            logging.info(f"Checking for updates at: {version_url}")
            response = requests.get(version_url)
            response.raise_for_status()
            remote_version_info = response.json()
            latest_version = version.parse(remote_version_info['latest_version'])
            current_version = version.parse(self.current_version)
            logging.info(f"Current version: {current_version}, Latest version: {latest_version}")
            return latest_version > current_version, remote_version_info
        except requests.RequestException as e:
            logging.error(f"Error checking for updates: {e}")
            return False, None

    def get_current_version(self):
        if os.path.exists(self.version_file):
            with open(self.version_file, 'r') as f:
                return json.load(f)['latest_version']
        logging.warning(f"Version file not found at {self.version_file}. Using default version 0.0.0")
        return "0.0.0"

    def download_update(self, version_info):
        if not version_info or 'update_package' not in version_info:
            logging.error("Invalid version info")
            return False

        try:
            update_url = f"{self.update_url}/{version_info['update_package']}"
            logging.info(f"Downloading update package from: {update_url}")
            response = requests.get(update_url, stream=True)
            response.raise_for_status()

            os.makedirs(self.temp_dir, exist_ok=True)
            package_path = os.path.join(self.temp_dir, 'update_package.zip')

            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded = 0

            with open(package_path, 'wb') as f:
                for data in response.iter_content(block_size):
                    size = f.write(data)
                    downloaded += size
                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        self.splash_screen.update_progress(progress, "Downloading update...")

            logging.info("Update package downloaded successfully")
            return True
        except requests.RequestException as e:
            logging.error(f"Error downloading update: {e}")
            return False

    def prepare_for_update(self, version_info):
        update_info = {
            'main_exe_path': sys.executable,
            'update_url': self.update_url,
            'current_version': self.current_version,
            'new_version': version_info['latest_version']
        }
        update_info_path = os.path.join(self.temp_dir, 'update_info.json')
        with open(update_info_path, 'w') as f:
            json.dump(update_info, f)
        return update_info_path

    def update_files_and_folders(self, manifest):
        total_items = len(manifest.get('files_to_update', [])) + len(manifest.get('folders_to_update', []))
        current_item = 0

        for item in manifest.get('files_to_update', []) + manifest.get('folders_to_update', []):
            if 'path' in item:
                if os.path.isfile(os.path.join(self.temp_dir, item['path'])):
                    self.update_file(item)
                else:
                    self.update_folder(item)
            current_item += 1
            progress = int((current_item / total_items) * 100)
            logging.info(f"Update progress: {progress}%")
            if self.splash_screen:
                self.splash_screen.update_progress(progress, "Updating")

    def update_file(self, file_info):
        src = os.path.join(self.temp_dir, file_info['path'])
        dst = os.path.join(self.base_path, file_info['path'])
        if file_info['path'] == self.exe_name:
            return  # We'll handle the EXE separately

        if os.path.exists(src):
            if file_info['action'] == 'replace' or not os.path.exists(dst):
                self.safe_file_operation(shutil.copy2, src, dst)
                logging.info(f"Updated file: {file_info['path']}")
        else:
            logging.warning(f"Source file not found: {src}")

    def update_folder(self, folder_info):
        src = os.path.join(self.temp_dir, folder_info['path'])
        dst = os.path.join(self.base_path, folder_info['path'])
        if os.path.exists(src):
            if folder_info['action'] == 'merge':
                self.merge_folders(src, dst)
            elif folder_info['action'] == 'create_if_not_exists':
                if not os.path.exists(dst):
                    self.safe_file_operation(shutil.copytree, src, dst)
                    logging.info(f"Created folder: {folder_info['path']}")
            elif folder_info['action'] == 'replace':
                if os.path.exists(dst):
                    self.safe_file_operation(shutil.rmtree, dst)
                self.safe_file_operation(shutil.copytree, src, dst)
                logging.info(f"Replaced folder: {folder_info['path']}")
        else:
            logging.warning(f"Source folder not found: {src}")

    def safe_file_operation(self, operation, *args, max_attempts=10, delay=2):
        for attempt in range(max_attempts):
            try:
                operation(*args)
                return
            except PermissionError as e:
                if attempt < max_attempts - 1:
                    logging.warning(f"Permission error, retrying in {delay} seconds: {str(e)}")
                    time.sleep(delay)
                else:
                    raise

    def merge_folders(self, src, dst):
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                self.merge_folders(s, d)
            else:
                self.safe_file_operation(shutil.copy2, s, d)
                logging.info(f"Updated file in merge: {d}")

    def update_local_version_file(self, new_version_info):
        current_time = datetime.now().isoformat()
        local_version_info = {
            "latest_version": new_version_info['latest_version'],
            "update_date": current_time
        }
        with open(self.version_file, 'w') as f:
            json.dump(local_version_info, f, indent=2)
        logging.info(f"Updated local version file to version {new_version_info['latest_version']}")

    def automatic_update(self):
        update_available, version_info = self.check_for_updates()
        if update_available and version_info:
            logging.info(f"Update available: {version_info.get('latest_version', 'Unknown')}")
            if self.download_update(version_info):
                return self.apply_update()
        return False
