import openrgb
import time
import sys
from openrgb.utils import RGBColor, ZoneType

class ChaseEffect:
    def __init__(self):
        self.client = openrgb.OpenRGBClient()
        self.Dlist = self.client.devices
        self.Color1 = RGBColor(255, 0, 0)
        self.Color2 = RGBColor(0, 0, 255)
        self.ReversedDevice = None
        self.OnlySet = None
        self.Speed = 1.0
        self.Brightness = 1.0

    def SetStatic(self, Dlist):
        for Device in Dlist:
            time.sleep(0.05)
            try:
                Device.set_mode('direct')
                print(f'Set {Device.name} successfully')
            except:
                try:
                    Device.set_mode('static')
                    print(f'error setting {Device.name}\nfalling back to static')
                except:
                    print(f"Critical error! couldn't set {Device.name} to static or direct")

    def apply_brightness(self, color, brightness):
        return RGBColor(int(color.red * brightness), int(color.green * brightness), int(color.blue * brightness))

    def InfiniteCycle(self):
        Enable = self.OnlySet if self.OnlySet is not None else self.client.devices
        PassTo = []
        for Device in Enable:
            ReverseBool = Device in self.ReversedDevice if self.ReversedDevice else False
            for zone in Device.zones:
                LEDAmount = len(zone.leds)
                PassTo.append([zone, list(range(1, LEDAmount + 1)), LEDAmount, ReverseBool])

        self.SetStatic(Enable)
        RunThrough = 0
        while True:
            for ZO in PassTo:
                ZOType = ZO[0].type
                if ZOType == ZoneType.SINGLE:
                    RunThrough += 1
                    if (RunThrough % 3) == 0:
                        if ZO[0].colors[0] == self.Color1:
                            ZO[0].colors[0] = self.apply_brightness(self.Color2, self.Brightness)
                        elif ZO[0].colors[0] == self.Color2:
                            ZO[0].colors[0] = self.apply_brightness(self.Color1, self.Brightness)
                        else:
                            ZO[0].colors[0] = self.apply_brightness(self.Color2, self.Brightness)
                        ZO[0].show()
                elif ZOType == ZoneType.LINEAR:
                    ID = 0
                    Half = int(len(ZO[0].colors) / 2)
                    for _ in ZO[0].colors:
                        if ZO[3]:  # Reversed
                            if ZO[1][ID] > Half:
                                ZO[0].colors[ID] = self.apply_brightness(self.Color1, self.Brightness)
                            else:
                                ZO[0].colors[ID] = self.apply_brightness(self.Color2, self.Brightness)
                            ZO[1][ID] = (ZO[1][ID] % ZO[2]) + 1
                        else:
                            if ZO[1][ID] >= Half:
                                ZO[0].colors[ID] = self.apply_brightness(self.Color1, self.Brightness)
                            else:
                                ZO[0].colors[ID] = self.apply_brightness(self.Color2, self.Brightness)
                            ZO[1][ID] = ZO[2] if ZO[1][ID] <= 1 else ZO[1][ID] - 1
                        ID += 1
                    ZO[0].show()
                elif ZOType == ZoneType.MATRIX:
                    pass  # matrix support not implemented
            time.sleep(0.01 / self.Speed)  # Adjust sleep time based on speed

    def update_speed(self, new_speed):
        self.Speed = new_speed

    def update_brightness(self, new_brightness):
        self.Brightness = new_brightness / 100.0  # Convert percentage to float

    def run(self):
        self.InfiniteCycle()

# This part would be in your main application file
class MainApp:
    def __init__(self):
        self.brightness_spin = None
        self.speed_effect_spin = None
        self.effect = OpenRGBEffect()
        # ... other initialization code ...

    def setup_ui(self):
        # ... other UI setup code ...

        self.speed_effect_spin.valueChanged.connect(self.update_effect_speed)
        self.brightness_spin.valueChanged.connect(self.update_effect_brightness)

    def update_effect_speed(self, value):
        self.effect.update_speed(value)

    def update_effect_brightness(self, value):
        self.effect.update_brightness(value)

    def start_effect(self):
        # Run the effect in a separate thread
        import threading
        effect_thread = threading.Thread(target=self.effect.run)
        effect_thread.start()

# Usage
if __name__ == "__main__":
    app = MainApp()
    app.setup_ui()
    app.start_effect()